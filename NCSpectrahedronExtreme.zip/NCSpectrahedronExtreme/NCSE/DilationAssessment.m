(* ::Package:: *)

(* ::Section:: *)
(*DilationAssessment 1.0.0*)


BeginPackage["DilationAssessment`",{"NCSE`"}]

Get["DilationAssessment.usage"];
X;
Y;
Z;
gamma;
BadNullNumerics;

Begin["`Private`"];



(* ::Section:: *)
(*Dilations*)


(* ::Text:: *)
(*This section contains functions for dilating a tuple toward a free extreme point of the given free spectrahedron*)


(* Dilation Assessment performs an experiment to track the number of Maximal1Dilations needed to dilate elements of randomly generated free spectrahedra in g variables to Arveson extreme points *)
Options[DilationAssessment]:={StepEarlyStop->1,PrintOneSpec->False,OutputFile->False,DemoOutput->False}
DilationAssessment[g_,d_,level_,numA_,numXperA_,numAttempt_,radius_,seed_,OptionsPattern[]]:=Block[{spec,point,SpecPointsPair,TotalBestDSDs,TotalCount,BestDSDs,index,j,k,count,countRej,DSD,Max1Di,iters,failediters,BestDi,BestStep,BestDSD,table,BestVariName,filename,filepath,fileStream,RandomBeta},

SpecPointsPair={};
TotalBestDSDs={};
TotalCount=0;

For[index=1,index<=numA,index++,
spec=MakeIrreducibleBoundedA[g,d,seed+index*137];
count=0;
BestDSDs={};

If[OptionValue[PrintOneSpec],
Print["---------------------------------"];
Print["Spectrahedron seed: ",seed+index*137]
];

For[j=1,j<= numXperA,j++,
SeedRandom[j];


point=RandSpecInteriorPt[spec,level];
    
BestStep=g*level;
BestDSD=Table[g*level-i,{i,0,g*level}];
For[k=1,k<=numAttempt,k++,
{Max1Di,DSD,iters,failediters}=Maximal1DilationRepeated[spec,point,100,RandomBeta->True];
If[Length[DSD]-1<= OptionValue[StepEarlyStop],BestStep=Length[DSD]-1;BestDSD=DSD;BestDi=Max1Di;Break[]];
If[DilationSubspaceDimension[spec,Max1Di]==0&&BestStep>= Length[DSD],BestStep=Length[DSD]-1;BestDSD=DSD;BestDi=Max1Di];
];
    
count+=1;
TotalCount+=1;
SpecPointsPair=Append[SpecPointsPair,{spec,point,Eigenvalues[LMI[spec,point]//N]}];
BestDSDs=Append[BestDSDs,{BestStep,BestDSD,BestDi}];
TotalBestDSDs=Append[TotalBestDSDs,{BestStep,BestDSD,BestDi}];
];

If[OptionValue[PrintOneSpec],
table=Transpose[BestDSDs][[1]];
Print[Table[{i,Count[table,i]},{i,Min[table],Max[table]}]];
Print[count];
table=DeleteDuplicates[Transpose[BestDSDs][[2]]];
Print[Table[{table[[i]],Count[Transpose[BestDSDs][[2]],table[[i]]]},{i,Length[table]}]];
]];

If[SameQ[OptionValue[OutputFile],False]==False,
filename=StringJoin[OptionValue[OutputFile],ToString[TotalCount],"_g",ToString[g],"d",ToString[d],"n",ToString[level],"seed",ToString[seed]];
fileStream=OpenWrite[StringJoin[filename,".m"]];

















(* ::Section::Closed:: *)
(**)


WriteLine[fileStream,StringJoin["(* g=",ToString[g],",d=",ToString[d],",n=",ToString[level],",",ToString[numA]," spectrahedra, ",ToString[numXperA]," random initial point (radius: ",ToString[radius],") per spectrahedron *)"]];



(* ::Subsection::Closed:: *)
(**)


WriteLine[fileStream,"(* Plot Function *)"];


(* ::Input::Initialization:: *)
WriteLine[fileStream,"BestNumDilStepsPlot[Best_]:=Block[{},Return[Histogram[Best,{Min[Best]-0.5,Max[Best]+0.5,1},LabelingFunction->Above]]];"];
WriteLine[fileStream,"EigenDistribution[eigen_]:=Block[{eigenlist},eigenlist=Transpose[eigen];Return[BoxWhiskerChart[eigenlist,Epilog\[Rule]{Red,PointSize[Medium],Point/@Table[Transpose[{Table[i-0.1+0.2*j/(Length[eigenlist[[i]]]-1),{j,0,Length[eigenlist[[i]]]-1}],eigenlist[[i]]}],{i,Length[eigenlist]}]}]]];"];
WriteLine[fileStream,"DSDimPlot[DSDim_,max_]:=Block[{DSDimLines,Bottom,Left},DSDimLines=DeleteDuplicates[DSDim];DSDimLines=Table[Table[{j-1,DSDimLines[[i]][[j]]},{j,Length[DSDimLines[[i]]]}],{i,Length[DSDimLines]}];If[Length[DSDimLines]== 1,DSDimLines=DSDimLines[[1]]];Return[{Labeled[ListLinePlot[DSDimLines,Mesh-> Full,PlotRange->{{0,max+0.5},{0,max+0.5}}, GridLines->{Range[max], Range[max]},AxesLabel->{\"x\",\"y\"}],{\"x: Number of dilation steps\",\"y: DSDim\"},{Bottom,Left},RotateLabel->True],Histogram[{DSDim//Flatten,Table[DSDim[[i]][[Length[DSDim[[i]]]]],{i,Length[DSDim]}]},{-0.5,max+0.5,1},BarOrigin->Left]}]];"];



(* ::Subsection::Closed:: *)
(**)


WriteLine[fileStream,"(* Spectrahedron-Point Pair *)"];


(* ::Input::Initialization:: *)
WriteLine[fileStream,StringJoin["SpecPointsPair=",ToString[SpecPointsPair,InputForm],";"]];

BestVariName=StringJoin["BestDSD","g",ToString[g],"d",ToString[d],"n",ToString[level],"seed",ToString[seed]];


(* ::Subsection::Closed:: *)
(**)


WriteLine[fileStream,"(* Best # Dilation *)"];


(* ::Input::Initialization:: *)
WriteLine[fileStream,StringJoin[BestVariName,"Step=",ToString[Transpose[TotalBestDSDs][[1]],InputForm],";"]];
WriteLine[fileStream,StringJoin[BestVariName,"DSDs=",ToString[Transpose[TotalBestDSDs][[2]],InputForm],";"]];



(* ::Subsection:: *)
(**)


WriteLine[fileStream,"(* Best # Dilation Plot *)"];


(* ::Input::Initialization:: *)
WriteLine[fileStream,StringJoin["BestNumDilStepsPlot[",BestVariName,"Step]"]];


(* ::Input::Initialization:: *)
WriteLine[fileStream,StringJoin["DSDimPlot[",BestVariName,"DSDs,",ToString[g*level],"]"]];



(* ::Subsection:: *)
(**)


WriteLine[fileStream,"(* Eigenvalues Distributions *)"];


(* ::Input::Initialization:: *)
WriteLine[fileStream,"EigenDistribution[Transpose[SpecPointsPair][[3]]]"];



(* ::Subsection::Closed:: *)
(**)


WriteLine[fileStream,"(* Export to PDF *)"];


(* ::Input::Initialization:: *)
WriteLine[fileStream,StringJoin["Export[\"",filename,".pdf\", EvaluationNotebook[]];"]];

Close[fileStream];
];
If[OptionValue[PrintOneSpec],
Print["---------------------------------"];
Print["Total:"];
];
table=Transpose[TotalBestDSDs][[1]];
table=Table[{i, Count[table, i]}, {i, Min[table], Max[table]}];

If[OptionValue[DemoOutput],
Print[table, " - the best #dilation is ",
StringRiffle[Table[StringJoin[ToString[table[[i]][[1]]], " for ",ToString[table[[i]][[2]]], " runs"],{i, Length[table]}],", "]];,
Print[table];
];
If[OptionValue[DemoOutput],
Print[TotalCount, " - there are a total of ", TotalCount," points"];,
Print[TotalCount];
];
table = DeleteDuplicates[Transpose[TotalBestDSDs][[2]]];
table = Table[{table[[i]],
Count[Transpose[TotalBestDSDs][[2]], table[[i]]]}, {i,Length[table]}];
If[OptionValue[DemoOutput],
Print[table, " - The sequence of DSDim(s) is ",StringRiffle[Table[StringJoin[ToString[table[[i]][[1]]]," for ",ToString[table[[i]][[2]]], " runs"], {i, Length[table]}],", "]];,
Print[table];
];
Return[{SpecPointsPair,TotalBestDSDs}]];



(* ::Section:: *)
(*End Package*)


End[]
EndPackage[]


(* ::Section:: *)
(*Version History*)


(* ::Text:: *)
(*Version history for NCSE. *)
(**)
(*22Dec 2020 Version 1.0.0*)
(**)
(*Created the DilationAssessment.m file.*)
