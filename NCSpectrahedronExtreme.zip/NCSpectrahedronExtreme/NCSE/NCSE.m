(* ::Package:: *)

(* ::Section:: *)
(*NCSE 2.3.0*)


BeginPackage["NCSE`",{"NCReplace`","SDP`"}]

Get["NCSE.usage"];
X;
Y;
Z;
gamma;
BadNullNumerics;

Begin["`Private`"];



(* ::Section:: *)
(*Basic Functions*)


(* ::Text:: *)
(*This section includes the basic functions used in the notebook. Examples include direct sum computation of a list of matrices, LMI evaluation and manipulation (such as Eigenvalue calculations), linear functional generation, random matrix generation, and and basic Variable Generation. The basic variables are used in Extreme Point generation and classification. *)


(* ::Input::Initialization:: *)
(* NCSEVersion returns the working version of NCSE *)
NCSEVersion[]:="The current version of NCSE is 2.3.0"


(* EqualsZero sets equation\[Equal]0 *)
EqualsZero[equation_]:=Equal[equation,0]

(* Takes the upper triangular portion of a matrix and flattens it *)
TakeUpper[mat_?SquareMatrixQ]:=Join@@Table[mat[[i,j]],{i,Length[mat]},{j,i,Length[mat]}];


(* Takes the direct sum of a list *)
DirectSum[list_]:=Block[{M},
M=list[[1]];
Do[M=ArrayFlatten[{{M,0},{0,list[[i+1]]}}],{i,Length[list]-1}];
M]

(* Computes the direct sum of a list of tuples *)
DirectSumTuple[tuples_]:=Block[{g,T},
g=Length[tuples[[1]]];
T=Table[DirectSum[tuples[[All,j]]],{j,g}];
T]


JoinMatrix[list_,n_]:=Block[{i,matrix},
If[Length[list]==1,Return[list[[1]]]];
matrix=Join[list[[1]],list[[2]],n];
For[i=3,i<= Length[list],i++,matrix=Join[matrix,list[[i]],n]];
Return[matrix];
]


(* LMI computes the linear pencil determined by the tuples A and X. LMI determines what type of pencil to generate depending on the input sizes for A and X. There are 2 main cases.
1. If Length[A]\[Equal]Length[X], then LMI computes the monic linear pencil L_A (X)= I-A[[1]] \otimes X[[1]] -...- A[[g]] \otimes X[g]
2. If Length[A]\[Equal]Length[X]+1  and k:=Length[A[[2]]]*Length[X[[1]]]/Length[A[[1]]] is an integer, then LMI computes the nonmonic linear pencil   A[[1]] \otimes I_k - A[[2]] \otimes X[[1]] - ... - A[[g+1]] \otimes X[g]

Case 2 can be viewed as having two subcases. One is the free nonmonic LMI case, and the other is the (semi) nonfree nonmonic LMI case. 

If A and X do not meet condition 1 or condition 2, then LMI returns: The input size for the tuples A and X is not supported. *)
LMI[A_,X_]:=Block[{k},
If[Length[A]<Length[X],
Return["The input size for the tuples A and X is not supported"]];
If[SameQ[Length[A],Length[X]],
Return[KroneckerProduct[IdentityMatrix[Length[A[[1]]]],IdentityMatrix[Length[X[[1]]]]]-Sum[KroneckerProduct[A[[i]],X[[i]]],{i,Length[X]}]],
k=Length[A[[2]]]*Length[X[[1]]]/Length[A[[1]]];
If[SameQ[Length[A],Length[X]+1] && Element[k,Integers],
Return[KroneckerProduct[A[[1]],IdentityMatrix[k]]-Sum[KroneckerProduct[A[[i+1]],X[[i]]],{i,Length[X]}]]]];
Return["The input size for the tuples A and X is not supported"]]

(* Computes the linear part of L_A (X). That is, computes A[[1]] \otimes X[[1]] +...+ A[[g]] \otimes X[g] *)
Lambda[A_,X_]:=Sum[KroneckerProduct[A[[i]],X[[i]]],{i,Length[X]}]


(*Maps a n x n complex matrix to its 2n x 2n real embedding *)
Cto2R[mat_]:=Block[{A,B},
	A=Re[mat];
	B=Im[mat];
	Return[ArrayFlatten[{{A,B},{-B,A}}]]]
	
(* Maps a complex matrix to a two tuple of 2n x 2n real matrices *)
Cto2R2V[mat_]:=Block[{A,B},
	A=Re[mat];
	B=Im[mat];
Return[{ArrayFlatten[{{A,0},{0,A}}],ArrayFlatten[{{0,B},{-B,0}}]}]]


(* Calculates eigenvalues of LMI evaluated on X *)
PencilEig[A_,X_]:=Eigenvalues[LMI[A,X]];


(* Generates a symbolic symmetric g-tuple of n x n matrices*)
MakeX[g_,n_]:=Block[{X},
Table[If[i<j,X[k,i,j],X[k,j,i]],{k,g},{i,n},{j,n}]]

(* Generates a sybolic symmetric n x n matrix*)
MakeY[n_]:=Block[{Y},
Table[If[i<j,Y[i,j],Y[j,i]],{i,n},{j,n}]]

(* Generates a symbolic symmetric g-tuple of n x n matrices*)
MakeZ[g_,n_]:=Block[{Z},
Table[If[i<j,Z[k,i,j],Z[k,j,i]],{k,g},{i,n},{j,n}]]

(* Generates a symbolic g-tuple of n x 1 matrices*)
MakeZArv[g_,n_]:=Block[{Z},
Table[{Table[Z[k,j],{j,n}]},{k,g}]]


(* Converts a flattened g-tuple of n x 1 matrices back to a g-tuple of n x 1 matrices *)
VecToBeta[vec_,g_,n_]:=Table[{vec[[(h-1)*n+i]]},{h,1,g},{i,1,n}]

(* Converts a flattened g-tuple of n x n matrices back to a g-tuple of n x n matrices ?? This doesn't appear to be working as intended, but it also appears that it is never used. Delete it?*)
VecToSymBeta[vec_,g_,n_]:=Table[{vec[[(h-1)*n+i]]},{h,n,g},{i,1,n}]


(* Generates a random linear functional on symmetric g-tuples of n x n matrices *)
Options[MakeFunctionalReal]:={WeightVector-> Null}
MakeFunctionalReal[g_,n_,OptionsPattern[]]:=Block[{Functional,FunctionalLength,FunctionalVariables,FunctionalWeight,WeightVector},

(* A functional will be made by taking innerproduct of FunctionalVariables with a weight vector FunctionalWeight *)
FunctionalVariables=Variables[MakeX[g,n]];
FunctionalLength=Length[FunctionalVariables];

(* The following if loop determines how to make FunctionalWeight. First is a check if the Option WeightVector is a vector which has the same number of entries as variables in FunctionalVariables *)
If[SameQ[Head[OptionValue[WeightVector]],List]&&SameQ[Length[OptionValue[WeightVector]],FunctionalLength],
FunctionalWeight=OptionValue[WeightVector],

(* If Option WeightVector is NOT a vector which has the same number of entries as variables in FunctionalVariables, check if WeightVector has the default value of Null. In this case, create a random weight vector *)
If[SameQ[OptionValue[WeightVector],Null],
FunctionalWeight=Table[RandomReal[{-1,1}],{k,FunctionalLength}],

(* If Option WeightVector does not have either of the previous forms, create a random FunctionalWeight, but also print a Warning to the user that their option does not have the correct form *)

FunctionalWeight=Table[RandomReal[{-1,1}],{k,FunctionalLength}];
Print["WARNING: The WeightVector Option does not have the correct format. Defaulted to making a random linear functional"];];];
Functional=Dot[FunctionalWeight,FunctionalVariables];
Return[{FunctionalWeight,Functional}]]

(*Generates a random linear functional with rational coefficients on symmetric g-tuples of n times n matrices *)
Options[MakeFunctionalRational]:={Distribution->"uniform", WeightVector-> Null,IntegerRange-> {-200000,200000},StepDenominator-> 100000 }
MakeFunctionalRational[g_,n_,OptionsPattern[]]:=Block[{X,Functional,FunctionalLength,FunctionalVariables,FunctionalWeight,WeightVector,Distribution,IntegerRange,StepDenominator},

(* A functional will be made by taking innerproduct of FunctionalVariables with a weight vector FunctionalWeight *)
FunctionalVariables=Variables[MakeX[g,n]];
FunctionalLength=Length[FunctionalVariables];

(* The following if loop determines how to make FunctionalWeight. First is a check if the Option WeightVector is a vector which has the same number of entries as variables in FunctionalVariables *)
If[SameQ[Head[OptionValue[WeightVector]],List]&&SameQ[Length[OptionValue[WeightVector]],FunctionalLength],
FunctionalWeight=OptionValue[WeightVector],

(* If Option WeightVector is NOT a vector which has the same number of entries as variables in FunctionalVariables, check if WeightVector has the default value of Null. In this case, create a random weight vector *)
If[SameQ[OptionValue[WeightVector],Null],
	If[OptionValue[Distribution]=="uniform",FunctionalWeight=Table[RandomInteger[{Min[OptionValue[IntegerRange]],Max[OptionValue[IntegerRange]]}]/OptionValue[StepDenominator],{k,FunctionalLength}]];
	If[OptionValue[Distribution]=="gaussian",FunctionalWeight=Table[RandomReal[NormalDistribution[0,1]],{k,FunctionalLength}]];
,

(* If Option WeightVector does not have either of the previous forms, create a random FunctionalWeight, but also print a Warning to the user that their option does not have the correct form *)

FunctionalWeight=Table[RandomInteger[{Min[OptionValue[IntegerRange]],Max[OptionValue[IntegerRange]]}]/OptionValue[StepDenominator],{k,FunctionalLength}];
Print["WARNING: The WeightVector Option does not have the correct format."];
;];];
Functional=Dot[FunctionalWeight,FunctionalVariables];
Return[{FunctionalWeight,Functional}]]


(* Indices are switched in the problem. This is a tool for switching back *)
FindIndex[n_,k_,i_,j_]:=(k-1)*(n^2+n)/2+Sum[n+1-s,{s,i}]+j-n

(* Indices are switched in the problem. This is a tool for switching back in the case X1 is diagonal*)
FindIndexDiag[n_,k_,i_,j_]:=If[k==1,i,((k-1)*(n^2+n)/2+Sum[n+1-s,{s,i}]+j-n)-Binomial[n+1,2]+n]


(* Rule for subsituting in to Xg after running the SDP *)
MakeXRule[g_,n_]:=Flatten[Table[X[k,i,j]->  Y[[1,1,FindIndex[n,k,i,j]]],{k,g},{j,n},{i,j}]]

(* Finds the variables the SDP is in from the input Xg. Stores this in SDPVars *)
MakeSDPVars[MatrixTuple_]:=DeleteDuplicates[Flatten[MatrixTuple]];


(* Makes a column vector beta that will be used in the test to see if the extreme point is arverson *)
MakeBeta[g_,n_]:=Block[{beta},
Table[Transpose[{Table[beta[k,j],{j,n}]}],{k,g}]]

(* Makes a symmetric beta to be used in the test to see if beta is Euclidean *)
MakeSymBeta[g_,n_]:=Block[{SymBeta},
Table[If[i<j,SymBeta[k,i,j],SymBeta[k,j,i]],{k,g},{i,n},{j,n}]]

(* Create a list of zeros with the appriate size to check beta=0 against for the Euclidean test *)
MakeZeroSymBetaList[g_,n_]:={{Table[0,{k,g*(n(n+1))/2}]}}

(* Create a list of zeros with the appriate size to check beta=0 against for the Arveson test *)
MakeZeroBetaList[g_,n_]:={{Table[0,{k,g*n}]}}

(* Makes the matrix {{Extremepoint, Beta},{Transpose[Beta],0}}   *)
MakeExtendX[Xg_,beta_,g_]:=Table[ArrayFlatten[{{Xg[[k]],beta[[k]]},{Transpose[beta[[k]]],0*IdentityMatrix[Length[beta[[1,1]]]]}}],{k,g}]


(* randmat generates a random r by c matrix with inputs which are rational numbers of the form j/10 for -10\[LessEqual] j\[LessEqual] 10 *)
randmat[r_,c_]:=Table[RandomInteger[{-10,10}]/10,{i,r},{j,c}]


(* Makegamma generates a g tuple of gamma n x n symmetric matrices with entires gamma[k,i,j]. *)
Makegamma[g_,n_]:=Block[{gamma},
Table[If[i<j,gamma[k,i,j],gamma[k,j,i]],{k,g},{i,n},{j,n}]]

MakeExtendXwithGamma[Xg_,beta_,g_]:=Block[{ExtendX,betaLength,gamma,gammag},
betaLength=Length[beta[[1,1]]];
gammag=Makegamma[g,betaLength];
ExtendX=Table[ArrayFlatten[{{Xg[[k]],beta[[k]]},{Transpose[beta[[k]]],gammag[[k]]}}],{k,g}]]


(* Determines the dimension of the null space of a numerical matrix using Cutoff as the value to treat as zero *)
NullDimension[Mat_,Cutoff_]:=Count[Chop[Eigenvalues[Mat],Cutoff],0]

(* Determine Nulls attempts to decide what values should be called zero in a give list. The function looks for small values which have a large gap from the next value. By default, if the gap is not sufficiently large or small, the function reports that the numerics are poor. DetermineNull returns the index of the largest element of the list which is considered zero when the list is ordered from greatest to smallest absolute value. *)
Options[DetermineNull]:={NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2)}
DetermineNull[list_,EigMagTol_,EigGapTol_,OptionsPattern[]]:=Block[{AbsList,NullFound,iterate,EigGap,BestGap,NumericsAssessment,NumericsAssessmentTol,BadNumerics},
AbsList=Map[Abs,list];
AbsList=Sort[AbsList,Greater];
If[AbsList[[1]]<= EigMagTol,
Return[{1,0}]];
iterate=2;
NullFound=False;
BestGap=Infinity;
While[NullFound==False &&iterate<= Length[AbsList],
If[Abs[AbsList[[iterate]]]<= EigMagTol&&AbsList[[iterate]]/AbsList[[iterate-1]]<=  EigGapTol,
NullFound=True;
BestGap=AbsList[[iterate]]/AbsList[[iterate-1]],
If[AbsList[[iterate]]/AbsList[[iterate-1]]<BestGap,BestGap=AbsList[[iterate]]/AbsList[[iterate-1]]];
iterate=iterate+1;]];
If[SameQ[NullFound,True],Return[{iterate,BestGap}],If[SameQ[OptionValue[NumericsAssessment],True]&&BestGap*OptionValue[NumericsAssessmentTol]< EigGapTol,
Return[{BadNumerics,BestGap}],If[SameQ[OptionValue[NumericsAssessment],True]&&AbsList[[Length[list]]]<10^(-2)* EigMagTol,Return[{BadNumerics,BestGap}], Return[{False,BestGap}]]]]]

Options[RandSymMat]:={Distribution-> "UniformRational",DistributionBounds-> {-100,100},DistributionNormalization-> 1/200,DistributionVariance-> 1,DistributionMean-> 0};
RandSymMat[n_,OptionsPattern[]]:=Block[{mat,Distribution,DistributionBounds,DistributionNormalization,DistributionVariance,DistributionMean},
If[OptionValue[Distribution]=="Normal",
mat=RandomVariate[NormalDistribution[OptionValue[DistributionMean],OptionValue[DistributionVariance]],{n,n}];,
If[OptionValue[Distribution]=="Uniform",
mat=OptionValue[DistributionNormalization]*RandomReal[OptionValue[DistributionBounds],{n,n}];,
mat=OptionValue[DistributionNormalization]*RandomInteger[OptionValue[DistributionBounds],{n,n}];]];
Return[mat+Transpose[mat]]]

Options[RandSymTuple]:={Distribution-> "UniformRational",DistributionBounds-> {-100,100},DistributionNormalization-> 1/200,DistributionVariance-> 1,DistributionMean-> 0};
RandSymTuple[g_,n_,OptionsPattern[]]:=Block[{tup,Distribution,DistributionBounds,DistributionNormalization,DistributionVariance,DistributionMean},
tup=Table[RandSymMat[n,Distribution-> OptionValue[Distribution],DistributionBounds-> OptionValue[DistributionBounds],DistributionNormalization-> OptionValue[DistributionNormalization],DistributionVariance-> OptionValue[DistributionVariance],DistributionMean-> OptionValue[DistributionMean]],{i,g}];
Return[tup]]

Options[RandSpecInteriorPt]:={Distribution-> "UniformRational",TupleDistributionBounds-> {-100,100},TupleDistributionNormalization-> 1/200,TupleDistributionVariance-> 1,TupleDistributionMean-> 0,ScaleDistributionGranularity-> 100,MaxIters-> 1000,FixedScaleConstant->False,ScaleConstant-> 1/2};
RandSpecInteriorPt[A_,n_,OptionsPattern[]]:=Block[{g,tup,PDQ,InteriorQ,Distribution,TupleDistributionBounds,TupleDistributionNormalization,TupleDistributionVariance,TupleDistributionMean,ScaleDistributionGranularity,DistributionVariance,DistributionMean,DistributionBounds,DistributionNormalization,MaxIters,Iters,ScaleConst,FixedScaleConstant,ScaleConstant},
g=Length[A];
PDQ=PositiveDefiniteMatrixQ;
Iters=0;
tup=RandSymTuple[g,n,Distribution-> OptionValue[Distribution],DistributionBounds-> OptionValue[TupleDistributionBounds],DistributionNormalization-> OptionValue[TupleDistributionNormalization],DistributionMean-> OptionValue[TupleDistributionMean],DistributionVariance-> OptionValue[TupleDistributionVariance]];
InteriorQ=PDQ[LMI[A,tup]//N];
While[InteriorQ==False&&Iters<OptionValue[MaxIters],
ScaleConst=If[OptionValue[FixedScaleConstant],OptionValue[ScaleConstant],
If[OptionValue[Distribution]=="Uniform"||OptionValue[Distribution]=="Normal",
RandomReal[{0,1}],
RandomInteger[{1,OptionValue[ScaleDistributionGranularity]-1}]/OptionValue[ScaleDistributionGranularity]]];
If[Iters==OptionValue[MaxIters]-1,tup=0*tup,
tup=ScaleConst*tup];
InteriorQ=PDQ[LMI[A,tup]//N];
Iters=Iters+1;
];
Return[tup]]

Options[SubspaceDistance]:={DistanceMeasure-> "PrincipalAngle"};
SubspaceDistance[U_,V_,OptionsPattern[]]:=Block[{DistanceMeasure,UIso,VIso,n,nU,nV,mU,mV,DistancesList,ProductSingularValues},
{nU,mU}=Dimensions[U];
{nV,mV}=Dimensions[V];
If[nU!=nV,Return["Dimension Mismatch: The given matrices do not have the same number of rows."],n=nU];
If[UnitaryMatrixQ[U],UIso=U,
UIso=SingularValueDecomposition[U][[1]];
UIso=UIso[[All,1;;mU]]];
If[UnitaryMatrixQ[V],VIso=V,
VIso=SingularValueDecomposition[V][[1]];
VIso=VIso[[All,1;;mV]]];
If[OptionValue[DistanceMeasure]=="OrthComplementNorm",
DistancesList=Map[Norm,Transpose[UIso-VIso . Transpose[VIso] . UIso]];,
ProductSingularValues=SingularValueList[Transpose[UIso] . VIso];
ProductSingularValues=Join[ProductSingularValues,Table[0,{i,Abs[mU-mV]}]];
DistancesList=Map[ArcCos,ProductSingularValues];];
DistancesList=Sort[Re[DistancesList],Less];
Return[DistancesList]]



(* ::Section::Closed:: *)
(*Free Tangent Planes and Commutants*)


(* ::Text:: *)
(*This section contains functions for computation the dimension of of tangent planes and commutants*)


(* ::Input::Initialization:: *)
(* TanDimGuess computes guess for nontrivial tangent space dimension based on g,n, and k where k is the dimension of the kernel of L_A(X). This will not always be correct. *)
TanDimGuess[g_,n_,k_]:=Block[{},Return[n*(n+1)*g/2-n*(n-1)/2-(k+1)*k/2]]

ConjCoefArray[mat_]:=Block[{n,m,numsymvars,CoefArray,i,j,ijcoefs,tarspacedim},
{n,m}=Dimensions[mat];
CoefArray=Table[Flatten[Table[If[k==l,mat[[k,j]]*mat[[k,i]],mat[[k,j]]*mat[[l,i]]+mat[[l,j]]*mat[[k,i]]],{k,n},{l,k,n}]],{i,m},{j,i,m}];
numsymvars=n (n+1)/2;
tarspacedim=m (m+1)/2;
CoefArray=ArrayReshape[CoefArray,{tarspacedim,numsymvars}];
Return[CoefArray]]



(* FreeTangentNumerical computes the dimension of the tangent plane to the crease on the free spectrahedron defined by A at the tuple X *)
Options[FreeTangentNumerical]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2)}
FreeTangentNumerical[A_,X_,OptionsPattern[]]:=Block[{Alin,LamEvalUpper,g,n,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZEucMat,TangentEqsBasic,TangentEqs,TangentEqsTable,TangentSystemMat,TangentSystemEigVals,TangentSystemEigVecs,ZSolExistQ,ZSolConfidence,TangentQ,BadSystemNumerics,LamEvalCoefArray,ConjCoefs},
g=Length[X];
n=Length[X[[1]]];
If[SameQ[Length[A],Length[X]],Alin=A,Alin=A[[2;;All]]];
{LMIEigenvalues,LMIEigenvectors}=Eigensystem[LMI[A,X]];
{NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[NullVecStartIterate,False],Return[{False,NullConfidence,False,LMIEigenvalues}],
If[SameQ[NullVecStartIterate,BadNumerics],Return[{BadNullNumerics,{NullConfidence,BadNullNumerics}}],
NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
ZEucMat=MakeZ[g,n];
LamEvalUpper=TakeUpper[Lambda[Alin,ZEucMat]];
LamEvalCoefArray=Normal[CoefficientArrays[Flatten[LamEvalUpper]],Variables[ZEucMat]][[2]]];
ConjCoefs=ConjCoefArray[NullInclusionMatrix];
TangentSystemMat=ConjCoefs . LamEvalCoefArray;
{TangentSystemEigVals,TangentSystemEigVecs}=Eigensystem[Transpose[TangentSystemMat] . TangentSystemMat];
{ZSolExistQ,ZSolConfidence}=DetermineNull[TangentSystemEigVals,OptionValue[EigMagTol]*10^(-3),OptionValue[EigGapTol]*10^(-3),NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
TangentQ=If[SameQ[False,ZSolExistQ],0,
If[SameQ[ZSolExistQ,BadNumerics],BadSystemNumerics,Length[TangentSystemEigVals]-ZSolExistQ+1-n*(n-1)/2]];
Return[TangentQ]]]

(* FreeTangentBasis computes a basis for the free tangent space. The basis is presented as a basis for the Trivial Tangent space and for the orthogonal complemnt of the Trivial tangent space (relative to the full Free tangent space) *)
Options[FreeTangentBasis]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2)}
FreeTangentBasis[A_,X_,OptionsPattern[]]:=Block[{Alin,LamEvalUpper,g,n,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZEucMat,TangentEqsBasic,TangentEqs,TangentEqsTable,TangentSystemMat,TangentSystemEigVals,TangentSystemEigVecs,ZSolExistQ,ZSolConfidence,TangentQ,BadSystemNumerics,LamEvalCoefArray,ConjCoefs,TangentBasisPreVecs,TangentBasisVecs,TrivialBasisVecs,SkewSymsBasis,TrivialBasisTuples,AllBasisVecs,TanOrthoBasis,PLamEvalP,TanBasisDim,TanBasisTuples,NonTrivialBasisTuples},
(* Determine g and n *)
g=Length[X];
n=Length[X[[1]]];
(* Determine if Pencil is monic or nonmonic *)
If[SameQ[Length[A],Length[X]],Alin=A,Alin=A[[2;;All]]];
(* Determine nullspace of LMI[A,X] *)
{LMIEigenvalues,LMIEigenvectors}=Eigensystem[LMI[A,X]];
{NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
(* Logic to handle numerically illconditioned cases *)
If[SameQ[NullVecStartIterate,False],Return[{False,NullConfidence,False,LMIEigenvalues}],
If[SameQ[NullVecStartIterate,BadNumerics],Return[{BadNullNumerics,{NullConfidence,BadNullNumerics}}],
(* form inclusion matrix mapping onto kernel of LMI[A,X] *)
NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
	(* Make a variable representing a g-tuple of symmetric betas and evaluate the Free Tangent system on this tuple *)
ZEucMat=MakeZ[g,n];
PLamEvalP=Simplify[Transpose[NullInclusionMatrix] . Lambda[Alin,ZEucMat] . NullInclusionMatrix];
(* Create a matrix representing the Free Tangent System and Find its nullspace *)
LamEvalUpper=TakeUpper[PLamEvalP];
LamEvalCoefArray=Normal[CoefficientArrays[Flatten[LamEvalUpper],Variables[ZEucMat]][[2]]]];
{TangentSystemEigVals,TangentSystemEigVecs}=Eigensystem[Transpose[LamEvalCoefArray] . LamEvalCoefArray];
{ZSolExistQ,ZSolConfidence}=DetermineNull[TangentSystemEigVals,OptionValue[EigMagTol]*10^(-3),OptionValue[EigGapTol]*10^(-3),NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
(* Logic for numerically illconditioned cases *)
If[SameQ[False,ZSolExistQ],Return["The free tangent plane at X does not exist"],
If[SameQ[ZSolExistQ,BadNumerics],Return[BadSystemNumerics],
TangentBasisPreVecs=TangentSystemEigVecs[[ZSolExistQ;;Length[TangentSystemEigVecs]]];
TanBasisDim=Length[TangentBasisPreVecs]];];
If[n==1,
(* If n=1, Convert basis vectors find to a tuple of matrices. *)
TangentBasisVecs=Table[VecToBeta[TangentBasisPreVecs[[i]],g,n],{i,Length[TangentBasisPreVecs]}];
TrivialBasisVecs={};
NonTrivialBasisTuples=Table[ShortVecToSymBeta[TangentBasisVecs[[i]],g,n],{i,Length[TangentBasisVecs]}],
(* If n>1, compute the Trivial tangent space, and form an orthonormal basis for the Free Tangent Space (in the upper triangular innerproduct) with leading vectors spanning the Trivial Tangent space *)
SkewSymsBasis=SkewSymmetricBasis[n];
TrivialBasisTuples=Table[LeftMultTuple[SkewSymsBasis[[i]],X]-RightMultTuple[SkewSymsBasis[[i]],X],{i,Length[SkewSymsBasis]}];
TrivialBasisVecs=Map[TakeUpperTuple,TrivialBasisTuples];
(*TangentBasisPreVecs=Table[Flatten[Map[SymMatFromShortVec,ArrayReshape[TangentBasisPreVecs[[i]],{g,n*(n+1)/2}]]],{i,Length[TangentBasisPreVecs]}]*);
AllBasisVecs=Join[TrivialBasisVecs,TangentBasisPreVecs][[1;;TanBasisDim]];
TanOrthoBasis=Orthogonalize[AllBasisVecs];
TanBasisTuples=Table[ShortVecToSymBeta[TanOrthoBasis[[i]],g,n],{i,Length[TanOrthoBasis]}];
(* Form Tuples corresponding to the vectors which form an orthonormal basis for the trivial and the nontrivial tangent space *)
TrivialBasisTuples=Table[TanBasisTuples[[i]],{i,Length[TrivialBasisVecs]}];
NonTrivialBasisTuples=Table[TanBasisTuples[[i]],{i,Length[TrivialBasisVecs]+1,Length[TanBasisTuples]}];]];
Return[{TrivialBasisTuples,NonTrivialBasisTuples}]]

(* FreeTangentMemberTest computes the norm of the free tangent system Transpose[P_X] Lambda[A,B] P_X. This serves as a membership test for the Free Tangent space. *)
Options[FreeTangentMemberTest]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2)}
FreeTangentMemberTest[A_,X_,beta_,OptionsPattern[]]:=Block[{Alin,LamEvalUpper,g,n,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZEucMat,TangentEqsBasic,TangentEqs,TangentEqsTable,TangentSystemMat,TangentSystemEigVals,TangentSystemEigVecs,ZSolExistQ,ZSolConfidence,TangentQ,BadSystemNumerics,LamEvalCoefArray,ConjCoefs,TangentBasisPreVecs,TangentBasisVecs,TrivialBasisVecs,SkewSymsBasis,TrivialBasisTuples,AllBasisVecs,TanOrthoBasis},
g=Length[X];
n=Length[X[[1]]];
If[SameQ[Length[A],Length[X]],Alin=A,Alin=A[[2;;All]]];
{LMIEigenvalues,LMIEigenvectors}=Eigensystem[LMI[A,X]];
{NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[NullVecStartIterate,False],Return[{False,NullConfidence,False,LMIEigenvalues}],
If[SameQ[NullVecStartIterate,BadNumerics],Return[{BadNullNumerics,{NullConfidence,BadNullNumerics}}],
NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
Return[Norm[Transpose[NullInclusionMatrix] . Lambda[A,beta] . NullInclusionMatrix]/TupleNorm[beta]]]]]

(* EuclideanPLambdaP computes the inclusion P from the kerenl of L_A (X) to R^{ng}. In addition, a matrix representing the linear map P^T.Lambda[A,\cdot].P: SM_n (R)^g \to R^{k \times k} is returned. Here k is the dimension of the kernel of L_A (X). The kernel of this linear map is the tangent plane to the crease *)
EuclideanPLambdaP[A_,X_]:=Block[{g,n,Alin,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZEucMat,NullContainmentEqsBasic,NullContainmentEqs,NullContainmentTable,NullSystemMat,NullSystemEigVals,NullSystemEigenVecs,ZSolExistQ,ZSolConfidence,EuclideanQ,BadSystemNumerics},
g=Length[X];
n=Length[X[[1]]];
Alin=A//N;
{LMIEigenvalues,LMIEigenvectors}=Eigensystem[LMI[A,X]];
{NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,10^(-6),10^(-5),NumericsAssessment->True,NumericsAssessment->10^(-2)];
NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
ZEucMat=MakeZ[g,n];

NullContainmentEqsBasic=Transpose[NullInclusionMatrix] . Lambda[Alin,ZEucMat] . NullInclusionMatrix//Expand;
NullContainmentEqs=DeleteCases[DeleteCases[Flatten[NullContainmentEqsBasic],0.],0];
NullContainmentTable=Table[NullContainmentEqs[[i]]==0,{i,1,Length[NullContainmentEqs]}];
NullSystemMat=N[Normal[CoefficientArrays[NullContainmentTable,Variables[ZEucMat]]][[2]]];
Return[{NullInclusionMatrix,NullSystemMat}]
]








(* CommutantDimension determines the dimension of the commutant of the tuple X={X[[1]],X[[2]],...,X[[g]]}. by determining the dimension of the null space of the linear system Y.X[[i]]-X[[i]].Y\[Equal]0 for i=1,...,g. *)
Options[CommutantDimension]:={EigMagTol-> 10^(-9),EigGapTol-> 10^(-8),ChopCutoff->10^(-8),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2)}
CommutantDimension[X_,OptionsPattern[]]:=Block[{g,n,YMat,CommutantEqs,CommutantSystemMat,CommutantSystemEigVals,CommutantSystemEigVecs,CommSolExistQ,CommSolConfidence,EigMagTol,EigGapTol,ChopCutoff,NumericsAssessment,NumericsAssessmentTol,CommDim,BadNumerics,BadSystemNumerics},
g=Length[X];
n=Length[X[[1]]];
YMat=MakeY[n];
CommutantEqs=Map[EqualsZero,DeleteCases[Chop[Flatten[Table[YMat . X[[i]]-X[[i]] . YMat,{i,g}]],OptionValue[ChopCutoff]],0]];
If[Length[CommutantEqs]==0,Return[{n*(n+1)/2,0}]];
CommutantSystemMat=N[Normal[CoefficientArrays[CommutantEqs,Variables[YMat]]][[2]]];
{CommutantSystemEigVals,CommutantSystemEigVecs}=Eigensystem[Transpose[CommutantSystemMat] . CommutantSystemMat];
{CommSolExistQ,CommSolConfidence}=DetermineNull[CommutantSystemEigVals,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[CommSolExistQ,BadNumerics],CommDim=BadSystemNumerics,CommDim=Length[CommutantSystemEigVals]-CommSolExistQ+1];
Return[{CommDim,CommSolConfidence}]]



(* ::Section::Closed:: *)
(*Near Flat Assesment Experiment*)


(* ::Text:: *)
(*This section contains functions for experiments on near flat dimension conjectures *)


(* NearFlatExperimentRandomP generates random inclusion matrices then runs NearFlatAssessmentGivenP on the collection of random inclusions and gives a table containing the data from the runs *)
Options[NearFlatExperimentRandomP]:={GapOrMag->"Mag",PrintConjectureSummary-> True,PrintTable-> True,NumAnglesToDisplay-> 2,NumDigitsToDisplay-> 1,PrintParameterSummary-> True}
NearFlatExperimentRandomP[A_,n_,k_,numIters_,EucKerRatio_,ArvKerRatio_,RowLinDependenceTol_,AngleConjTol_,OptionsPattern[]]:=Block[{ConjSumCol,d,DataTable,ExpNumCol,g,GapOrMag,InclusionMats,NearFlatData,NearFlatDataDisplay,NumAnglesToDisplay,NumDigitsToDisplay,PrintConjectureSummary,PrintParameterSummary,PrintTable,SuccessfulBaseConjNum,SuccessfulAngleConjNum,SuccessfulStrongConjNum,TableHead},
g=Length[A];
d=Length[A[[1]]];
(* Generate random inclusion matrices *)
InclusionMats=Table[RandomIsometry[n*d,k],{i,numIters}];
(* Run NearFlatAssessmentGivenP *)
NearFlatData=Table[NearFlatAssessmentGivenP[A,InclusionMats[[i]],EucKerRatio,ArvKerRatio,RowLinDependenceTol,NumAnglesToDisplay-> OptionValue[NumAnglesToDisplay]],{i,numIters}];
(* Generate Table *) 
NearFlatDataDisplay=Table[NumberForm[NearFlatData[[i,j]],OptionValue[NumDigitsToDisplay]],{i,Length[NearFlatData]},{j,Length[NearFlatData[[1]]]}];
TableHead={{"EX","Conj","Arv","rank","Euc","Principal","ArvSols","EucRows","EucSols"},{"No","Sum","Sol","EucRow","Sol","Angles","Tols","Tols","Tols"}};
ExpNumCol=Table[{i},{i,numIters}];
ConjSumCol=Table[If[NearFlatData[[i,2]]==0,{{"N","N","N"}},
If[Min[NearFlatData[[i,4]]]>AngleConjTol,{{"Y","N","N"}},
If[(NearFlatData[[i,1]]>NearFlatData[[i,2]]&&NearFlatData[[i,4,2]]<AngleConjTol)||(NearFlatData[[i,1]]==NearFlatData[[i,2]]&&NearFlatData[[i,4,1]]<AngleConjTol),{{"Y","Y","Y"}},{{"Y","Y","N"}}]]],{i,numIters}];
SuccessfulBaseConjNum=numIters-Count[ConjSumCol,{{"N","N","N"}}];
SuccessfulAngleConjNum=numIters-Count[ConjSumCol,{{"N","N","N"}}]-Count[ConjSumCol,{{"Y","N","N"}}];
SuccessfulStrongConjNum=Count[ConjSumCol,{{"Y","Y","Y"}}];
DataTable=Join[TableHead,ArrayFlatten[{{ExpNumCol,ConjSumCol,NearFlatDataDisplay}}]];
If[SameQ[OptionValue[PrintParameterSummary],True],
Print[" "];
Print[StringForm["The values for {g,n,d,k} are ``.",{g,n,d,k}]];
Print[StringForm["The bean count g*n-d*k for this experiment is ``.",g*n-d*k]];];
If[SameQ[OptionValue[PrintConjectureSummary],True],
Print[" "];Print[StringForm["`` out of `` experiments passed basic near flat existence conjecture conjecture.",SuccessfulBaseConjNum,numIters]];
Print[StringForm["The proportion of experiments which passed the base conjecture is ``.",NumberForm[N[SuccessfulBaseConjNum/numIters],OptionValue[NumDigitsToDisplay]]]];
Print[" "];Print[StringForm["`` out of `` experiments passed the near flat rows vs dilation subspace angle conjecture.",SuccessfulAngleConjNum,numIters]];
Print[StringForm["The proportion of experiments which passed the base conjecture is ``.",NumberForm[N[SuccessfulAngleConjNum/numIters],OptionValue[NumDigitsToDisplay]]]];
Print[" "];Print[StringForm["`` out of `` experiments passed the near flat rows approximately contained by dilation subspace conjecture.",SuccessfulStrongConjNum,numIters]];
Print[StringForm["The proportion of experiments which passed the base conjecture is ``.",NumberForm[N[SuccessfulStrongConjNum/numIters],OptionValue[NumDigitsToDisplay]]]];
Print[" "];];
If[SameQ[OptionValue[PrintTable],True],Print[MatrixForm[DataTable]]];
Return[NearFlatData]];

(* NearFlatExperiment generates random interior points of the given free spectrahedron of size n-dilNum, then dilates those points dilNum times. NearFlatAssessment is then run on the collection of dilations *)
Options[NearFlatExperiment]:={GapOrMag->"Mag",PrintConjectureSummary-> True,PrintTable-> True,NumAnglesToDisplay-> 2,NumDigitsToDisplay-> 1,PrintParameterSummary-> True}
NearFlatExperiment[A_,n_,dilNum_,numIters_,EucKerRatio_,RowLinDependenceTol_,AngleConjTol_,OptionsPattern[]]:=Block[{betaMethod,ConjSumCol,d,DataTable,DilationPts,ExpNumCol,g,GapOrMag,InteriorPts,NearFlatData,NearFlatDataDisplay,NumAnglesToDisplay,NumDigitsToDisplay,PrintConjectureSummary,PrintParameterSummary,PrintTable,PtSizeCol,RandomBeta,SuccessfulBaseConjNum,SuccessfulAngleConjNum,SuccessfulStrongConjNum,TableHead},
g=Length[A];
d=Length[A[[1]]];
(* Logic check that n-dilNum is positive *)
If[dilNum>= n,Return["Given dilNum is too large. Must have dilNum < n "]];
InteriorPts=Table[RandSpecInteriorPt[A,n-dilNum],{i,numIters}];
(* Genrate Random Interior Points and Diltions *)
DilationPts=Table[Maximal1DilationRepeated[A,InteriorPts[[i]],dilNum,RandomBeta-> True,betaMethod-> "Projectionbeta"][[1]],{i,numIters}]//N;
(* Run NearFlatAssessment *)
NearFlatData=Table[NearFlatAssessment[A,DilationPts[[i]],EucKerRatio,RowLinDependenceTol,GapOrMag-> OptionValue[GapOrMag],NumAnglesToDisplay-> OptionValue[NumAnglesToDisplay]],{i,numIters}];

NearFlatDataDisplay=Table[NumberForm[NearFlatData[[i,j]],OptionValue[NumDigitsToDisplay]],{i,Length[NearFlatData]},{j,Length[NearFlatData[[1]]]}];
(* Generate Table *)
TableHead={{"EX","Conj","n","Arv","rank","Euc","Principal","EucRows","EucSols"},{"No","Sum"," ","Sol","EucRow","Sol","Angles","Tols","Tols"}};
ExpNumCol=Table[{i},{i,numIters}];
PtSizeCol=Table[{Length[DilationPts[[i,1]]]},{i,numIters}];
ConjSumCol=Table[If[NearFlatData[[i,1]]==0,{{"Y","Y","Y"}},If[NearFlatData[[i,2]]==0,{{"N","N","N"}},
If[Min[NearFlatData[[i,4]]]>AngleConjTol,{{"Y","N","N"}},
If[(NearFlatData[[i,1]]>NearFlatData[[i,2]]&&NearFlatData[[i,4,2]]<AngleConjTol)||(NearFlatData[[i,1]]==NearFlatData[[i,2]]&&NearFlatData[[i,4,1]]<AngleConjTol),{{"Y","Y","Y"}},{{"Y","Y","N"}}]]]],{i,numIters}];
SuccessfulBaseConjNum=numIters-Count[ConjSumCol,{{"N","N","N"}}];
SuccessfulAngleConjNum=numIters-Count[ConjSumCol,{{"N","N","N"}}]-Count[ConjSumCol,{{"Y","N","N"}}];
SuccessfulStrongConjNum=Count[ConjSumCol,{{"Y","Y","Y"}}];
DataTable=Join[TableHead,ArrayFlatten[{{ExpNumCol,ConjSumCol,PtSizeCol,NearFlatDataDisplay}}]];
If[SameQ[OptionValue[PrintParameterSummary],True],
Print[" "];
Print[StringForm["The values for {g,n,d,k} are ``.",{g,n,d,k}]];
Print[StringForm["The bean count g*n-d*k for this experiment is ``.",g*n-d*k]];];
If[SameQ[OptionValue[PrintConjectureSummary],True],
Print[" "];Print[StringForm["`` out of `` experiments passed basic near flat existence conjecture conjecture.",SuccessfulBaseConjNum,numIters]];
Print[StringForm["The proportion of experiments which passed the base conjecture is ``.",NumberForm[N[SuccessfulBaseConjNum/numIters],OptionValue[NumDigitsToDisplay]]]];
Print[" "];Print[StringForm["`` out of `` experiments passed the near flat rows vs dilation subspace angle conjecture.",SuccessfulAngleConjNum,numIters]];
Print[StringForm["The proportion of experiments which passed the base conjecture is ``.",NumberForm[N[SuccessfulAngleConjNum/numIters],OptionValue[NumDigitsToDisplay]]]];
Print[" "];Print[StringForm["`` out of `` experiments passed the near flat rows approximately contained by dilation subspace conjecture.",SuccessfulStrongConjNum,numIters]];
Print[StringForm["The proportion of experiments which passed the base conjecture is ``.",NumberForm[N[SuccessfulStrongConjNum/numIters],OptionValue[NumDigitsToDisplay]]]];
Print[" "];];
If[SameQ[OptionValue[PrintTable],True],Print[MatrixForm[DataTable]]];
Return[NearFlatData]];


(* NearFlatAssessment Determines the DilationSubspace and Near flat solution spaces at X in the free spectrahedron defined by A, then deterimines the angle between the dilation subspace and the near flat rows *)
Options[NearFlatAssessment]:={GapOrMag->"Mag", NumAnglesToDisplay-> 2}
NearFlatAssessment[A_,X_,EucKerRatio_,RowLinDependenceTol_,OptionsPattern[]]:=Block[{DimDiSub,DimEucRows,DiSubspace,EucSystemEigVals,EucSystemEigVecs,EucSystemMat,EucSystemNullStartIndex,EucSystemSingVals,g,GapOrMag,n,LinIndepRowsCount,NearFlatRowsMat,NearFlatSols,NumAnglesToDisplay,NumericsAssessment,PEuc,PrincipalAngleList,VectorizedNearFlatSols,DimNearFlat,DimFlatTols},

g=Length[X];
n=Length[X[[1]]];

(* Compute inclusion to Kernel of LMI[A,X] *)
{PEuc,EucSystemMat}=EuclideanLambdaP[A,X];

(* Compute singular values and right singular vectors for matrix representation of Euclidean system Lambda[A,beta].P_x *)
{EucSystemEigVals,EucSystemEigVecs}=Eigensystem[Transpose[EucSystemMat] . EucSystemMat];
EucSystemSingVals=Map[Re,Map[Sqrt,EucSystemEigVals]];

(* Compute singular values and right singular vectors for matrix representation of Euclidean system Lambda[A,beta].P_x *)
{EucSystemEigVals,EucSystemEigVecs}=Eigensystem[Transpose[EucSystemMat] . EucSystemMat];
EucSystemSingVals=Map[Re,Map[Sqrt,EucSystemEigVals]];
EucSystemSingVals=Sort[EucSystemSingVals,Greater];

(* Determine number of approximate solutions to Euclidean system *)
If[OptionValue[GapOrMag]=="Gap",EucSystemNullStartIndex=DetermineNull[EucSystemSingVals,Infinity,EucKerRatio,NumericsAssessment->False];,EucSystemNullStartIndex=DetermineNull[EucSystemSingVals,EucKerRatio,Infinity,NumericsAssessment->False]];

If[SameQ[EucSystemNullStartIndex[[1]],False],VectorizedNearFlatSols=False;
{DimNearFlat,DimFlatTols}={0,{Last[EucSystemSingVals],-Infinity}};,
VectorizedNearFlatSols=EucSystemEigVecs[[EucSystemNullStartIndex[[1]];;All]];
If[EucSystemNullStartIndex[[1]]==1,
{DimNearFlat,DimFlatTols}={Length[VectorizedNearFlatSols],{Infinity,EucSystemSingVals[[1]]}},
{DimNearFlat,DimFlatTols}={Length[VectorizedNearFlatSols],{EucSystemSingVals[[EucSystemNullStartIndex[[1]]-1]],EucSystemSingVals[[EucSystemNullStartIndex[[1]]]]}};];

NearFlatSols=Table[ShortVecToSymBeta[VectorizedNearFlatSols[[i]],g,n],{i,Length[VectorizedNearFlatSols]}];
NearFlatRowsMat=ArrayFlatten[Table[{ArrayFlatten[{NearFlatSols[[i]]}]},{i,Length[NearFlatSols]}]]];

(* Compute basis for dilation subspace *)
DiSubspace=DilationSubspaceBasis[A,X];


(* Logic checks for if no approximate Euclidean solution space or no dilation subspace is found. If these spaces are found, then run NearFlatVSDilSubContainment to determine then angle between the Euclidean rows and the dilation subpsace *) 
If[SameQ[VectorizedNearFlatSols,False] &&SameQ[DiSubspace,"The given tuple is Arveson extreme"],
Return[{0,0,DimNearFlat,{0},{0,-Infinity},DimFlatTols}],
If[SameQ[VectorizedNearFlatSols,False],
Return[{Length[DiSubspace],0,DimNearFlat,{Pi/2},{0,-Infinity},DimFlatTols}],
If[SameQ[DiSubspace,"The given tuple is Arveson extreme"],Return[{0,"?",DimNearFlat,{Pi/2},"{?,?}",DimFlatTols}],
{PrincipalAngleList,DimDiSub,DimEucRows}=NearFlatVsDilSubContainment[NearFlatSols,DiSubspace,RowLinDependenceTol] ;
Return [{DimDiSub,DimEucRows[[1]],DimNearFlat,Sort[TopNonTrivialAngles[PrincipalAngleList,OptionValue[NumAnglesToDisplay]],Greater],DimEucRows[[2]],DimFlatTols}]]]]]



(* NearFlatAssessmentGivenP computes the approximate Arveson and Euclidean solution spaces corresponding to A and P where P is an in inclusion matrix of size d*n x k. Then the principal angles between the approximate Arveson solution space and the rows of the approximate Euclidean solution space are reported *)
Options[NearFlatAssessmentGivenP]:={GapOrMag->"Mag", NumAnglesToDisplay-> 2}
NearFlatAssessmentGivenP[A_,P_,EucKerRatio_,ArvKerRatio_,RowLinDependenceTol_,OptionsPattern[]]:=Block[{ArvSystemEigVals,ArvSystemEigVecs,ArvSystemMat,ArvSystemNullStartIndex,ArvSystemSingVals,d,DimDiSub,DimEucRows,DimFlatTols,DimNearFlat,DiSubspace,DiSubTols,EucSystemEigVals,EucSystemEigVecs,EucSystemMat,EucSystemNullStartIndex,EucSystemSingVals,g,GapOrMag,n,LinIndepRowsCount,NearFlatRowsMat,NearFlatSols,NumericsAssessment,PEuc,PrincipalAngleList,VectorizedDilationSubspace,VectorizedNearFlatSols,NumAnglesToDisplay},

g=Length[A];
d=Length[A[[1]]];
n=Length[P]/d;

(* Compute inclusion to Kernel of LMI[A,X] *)
EucSystemMat=EuclideanLambdaPGivenP[A,P];

(* Compute singular values and right singular vectors for matrix representation of Euclidean system Lambda[A,beta].P_x *)
{EucSystemEigVals,EucSystemEigVecs}=Eigensystem[Transpose[EucSystemMat] . EucSystemMat];
EucSystemSingVals=Map[Re,Map[Sqrt,EucSystemEigVals]];
EucSystemSingVals=Sort[EucSystemSingVals,Greater];

(* Determine number of approximate solutions to Euclidean system *)
If[OptionValue[GapOrMag]=="Gap",EucSystemNullStartIndex=DetermineNull[EucSystemSingVals,Infinity,EucKerRatio,NumericsAssessment->False],EucSystemNullStartIndex=DetermineNull[EucSystemSingVals,EucKerRatio,Infinity,NumericsAssessment->False]];

If[SameQ[EucSystemNullStartIndex[[1]],False],VectorizedNearFlatSols=False;
{DimNearFlat,DimFlatTols}={0,{Last[EucSystemSingVals],-Infinity}};,
VectorizedNearFlatSols=EucSystemEigVecs[[EucSystemNullStartIndex[[1]];;All]];
If[EucSystemNullStartIndex[[1]]==1,
{DimNearFlat,DimFlatTols}={Length[VectorizedNearFlatSols],{Infinity,EucSystemSingVals[[1]]}},
{DimNearFlat,DimFlatTols}={Length[VectorizedNearFlatSols],{EucSystemSingVals[[EucSystemNullStartIndex[[1]]-1]],EucSystemSingVals[[EucSystemNullStartIndex[[1]]]]}};];

NearFlatSols=Table[ShortVecToSymBeta[VectorizedNearFlatSols[[i]],g,n],{i,Length[VectorizedNearFlatSols]}];
NearFlatRowsMat=ArrayFlatten[Table[{ArrayFlatten[{NearFlatSols[[i]]}]},{i,Length[NearFlatSols]}]]];

(* Compute basis for dilation subspace *)
ArvSystemMat=ArvesonLambdaPGivenP[A,P];

(* Compute singular values and right singular vectors for matrix representation of Euclidean system Lambda[A,beta].P_x *)
{ArvSystemEigVals,ArvSystemEigVecs}=Eigensystem[Transpose[ArvSystemMat] . ArvSystemMat];
ArvSystemSingVals=Map[Abs,Map[Sqrt,ArvSystemEigVals]];
ArvSystemSingVals=Sort[ArvSystemSingVals,Greater];

(* Determine number of approximate solutions to Euclidean system *)
If[OptionValue[GapOrMag]=="Gap",ArvSystemNullStartIndex=DetermineNull[ArvSystemSingVals,Infinity,ArvKerRatio,NumericsAssessment->False],ArvSystemNullStartIndex=DetermineNull[ArvSystemSingVals,ArvKerRatio,Infinity,NumericsAssessment->False]];

If[SameQ[ArvSystemNullStartIndex[[1]],False],VectorizedDilationSubspace=False;
{DimDiSub,DiSubTols}={0,{Last[ArvSystemSingVals],-Infinity}};,
VectorizedDilationSubspace=ArvSystemEigVecs[[ArvSystemNullStartIndex[[1]];;All]];
If[ArvSystemNullStartIndex[[1]]==1,
{DimDiSub,DiSubTols}={Length[VectorizedDilationSubspace],{Infinity,ArvSystemSingVals[[1]]}},
{DimDiSub,DiSubTols}={Length[VectorizedDilationSubspace],{ArvSystemSingVals[[ArvSystemNullStartIndex[[1]]-1]],ArvSystemSingVals[[ArvSystemNullStartIndex[[1]]]]}};];];

(* Logic checks for if no approximate Euclidean solution space or no approximate Arveson solution space is found. If these spaces are found, then run NearFlatVSDilSubContainment to determine then principal angles between the Euclidean rows and the approximate Arveson solution space *)
If[SameQ[VectorizedNearFlatSols,False] &&SameQ[ VectorizedDilationSubspace,False],
Return[{0,0,DimNearFlat,{0},{0,-Infinity},{0,-Infinity},DimFlatTols}],
If[SameQ[VectorizedNearFlatSols,False],
Return[{Length[VectorizedDilationSubspace],0,DimNearFlat,{Pi/2},DiSubTols,{0,-Infinity},DimFlatTols}],
If[SameQ[ VectorizedDilationSubspace,False],Return[{0,{0},"?",DimNearFlat,{Pi/2},-Infinity,"{?,?}",DimFlatTols}],
{PrincipalAngleList,DimDiSub,DimEucRows}=NearFlatVsDilSubContainment[NearFlatSols,VectorizedDilationSubspace,RowLinDependenceTol] ;
Return [{DimDiSub,DimEucRows[[1]],DimNearFlat,Sort[TopNonTrivialAngles[PrincipalAngleList,OptionValue[NumAnglesToDisplay]],Greater],DiSubTols,DimEucRows[[2]],DimFlatTols}]]]]]


(* NearFlatVsDilSubContainment finds the principal angles between the rows of a given approximate Euclidean solution space and the given approximate Arveson solution space *)
Options[NearFlatVsDilSubContainment]:={GapOrMag->"Mag"}
NearFlatVsDilSubContainment[NearFlatSols_,Disub_,RowLinDependenceTol_,OptionsPattern[]]:=Block[{DimDiSub,DimEucRows,DisubRowMat,GapOrMag,NearFlatRowsMat,NearFlatNullStartIndex,NearFlatRowsRightSingVecs,NearFlatLinIndepRows,NearFlatRowsSingVals,NearFlatRowsTol,NumericsAssessment,PrincipalAngleList},

(* Turn NearFlatSols into matrix *)
NearFlatRowsMat=ArrayFlatten[Table[{ArrayFlatten[{NearFlatSols[[i]]}]},{i,Length[NearFlatSols]}]];

(* Determine Basis for span of linearly independent near flat rows *)
{NearFlatRowsSingVals,NearFlatRowsRightSingVecs}=SingularValueDecomposition[NearFlatRowsMat,Min[Dimensions[NearFlatRowsMat]]][[2;;3]];
NearFlatRowsSingVals=Diagonal[NearFlatRowsSingVals];
NearFlatRowsRightSingVecs=Transpose[NearFlatRowsRightSingVecs];
NearFlatNullStartIndex=If[OptionValue[GapOrMag]=="Gap",
NearFlatNullStartIndex=DetermineNull[NearFlatRowsSingVals,Infinity,RowLinDependenceTol,NumericsAssessment->False],
NearFlatNullStartIndex=DetermineNull[NearFlatRowsSingVals,RowLinDependenceTol,Infinity,NumericsAssessment->False]];
(* If the near flat row matrix does not have a null space, then all rows are linearly independent *)
If[NearFlatNullStartIndex[[1]]==False,NearFlatNullStartIndex[[1]]=Min[Dimensions[NearFlatRowsMat]]+1;
NearFlatRowsTol={Last[NearFlatRowsSingVals],-Infinity}];
(* If tolerances are set too high, the near flat matrix could be treated as a zero matrix, hence it would have no linearly independent rows. In this case we force that there is at least one linearly independent row *)
If[NearFlatNullStartIndex[[1]]==1,NearFlatNullStartIndex[[1]]=2];
DimEucRows=NearFlatNullStartIndex[[1]]-1;
NearFlatLinIndepRows=NearFlatRowsRightSingVecs[[1;;DimEucRows]];
If[DimEucRows==Min[Dimensions[NearFlatRowsMat]],
NearFlatRowsTol={Last[NearFlatRowsSingVals],-Infinity},
NearFlatRowsTol=NearFlatRowsSingVals[[DimEucRows;;DimEucRows+1]]];

(* Turn dilation subspace into matrix whose rows are flattend elements of the dilation subspace *)
DisubRowMat=Map[Flatten,Disub];
DimDiSub=Length[DisubRowMat];

(* Compute Principal angles between Near flat subspace and dilation subspace *)
PrincipalAngleList=SubspaceDistance[Transpose[NearFlatLinIndepRows],Transpose[DisubRowMat]];
Return[{PrincipalAngleList,DimDiSub,{DimEucRows,NearFlatRowsTol}}]]





(* ArvesonLambdaPGivenP computes the matrix represenation of the linear map associated to the Arveson system, where the inclusion to the kernel is given *)
ArvesonLambdaPGivenP[A_,P_]:=Block[{d,g,n,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZArvMat,NullContainmentEqsBasic,NullContainmentEqs,NullContainmentTable,NullSystemMat,NullSystemEigVals,NullSystemEigenVecs,ZSolExistQ,ZSolConfidence,ArvesonQ,BadSystemNumerics,Alin},
g=Length[A];
d=Length[A[[1]]];
n=Length[P]/d;
Alin=A//N;
NullInclusionMatrix=P;
(* Create a dummy Arveson beta variable *)
ZArvMat=MakeZArv[g,n];
(* Generate NullContainment Equations and clean up trivial equations *)
NullContainmentEqsBasic=Lambda[Alin,ZArvMat] . NullInclusionMatrix//Expand;
NullContainmentEqs=DeleteCases[DeleteCases[Flatten[NullContainmentEqsBasic],0.],0];
(* Represent Equations as a matrix *)
NullContainmentTable=Table[NullContainmentEqs[[i]]==0,{i,1,Length[NullContainmentEqs]}];NullSystemMat=N[Normal[CoefficientArrays[NullContainmentTable,Variables[ZArvMat]]][[2]]];Return[NullSystemMat];
]



(* EuclideaLambdaPGivenP computes the matrix represenation of the linear map associated to the Euclidean system *)
EuclideanLambdaPGivenP[A_,P_]:=Block[{d,g,n,Alin,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZEucMat,NullContainmentEqsBasic,NullContainmentEqs,NullContainmentTable,NullSystemMat,NullSystemEigVals,NullSystemEigenVecs,ZSolExistQ,ZSolConfidence,EuclideanQ,BadSystemNumerics},
g=Length[A];
d=Length[A[[1]]];
n=Length[P]/d;
Alin=A//N;
NullInclusionMatrix=P;
(* Create a dummy Euclidean beta variable *)
ZEucMat=MakeZ[g,n];
(* Generate NullContainment Equations and clean up trivial equations *)
NullContainmentEqsBasic=Lambda[Alin,ZEucMat] . NullInclusionMatrix//Expand;NullContainmentEqs=DeleteCases[DeleteCases[Flatten[NullContainmentEqsBasic],0.],0];
(* Represent Equations as a matrix *)
NullContainmentTable=Table[NullContainmentEqs[[i]]==0,{i,1,Length[NullContainmentEqs]}];
NullSystemMat=N[Normal[CoefficientArrays[NullContainmentTable,Variables[ZEucMat]]][[2]]];Return[NullSystemMat]
]

(* Generates a random inclusion matrix P then runs EuclideanLambdaPGivenP and ArvesonLambdaPGivenP using the randomly generated P *)
LambdaPRand[A_,n_,k_]:=Block[{d,ArvSystemMat,EucSystemMat,P,PreP},
d=Length[A[[1]]];
PreP=RandomVariate[CircularRealMatrixDistribution[n*d]];
P=Transpose[PreP[[1;;Min[k,n*d]]]];
ArvSystemMat=ArvesonLambdaPGivenP[A,P];
EucSystemMat=EuclideanLambdaPGivenP[A,P];
Return[{ArvSystemMat,EucSystemMat}]]

(* Computes a random n x k isometry *)
RandomIsometry[n_,k_]:=Block[{PreIso,Iso},
PreIso=RandomVariate[CircularRealMatrixDistribution[n]];
Iso=Transpose[PreIso[[1;;Min[k,n]]]];
Return[Iso]]
  
  

(* Gives the largest num nontrivial princpal angles from a list of principal angles. If the list has a trivial principal angle, then a trivial prinpcial angle is included *)
TopNonTrivialAngles[list_,num_]:=Block[{sortlist,TrivAngleCount,nontrivlistLength,nontrivlist,PiCount,TopAngles},
sortlist=Sort[list,Less];
PiCount=Count[list,Pi/2];
nontrivlist=DeleteCases[sortlist,Pi/2];
nontrivlistLength=Length[nontrivlist];
TopAngles=nontrivlist[[Max[nontrivlistLength-num+1,1];;nontrivlistLength]];
TopAngles=Union[Append[TopAngles,Min[sortlist]]];
If[PiCount>0,TopAngles=Union[Append[TopAngles,Pi/2]]];
Return[Sort[TopAngles,Greater]]]

gdnk[g_,d_,n_]:=Ceiling[g*n/d-1]
  


(* ::Section::Closed:: *)
(*Extreme Point Generation and Classification*)


(* ::Text:: *)
(*This section contains the major functions for extreme point generation and classification. There are two subsections. The first subsection is main subsection. In this section linear functionals are generated by randomly generating coefficients alpha in Sum alpha_i * variable_i. In this second section, the linear functionals are generated by using trace and a weight matrix. The functions in this section have been more successful in repeated dilations.*)


(* ::Subsection:: *)
(*Extreme Point Classification*)


(* ::Input::Initialization:: *)
(* Solves the Kernel Containment linear system to determine if a point is Arveson *) 
Options[ArvesonTest]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2)}
ArvesonTest[A_,X_,OptionsPattern[]]:=Block[{g,n,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZArvMat,NullContainmentEqsBasic,NullContainmentEqs,NullContainmentTable,NullSystemMat,NullSystemEigVals,NullSystemEigenVecs,ZSolExistQ,ZSolConfidence,ArvesonQ,BadSystemNumerics,Alin},
g=Length[X];
n=Length[X[[1]]];
If[SameQ[Length[A],Length[X]],Alin=A,Alin=A[[2;;All]]];
{LMIEigenvalues,LMIEigenvectors}=Eigensystem[LMI[A,X]];
{NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[NullVecStartIterate,False],Return[{False,{NullConfidence,False,LMIEigenvalues}}],
If[SameQ[NullVecStartIterate,BadNumerics],Return[{BadNullNumerics,{NullConfidence,BadNullNumerics}}],
NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
ZArvMat=MakeZArv[g,n];
NullContainmentEqsBasic=Lambda[Alin,ZArvMat] . NullInclusionMatrix;
NullContainmentEqs=DeleteCases[DeleteCases[Flatten[NullContainmentEqsBasic],0.],0];
NullContainmentTable=Table[NullContainmentEqs[[i]]==0,{i,1,Length[NullContainmentEqs]}];
NullSystemMat=N[Normal[CoefficientArrays[NullContainmentTable,Variables[ZArvMat]]][[2]]];
{NullSystemEigVals,NullSystemEigenVecs}=Eigensystem[Transpose[NullSystemMat] . NullSystemMat];
{ZSolExistQ,ZSolConfidence}=DetermineNull[NullSystemEigVals,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
ArvesonQ=If[SameQ[False,ZSolExistQ],True,
If[SameQ[ZSolExistQ,BadNumerics],BadSystemNumerics,False]];
Return[{ArvesonQ,{NullConfidence,ZSolConfidence}}]]]]

(* ArvesonTestSystemMat returns the matrix which represents the eqs for the linear system for testing if a matrix is Arveson. This function may be used for more careful analysis by hand. *) 
Options[ArvesonTestSystem]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2)}
ArvesonTestSystem[A_,X_,OptionsPattern[]]:=Block[{g,n,Alin,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZArvMat,NullContainmentEqsBasic,NullContainmentEqs,NullContainmentTable,NullSystemMat,NullSystemEigVals,NullSystemEigenVecs,ZSolExistQ,ZSolConfidence,ArvesonQ,BadSystemNumerics},
g=Length[X];
n=Length[X[[1]]];
If[SameQ[Length[A],Length[X]],Alin=A,Alin=A[[2;;All]]];
{LMIEigenvalues,LMIEigenvectors}=Eigensystem[LMI[A,X]];
{NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[NullVecStartIterate,False],Return[{False,{NullConfidence,False,LMIEigenvalues}}],
If[SameQ[NullVecStartIterate,BadNumerics],Return[{BadNullNumerics,{NullConfidence,BadNullNumerics}}],
NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
ZArvMat=MakeZArv[g,n];
NullContainmentEqsBasic=Lambda[Alin,ZArvMat] . NullInclusionMatrix;
NullContainmentEqs=DeleteCases[DeleteCases[Flatten[NullContainmentEqsBasic],0.],0];
NullContainmentTable=Table[NullContainmentEqs[[i]]==0,{i,1,Length[NullContainmentEqs]}];
NullSystemMat=N[Normal[CoefficientArrays[NullContainmentTable,Variables[ZArvMat]]][[2]]];
(*{NullSystemEigVals,NullSystemEigenVecs}=Eigensystem[Transpose[NullSystemMat].NullSystemMat];
{ZSolExistQ,ZSolConfidence}=DetermineNull[NullSystemEigVals,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment\[Rule] OptionValue[NumericsAssessment],NumericsAssessment\[Rule] OptionValue[NumericsAssessmentTol]];
ArvesonQ=If[SameQ[False,ZSolExistQ],True,
If[SameQ[ZSolExistQ,BadNumerics],BadSystemNumerics,False]];*)
Return[NullSystemMat]]]]


(* ArvesonLambdaP computes the matrix represenation of the linear map associated to the Arveson system *)
ArvesonLambdaP[A_,X_]:=Block[{g,n,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZArvMat,NullContainmentEqsBasic,NullContainmentEqs,NullContainmentTable,NullSystemMat,NullSystemEigVals,NullSystemEigenVecs,ZSolExistQ,ZSolConfidence,ArvesonQ,BadSystemNumerics,Alin},
g=Length[X];
n=Length[X[[1]]];
Alin=A//N;
{LMIEigenvalues,LMIEigenvectors}=Eigensystem[LMI[A,X]];
{NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,10^(-6),10^(-5),NumericsAssessment->True,NumericsAssessment->10^(-2)];
NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
ZArvMat=MakeZArv[g,n];

NullContainmentEqsBasic=Lambda[Alin,ZArvMat] . NullInclusionMatrix//Expand;
NullContainmentEqs=DeleteCases[DeleteCases[Flatten[NullContainmentEqsBasic],0.],0];
NullContainmentTable=Table[NullContainmentEqs[[i]]==0,{i,1,Length[NullContainmentEqs]}];
NullSystemMat=N[Normal[CoefficientArrays[NullContainmentTable,Variables[ZArvMat]]][[2]]];
Return[{NullInclusionMatrix,NullSystemMat}]
]


(* Solves the appropriate kernel containment system to determine if a given point is Euclidean Extreme *) 
Options[EuclideanTest]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2)}
EuclideanTest[A_,X_,OptionsPattern[]]:=Block[{g,n,Alin,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZEucMat,NullContainmentEqsBasic,NullContainmentEqs,NullContainmentTable,NullSystemMat,NullSystemEigVals,NullSystemEigenVecs,ZSolExistQ,ZSolConfidence,EuclideanQ,BadSystemNumerics},
g=Length[X];
n=Length[X[[1]]];
If[SameQ[Length[A],Length[X]],Alin=A,Alin=A[[2;;All]]];
{LMIEigenvalues,LMIEigenvectors}=Eigensystem[LMI[A,X]];
{NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[NullVecStartIterate,False],Return[{False,{NullConfidence,False,LMIEigenvalues}}],
If[SameQ[NullVecStartIterate,BadNumerics],Return[{BadNullNumerics,{NullConfidence,BadNullNumerics}}],
NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
ZEucMat=MakeZ[g,n];
NullContainmentEqsBasic=Lambda[Alin,ZEucMat] . NullInclusionMatrix;
NullContainmentEqs=DeleteCases[DeleteCases[Flatten[NullContainmentEqsBasic],0.],0];
NullContainmentTable=Table[NullContainmentEqs[[i]]==0,{i,1,Length[NullContainmentEqs]}];
NullSystemMat=N[Normal[CoefficientArrays[NullContainmentTable,Variables[ZEucMat]]][[2]]];
{NullSystemEigVals,NullSystemEigenVecs}=Eigensystem[Transpose[NullSystemMat] . NullSystemMat];
{ZSolExistQ,ZSolConfidence}=DetermineNull[NullSystemEigVals,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
EuclideanQ=If[SameQ[False,ZSolExistQ],True,
If[SameQ[ZSolExistQ,BadNumerics],BadSystemNumerics,False]];
Return[{EuclideanQ,{NullConfidence,ZSolConfidence}}]]]]

(* EuclideaLambdaP computes the matrix represenation of the linear map associated to the Euclidean system *)
EuclideanLambdaP[A_,X_]:=Block[{g,n,Alin,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZEucMat,NullContainmentEqsBasic,NullContainmentEqs,NullContainmentTable,NullSystemMat,NullSystemEigVals,NullSystemEigenVecs,ZSolExistQ,ZSolConfidence,EuclideanQ,BadSystemNumerics},
g=Length[X];
n=Length[X[[1]]];
Alin=A//N;
{LMIEigenvalues,LMIEigenvectors}=Eigensystem[LMI[A,X]];
{NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,10^(-6),10^(-5),NumericsAssessment->True,NumericsAssessment->10^(-2)];
NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
ZEucMat=MakeZ[g,n];

NullContainmentEqsBasic=Lambda[Alin,ZEucMat] . NullInclusionMatrix//Expand;
NullContainmentEqs=DeleteCases[DeleteCases[Flatten[NullContainmentEqsBasic],0.],0];
NullContainmentTable=Table[NullContainmentEqs[[i]]==0,{i,1,Length[NullContainmentEqs]}];
NullSystemMat=N[Normal[CoefficientArrays[NullContainmentTable,Variables[ZEucMat]]][[2]]];
Return[{NullInclusionMatrix,NullSystemMat}]
]


(* ClassifyExtremePoint first determines if an extreme point is Arveson. If it is not Arveson then it checks to see if the extreme point is Euclidean. This is just a combination of the ArvesonTest and EuclideanTest commands. *)
Options[ClassifyExtremePoint]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),PrintExtremeData-> False}
ClassifyExtremePoint[A_,ExtremePoint_,OptionsPattern[]]:=Block[{g,n,ArvesonQ,ArvesonTolerance,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,EuclideanQ,EuclideanTolerance,PrintExtremeData},

{ArvesonQ,ArvesonTolerance}=ArvesonTest[A,ExtremePoint,EigMagTol->OptionValue[EigMagTol],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol]];

If[SameQ[ArvesonQ,True], 
EuclideanQ=True;
EuclideanTolerance=ArvesonTolerance;
If[OptionValue[PrintExtremeData]==True,
(Print["The point is an Arveson extreme point"];
Print["The Arveson tolerance was"];
Print[ArvesonTolerance];
Print[];)],
If[OptionValue[PrintExtremeData]==True,(Print["The point is not an Arveson extreme point"];
Print["The Arveson tolerance was"];
Print[ArvesonTolerance];
Print[];)];

{EuclideanQ,EuclideanTolerance}=EuclideanTest[A,ExtremePoint,EigMagTol->OptionValue[EigMagTol],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol]];

If[OptionValue[PrintExtremeData]==True,
If[SameQ[EuclideanQ,True],
Print["The point is a Euclidean extreme point"];
Print["The Euclidean tolerance was"];
Print[EuclideanTolerance];
Print[];,Print[];,
Print["The point is not a Euclidean extreme point"];
Print["The Euclidean tolerance was"];
Print[EuclideanTolerance];
Print[];]];];

Return[{ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance}];]




(* ::Subsection:: *)
(*Extreme Point Generation*)


(* ::Input::Initialization:: *)
(* Generates an Extreme Point candidate. Returns the extreme point and the linear functional that was used to generate the point *)
Options[GenerateExtremePoint]:={MyFunctional->  MakeFunctionalRational,ChopCutoff->  10^(-3),TolGap->  10^(-9),WeightVector->  Null,WeightMatrix-> Null, Sig-> 0,MathematicaSDP->  True,MonicLMI-> True, Distribution->"uniform",IntegerRange-> {-200000,200000},StepDenominator-> 100000 }
GenerateExtremePoint[A_,g_,n_,OptionsPattern[]]:=Block[{ArvesonTolerance,ArvesonQ,ExtremeX,EuclideanQ,EuclideanTolerance,lmi,MyFunctional,SDPVars,sdp,XRule,retVal,Y,Z,S,flags,OutputFileName,PencilEigenvalues,SDPFunctional,SDPWeight,Sig,TraceAnalysisValue,WeightMatrix,WeightVector,X,Xg,MathematicaSDP,SDPrule,d,constraint,Distribution,IntegerRange,StepDenominator,FunctionalA,MonicLMI},
Xg=MakeX[g,n];
d=Length[A[[g]]];
lmi=LMI[A,Xg];
If[OptionValue[MonicLMI],FunctionalA=A,FunctionalA=A[[2;;All]]];
SDPVars=MakeSDPVars[Xg];
retVal=Null;
(* If the MyFunctional option is set to MakeFunctionalRational then a Random Rational Functional of the appropriate size is generated. If the MyFunctional option is set to a specfic functional then the SDP and the functional defined by the user in the MyFunctional option will be used*)

(* Execute if MyFunctional option is MakeFunctionalTrace. This makes a positive linear functional by taking Trace[W.LMI[A,X]] where W is given by WeightMatrix. If WeightMatrix is Null then it is randomly generated *)
If[SameQ[OptionValue[MyFunctional],MakeFunctionalTrace]==True,
retVal=MakeFunctionalTrace[FunctionalA,n,WeightMatrix->OptionValue[WeightMatrix], Sig->OptionValue[Sig],Distribution-> OptionValue[Distribution],IntegerRange-> OptionValue[IntegerRange],StepDenominator-> OptionValue[StepDenominator]];];

If[SameQ[OptionValue[MyFunctional],MakeFunctionalRational]==True,
(* Execute if MyFunctional option is MakeFunctionalRational. This makes a rational functional using the option for WeightVector. If WeightVector is Null then it is randomly generated *)
retVal=MakeFunctionalRational[g,n,WeightVector-> OptionValue[WeightVector],Distribution-> OptionValue[Distribution],IntegerRange-> OptionValue[IntegerRange],StepDenominator-> OptionValue[StepDenominator]];];
(* If MyFunctional is not MakeFunctionalTrace, or MakeFunctionalRational, prints an Error message *)
If[SameQ[OptionValue[MyFunctional],MakeFunctionalRational]==False&&SameQ[OptionValue[MyFunctional],MakeFunctionalTrace]==False,
Print["WARNING: The value given for MyFunctional is incorrect or unsupported."];
Return[Null]];
If[retVal==Null,Return[Null]];
SDPWeight=retVal[[1]];
SDPFunctional=retVal[[2]];
If[OptionValue[MathematicaSDP]==False,
sdp=SDPMatrices[SDPFunctional,lmi,SDPVars];
(* End if loop. SDP Run begins here *)
{Y,Z,S,flags}=SDPSolve[sdp,Symbol["GapTol"]-> OptionValue[TolGap],Symbol["FeasibilityTol"]-> 10.^(3)*OptionValue[TolGap],Symbol["PrintIterations"]-> False,Symbol["PrintSummary"]-> False];
Y=Chop[Y,OptionValue[ChopCutoff]*10^(-5)];
(* Set up substitution rule and substitute *)
XRule=MakeXRule[g,n];
ExtremeX=NCReplaceRepeated[Xg,XRule];,
constraint=VectorGreaterEqual[{lmi,0},{"SemidefiniteCone",d*n}];
SDPrule=Quiet[SemidefiniteOptimization[SDPFunctional,constraint,SDPVars]];
(*Set up substitution rule and substitute*)
ExtremeX=NCReplaceRepeated[Xg,SDPrule];
];
Return[{ExtremeX,SDPWeight}]]


(* FindExtremePoint is the main extreme point finding tool of NCSE. This function generates an extreme point on the spectrahedron D_A by maximizing a linear functional on D_A (n). By default additional information about the extreme point is also generated including if it is Arveson/Euclidean and if it is irreducible. *)
Options[FindExtremePoint]:={MonicLMI-> True,MathematicaSDP-> True,DiagnosticLevel->4, EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),MyFunctional-> MakeFunctionalRational,ChopCutoff-> 10^(-3),TolGap-> 10^(-9),WeightVector-> Null,WeightMatrix->Null, Sig->0,Distribution-> "uniform",IntegerRange-> {-200000,200000},StepDenominator-> 100000}
FindExtremePoint[A_,n_,OptionsPattern[]]:=Block[{t1,t2,PointGenTime,ClassifyTime,EigTime,TanDimTime,DataGenTime,retVal,MathematicaSDP,ExtremeX,SDPFunctional,X,Xg,lmi,g,d,MyFunctional,SDPVars,sdp,XRule,Y,Z,S,flags,ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance,PencilEigenvalues,NullSpaceAnalysis,NullSpaceDimension,TangentAnalysis,TangentSpaceDimension,TestExtremePointType,IrredAssessment,IrredData,CommDim,CommTol,ChopCutoff,TolGap,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,WeightVector,WeightMatrix,Sig,IntegerRange,StepDenominator,Distribution,MonicLMI},
If[OptionValue[MonicLMI],g=Length[A],g=Length[A]-1];
d=Length[A[[g]]];
(* Calls appropriate Generate extreme point function to generate an extreme point candadite. *)
t1=SessionTime[];
retVal=GenerateExtremePoint[A,g,n,MyFunctional-> OptionValue[MyFunctional],MathematicaSDP-> OptionValue[MathematicaSDP],ChopCutoff-> OptionValue[ChopCutoff],TolGap->OptionValue[TolGap],WeightMatrix->OptionValue[WeightMatrix], Sig->OptionValue[Sig],WeightVector-> OptionValue[WeightVector],Distribution-> OptionValue[Distribution],IntegerRange-> OptionValue[IntegerRange],StepDenominator-> OptionValue[StepDenominator],MonicLMI-> OptionValue[MonicLMI]];
If[retVal==Null,Return[Null]];
{ExtremeX,SDPFunctional}={retVal[[1]],retVal[[2]]};

PointGenTime=SessionTime[]-t1;
t1 = SessionTime[];

If[OptionValue[DiagnosticLevel]==0,Return[ExtremeX]];
If[OptionValue[DiagnosticLevel]==1,Return[{ExtremeX,SDPFunctional}];];

(* If DiagnosticLevel is at least 2 then ClassifyExtremePoint is run. ClassifyExtremePoint first determines if an extreme point is Arveson. If it is not Arveson then it checks to see if the extreme point is Euclidean. *)
{ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance}=ClassifyExtremePoint[A,ExtremeX,EigMagTol->OptionValue[EigMagTol],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol]];

ClassifyTime=SessionTime[]-t1;
t1 = SessionTime[];

PencilEigenvalues=Eigenvalues[LMI[A,ExtremeX]];
NullSpaceAnalysis=DetermineNull[PencilEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol]][[1]];
If[SameQ[NullSpaceAnalysis,False],NullSpaceDimension=False,If[SameQ[NullSpaceAnalysis,BadNumerics],NullSpaceDimension=BadNullNumerics,NullSpaceDimension=n*d-NullSpaceAnalysis+1]];

EigTime=SessionTime[]-t1;
t1 = SessionTime[];

If[OptionValue[DiagnosticLevel]==2,Return[{ExtremeX,SDPFunctional,ArvesonQ,EuclideanQ}];];
If[OptionValue[DiagnosticLevel]==3,Return[{ExtremeX,SDPFunctional,ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance}];];

TangentSpaceDimension=FreeTangentNumerical[A,ExtremeX];

TanDimTime=SessionTime[]-t1;
t1 = SessionTime[];

If[SameQ[n,1],{CommDim,CommTol}={True,0},
IrredData=CommutantDimension[ExtremeX,EigMagTol-> OptionValue[EigMagTol]*10^(-3),EigGapTol-> OptionValue[EigGapTol]*10^-3,NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff]*10^(-5)];
If[SameQ[IrredData[[1]],1],{CommDim,CommTol}={True,IrredData[[2]]},{CommDim,CommTol}={IrredData[[1]],IrredData[[2]]}]];
DataGenTime = SessionTime[]-t1;
Return[{ExtremeX,SDPFunctional,ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance,NullSpaceDimension,TangentSpaceDimension,CommDim,CommTol}]]

(* GeneratePointData generates a table using FindExtremePoint *)
Options[GenerateExtremeData]={DiagnosticLevel->0,EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),ChopCutoff-> 10^(-3),TolGap-> 10^(-9),WeightVector-> Null,WeightMatrix->Null,Sig->0,MyFunctional-> MakeFunctionalRational,MathematicaSDP-> True,Distribution-> "uniform",IntegerRange-> {-200000,200000},StepDenominator-> 100000,MonicLMI-> True};
GenerateExtremeData[A_,n_,DataLength_,Seed_,OptionsPattern[]]:=Block[{DataTable,EigMagTol,EigGapTol,NumericsAssessment,IrredAssessment,NumericsAssessmentTol,ChopCutoff,TolGap,WeightMatrix,Sig,WeightVector,MyFunctional,MathematicaSDP,IntegerRange,StepDenominator,Distribution,MonicLMI},
BlockRandom[SeedRandom[Seed];
DataTable=Table[FindExtremePoint[A,n,DiagnosticLevel->OptionValue[DiagnosticLevel],EigMagTol-> OptionValue[EigMagTol],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff],TolGap-> OptionValue[TolGap], Sig->OptionValue[Sig],MathematicaSDP-> OptionValue[MathematicaSDP],MyFunctional->OptionValue[MyFunctional],Distribution-> OptionValue[Distribution],IntegerRange-> OptionValue[IntegerRange],StepDenominator-> OptionValue[StepDenominator],MonicLMI-> OptionValue[MonicLMI]],{i,1,DataLength}];
Return[DataTable]]]



(* ::Section:: *)
(*Dilations*)


(* ::Text:: *)
(*This section contains functions for dilating a tuple toward a free extreme point of the given free spectrahedron*)


(* ::Input::Initialization:: *)
(* DilationSubspaceDimension computes the dimension of the dilation subspaces of X in the free spectrahedron D_A *)
Options[DilationSubspaceDimension]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),ChopCutoff-> 10^(-3)}
  DilationSubspaceDimension[A_,X_,OptionsPattern[]]:=Block[{g,Ag,n,Alin,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZArvMat,ZArvVars,NullContainmentEqsBasic,NullContainmentEqs,NullContainmentTable,NullSystemMat,NullSystemEigVals,NullSystemEigenVecs,ZSolExistQ,ZSolConfidence,ArvesonQ,BadSystemNumerics,NullVecs,ZSubRus,DilateCoef,NextMaximalBeta,DilateBetaIterate,DilateBeta,DilateGamma,DilateX,DilateFunctional,DilateLMI,DilateVars,DilateSDP,DilateSDPY,DilateSDPZ,DilateSDPS,DilateSDPflags,MaximalDilateRu,MaximalDilateX,DilationSize,DilationArvesonQ},
  g=Length[X];
  Ag=Length[A];
  If[SameQ[g,Ag],Alin=A,Alin=A[[2;;All]]];
  n=Length[X[[1]]];
  MaximalDilateX=BadNumerics;
  {LMIEigenvalues,LMIEigenvectors}=Eigensystem[N[LMI[A,X]]];
  {NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
  If[SameQ[NullVecStartIterate,False],Return[n*g],
  If[SameQ[NullVecStartIterate,BadNumerics],Return[{BadNullNumerics,{NullConfidence,BadNullNumerics}}],
  NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
  ZArvMat=MakeZArv[g,n];
  ZArvVars=Variables[ZArvMat];
  NullContainmentEqsBasic=Lambda[Alin,ZArvMat] . NullInclusionMatrix;
  NullContainmentEqs=DeleteCases[DeleteCases[Flatten[NullContainmentEqsBasic],0.],0];
  NullContainmentTable=Table[NullContainmentEqs[[i]]==0,{i,1,Length[NullContainmentEqs]}];
  NullSystemMat=Normal[CoefficientArrays[NullContainmentTable,ZArvVars]][[2]];
  {NullSystemEigVals,NullSystemEigenVecs}=Eigensystem[Transpose[NullSystemMat] . NullSystemMat];
  If[NullSystemMat==0,Return[True]];
  {ZSolExistQ,ZSolConfidence}=DetermineNull[NullSystemEigVals,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]]]];
  If[SameQ[ZSolExistQ,False], Return[0] ,Return[Length[NullSystemEigVals]-ZSolExistQ+1]]]
  
(* DilationSubspaceBasis computes a  basis for the dilation subspace of the spectrahedron defined by A at the tuple X*)
Options[DilationSubspaceBasis]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),ChopCutoff-> 10^(-3)}
DilationSubspaceBasis[A_,X_,OptionsPattern[]]:=Block[{DilationSubspaceBasisVecs,DilationSubspaceBasisPreVecs,g,Ag,n,Alin,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZArvMat,ZArvVars,NullContainmentEqsBasic,NullContainmentEqs,NullContainmentTable,NullSystemMat,NullSystemEigVals,NullSystemEigenVecs,ZSolExistQ,ZSolConfidence,ArvesonQ,BadSystemNumerics,NullVecs,ZSubRus,DilateCoef,NextMaximalBeta,DilateBetaIterate,DilateBeta,DilateGamma,DilateX,DilateFunctional,DilateLMI,DilateVars,DilateSDP,DilateSDPY,DilateSDPZ,DilateSDPS,DilateSDPflags,MaximalDilateRu,MaximalDilateX,DilationSize,DilationArvesonQ},
  g=Length[X];
  Ag=Length[A];
  If[SameQ[Ag,g],Alin=A,Alin=A[[2;;All]]];
  n=Length[X[[1]]];
  MaximalDilateX=BadNumerics;
  {LMIEigenvalues,LMIEigenvectors}=Eigensystem[N[LMI[A,X]]];
  {NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment->  OptionValue[NumericsAssessment],NumericsAssessment->  OptionValue[NumericsAssessmentTol]];
  If[SameQ[NullVecStartIterate,False],
	DilationSubspaceBasisPreVecs=IdentityMatrix[g*n];
	DilationSubspaceBasisVecs=Table[VecToBeta[DilationSubspaceBasisPreVecs[[i]],g,n],{i,Length[DilationSubspaceBasisPreVecs]}];
	Return[DilationSubspaceBasisVecs],
  If[SameQ[NullVecStartIterate,BadNumerics],Return[{BadNullNumerics,{NullConfidence,BadNullNumerics}}],
  NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
  ZArvMat=MakeZArv[g,n];
  ZArvVars=Variables[ZArvMat];
  NullContainmentEqsBasic=Lambda[Alin,ZArvMat] . NullInclusionMatrix;
  NullContainmentEqs=DeleteCases[DeleteCases[Flatten[NullContainmentEqsBasic],0.],0];
  NullContainmentTable=Table[NullContainmentEqs[[i]]==0,{i,1,Length[NullContainmentEqs]}];
  NullSystemMat=Normal[CoefficientArrays[NullContainmentTable,ZArvVars]][[2]];
  {NullSystemEigVals,NullSystemEigenVecs}=Eigensystem[Transpose[NullSystemMat] . NullSystemMat];
  {ZSolExistQ,ZSolConfidence}=DetermineNull[NullSystemEigVals,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[ZSolExistQ,BadNumerics],Return[{ZSolExistQ,ZSolConfidence}]];
  ArvesonQ=If[SameQ[False,ZSolExistQ],True,
  If[SameQ[ZSolExistQ,BadNumerics],BadSystemNumerics,False]];
  If[ArvesonQ==False,DilationSubspaceBasisPreVecs=NullSystemEigenVecs[[ZSolExistQ;;Length[NullSystemEigenVecs]]];
DilationSubspaceBasisVecs=Table[VecToBeta[DilationSubspaceBasisPreVecs[[i]],g,n],{i,Length[DilationSubspaceBasisPreVecs]}];
  Return[DilationSubspaceBasisVecs],
  Return["The given tuple is Arveson extreme"]]]]]


(* DilationSubspaceProjection computes the orthogonal projection which maps a vectorized g tuple of vectors to a vectorized element of the dilation subspace of the spectrahedron defined by A at the tuple X *)
Options[DilationSubspaceProjection]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),ChopCutoff-> 10^(-3)}
DilationSubspaceProjection[A_,X_,OptionsPattern[]]:=Block[{DilationSubspaceProj,DilationSubspaceBasisPreVecs,g,Ag,n,Alin,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZArvMat,ZArvVars,NullContainmentEqsBasic,NullContainmentEqs,NullContainmentTable,NullSystemMat,NullSystemEigVals,NullSystemEigenVecs,ZSolExistQ,ZSolConfidence,ArvesonQ,BadSystemNumerics,NullVecs,ZSubRus,DilateCoef,NextMaximalBeta,DilateBetaIterate,DilateBeta,DilateGamma,DilateX,DilateFunctional,DilateLMI,DilateVars,DilateSDP,DilateSDPY,DilateSDPZ,DilateSDPS,DilateSDPflags,MaximalDilateRu,MaximalDilateX,DilationSize,DilationArvesonQ},
  g=Length[X];
  Ag=Length[A];
  If[SameQ[Ag,g],Alin=A,Alin=A[[2;;All]]];
  n=Length[X[[1]]];
  MaximalDilateX=BadNumerics;
  {LMIEigenvalues,LMIEigenvectors}=Eigensystem[N[LMI[A,X]]];
  {NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment->  OptionValue[NumericsAssessment],NumericsAssessment->  OptionValue[NumericsAssessmentTol]];
  If[SameQ[NullVecStartIterate,False],
	DilationSubspaceProj=IdentityMatrix[g*n];
	Return[DilationSubspaceProj],
  If[SameQ[NullVecStartIterate,BadNumerics],Return[{BadNullNumerics,{NullConfidence,BadNullNumerics}}],
  NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
  ZArvMat=MakeZArv[g,n];
  ZArvVars=Variables[ZArvMat];
  NullContainmentEqsBasic=Lambda[Alin,ZArvMat] . NullInclusionMatrix;
  NullContainmentEqs=DeleteCases[DeleteCases[Flatten[NullContainmentEqsBasic],0.],0];
  NullContainmentTable=Table[NullContainmentEqs[[i]]==0,{i,1,Length[NullContainmentEqs]}];
  NullSystemMat=Normal[CoefficientArrays[NullContainmentTable,ZArvVars]][[2]];
  {NullSystemEigVals,NullSystemEigenVecs}=Eigensystem[Transpose[NullSystemMat] . NullSystemMat];
  {ZSolExistQ,ZSolConfidence}=DetermineNull[NullSystemEigVals,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[ZSolExistQ,BadNumerics],Return[{ZSolExistQ,ZSolConfidence}]];
  ArvesonQ=If[SameQ[False,ZSolExistQ],True,
  If[SameQ[ZSolExistQ,BadNumerics],BadSystemNumerics,False]];
  If[ArvesonQ==False,DilationSubspaceBasisPreVecs=NullSystemEigenVecs[[ZSolExistQ;;Length[NullSystemEigenVecs]]];
DilationSubspaceProj=Transpose[DilationSubspaceBasisPreVecs] . DilationSubspaceBasisPreVecs;
  Return[DilationSubspaceProj],
  Return["The given tuple is Arveson extreme"]]]]]

  
  
  (* Maximal1Dilation attempts to compute a maximal 1 dilation of X in the free spectrahedron D_A of the form {{X,c*beta},{c*Tranpose[beta],gamma}}. Here c is a real number. The computed c should always be optimal; however a heuristic is used for gamma so optimality is not guaranteed. Initial tests are highly succesful however. *)
  
  Options[Maximal1DilationGivenBeta]:={EigMagTol->10^(-6),EigGapTol->10^(-5),NumericsAssessment->True,NumericsAssessmentTol->10^(-2),ChopCutoff->10^(-3),TolGap->10^(-9),GammaFunctionalWeight-> Null,MathematicaSDP-> True}
  Maximal1DilationGivenBeta[A_,X_,beta_,OptionsPattern[]]:=Block[{betaSDP,betaSDPY,betaSDPX,betaSDPS,betaSDPflags,g,n,H,gamma,gammaSDP,gammaSDPY,gammaSDPX,gammaSDPS,gammaSDPflags,LMIEval,SDPVars,SDPFunctional,sdp,XDi,XMaxBetaDi,XMaxBetaDiRu,XMaxgammaDi,XMaxgammaDiRu,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,TolGap,FunctionalCoefs,GammaFunctionalWeight,d,MathematicaSDP,betaSDPrule,betaconstraint,gammaconstraint},
  g=Length[X];
  n=Length[X[[1]]];
d=Length[A[[1]]];
  XDi=Table[ArrayFlatten[{{X[[i]],Z*beta[[i]]},{Z*Transpose[beta[[i]]],{{gamma[i]}}}}],{i,g}];
  SDPFunctional=Z;
  SDPVars=Join[{Z},Table[gamma[i],{i,g}]];

If[SameQ[OptionValue[MathematicaSDP],False],
 LMIEval={LMI[A,XDi]};
  betaSDP=SDPMatrices[SDPFunctional,LMIEval,SDPVars];
  {betaSDPY,betaSDPX,betaSDPS,betaSDPflags}=SDPSolve[betaSDP,GapTol->OptionValue[TolGap],FeasibilityTol->10.^(3)*OptionValue[TolGap],Symbol["PrintIterations"]-> False,Symbol["PrintSummary"]-> False];
  XMaxBetaDiRu={Z-> betaSDPY[[1,1,1]]};
  XMaxBetaDi=NCReplaceRepeated[XDi,XMaxBetaDiRu];,
 LMIEval=LMI[A,XDi];
betaconstraint=VectorGreaterEqual[{LMIEval,0},{"SemidefiniteCone",Length[LMIEval]}];
 XMaxBetaDiRu={Quiet[SemidefiniteOptimization[SDPFunctional,betaconstraint,SDPVars]][[1]]};
(*Set up substitution rule and substitute*)
XMaxBetaDi=NCReplaceRepeated[XDi,XMaxBetaDiRu];];
  SDPVars=Table[gamma[i],{i,g}];
  If[SameQ[OptionValue[GammaFunctionalWeight],Null],
  FunctionalCoefs=Table[RandomReal[],{i,Length[SDPVars]}],
  FunctionalCoefs=OptionValue[GammaFunctionalWeight]];
  SDPFunctional=Dot[SDPVars,FunctionalCoefs];
If[SameQ[OptionValue[MathematicaSDP],False],
LMIEval={LMI[A,XMaxBetaDi]};
  gammaSDP=SDPMatrices[SDPFunctional,LMIEval,SDPVars];
  {gammaSDPY,gammaSDPX,gammaSDPS,gammaSDPflags}=SDPSolve[gammaSDP,GapTol->OptionValue[TolGap],FeasibilityTol->10.^(3)*OptionValue[TolGap],Symbol["PrintIterations"]-> False,Symbol["PrintSummary"]-> False];
  XMaxgammaDiRu=Table[Rule[gamma[i],gammaSDPY[[1,1,i]]],{i,g}];
  XMaxgammaDi=NCReplaceRepeated[XMaxBetaDi,XMaxgammaDiRu];,
LMIEval=LMI[A,XMaxBetaDi];
gammaconstraint=VectorGreaterEqual[{LMIEval,0},{"SemidefiniteCone",d*(n+1)}];
XMaxgammaDiRu=Quiet[SemidefiniteOptimization[SDPFunctional,gammaconstraint,SDPVars]];
(*Set up substitution rule and substitute*)
XMaxgammaDi=NCReplaceRepeated[XMaxBetaDi,XMaxgammaDiRu];];
  Return[{XMaxgammaDi,FunctionalCoefs}]]
  
 

  
(* Maximal1Dilation computes a maximal 1 dilation of X in the free spectrahedron D_A of the form {{X,beta},{Tranpose[beta],gamma}}. beta is computed for the user in this version. Warning: On certain spectrahedra, this computation can be numerically challenging. In these cases a good solution can fail to be obtained. Note: If Projectionbeta method is used for generating beta, then the projected vector is always generated randomly to prevent potential issues with repeated use of Maximal1Dilation (i.e. to prevent the projected vector from lying in the null space of the projection) *)
  Options[Maximal1Dilation]:={EigMagTol->10^(-6),EigGapTol->10^(-5),NumericsAssessment->True,NumericsAssessmentTol->10^(-2),ChopCutoff->10^(-3),TolGap->10^(-9),GammaFunctionalWeight-> Null,MathematicaSDP-> True,RandomBeta-> True,betaMethod-> "Projectionbeta"}
  Maximal1Dilation[A_,X_,OptionsPattern[]]:=Block[{BadNumerics,BadNullNumerics,beta,betaMethod,g,n,DiSubBasis,DiSubDim,DiSubProj,XMax1Di,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,TolGap,ChopCutoff,GammaFunctionalWeight,FunctionalCoefs,MathematicaSDP,Prebeta,RandomBeta,tempbeta,VectorToProjectToDiSub},
(* Determine X dimensions *)
  g=Length[X];
  n=Length[X[[1]]];
(* Compute the dimension of the dilation subspace. If this is 0, then the tuple is Arveson extreme. If this is g*n, then the tuple is an interior point, and any beta of appropriate size is in the dilation subspace *)
  DiSubDim=DilationSubspaceDimension[A,X,EigMagTol->  OptionValue[EigMagTol],EigGapTol-> OptionValue[EigGapTol],NumericsAssessment->OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff]];
  If[SameQ[DiSubDim,0],Return["The given tuple is Arveson extreme"],
If[SameQ[DiSubDim,g*n],If[OptionValue[RandomBeta]==True,tempbeta=Table[Transpose[{Table[RandomReal[{-1,1}],{i,n}]}],{j,g}];beta=tempbeta/Norm[Flatten[tempbeta]];,beta=Table[Transpose[{Table[1,{i,n}]}],{j,g}]],
(* If the Dilation subspace dimension is nontrivial, we need to compute a beta in the dilation subspace. We can use two methods. One method is to compute  projection onto the dilation subspace, and project, the other is to compute a basis for the dilation subspace. Computing a basis for the dilation subspace appears to be numerically unstable. We hope that the projection method is more numerically stable. The projection method comes first *)
If[OptionValue[betaMethod]=="Projectionbeta",
DiSubProj=DilationSubspaceProjection[A,X];
(* In edge cases, bad numerical tolerances can make it so that the projection to the dilation subspaces cannot robustly be computed. The following logic handles this issue *)
If[SameQ[DiSubProj[[1]],BadNumerics]||SameQ[DiSubProj[[1]],BadNullNumerics],Return[DiSubProj]];
(* Either a random or a fixed vector is projected depending on the option value of RandomBeta *)
VectorToProjectToDiSub=Table[RandomReal[{-1,1}],{i,g*n}];
(* The vector is projected giving a vector of length g*n which is the vectorization of an element of the dilation subspace. This vector is then converted to a g tuple beta *)
Prebeta=DiSubProj . VectorToProjectToDiSub;
beta=VecToBeta[Prebeta,g,n];,
(* Code for the basis method for computing an element of the dilation subspace follows. The DiSubBasis comand computes a basis. *)
 DiSubBasis=DilationSubspaceBasis[A,X,EigMagTol->  OptionValue[EigMagTol],EigGapTol-> OptionValue[EigGapTol],NumericsAssessment->OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff]];
(* In edge cases, bad numerical tolerances can make it so that the projection to the dilation subspaces cannot robustly be computed. The following logic handles this issue *)
If[SameQ[DiSubBasis[[1]],BadNumerics]||SameQ[DiSubBasis[[1]],BadNullNumerics],Return[DiSubBasis]];
  If[SameQ[DiSubBasis[[1]],False],If[OptionValue[RandomBeta]==True,tempbeta=VecToBeta[Table[RandomReal[{-1,1}],{i,n*g}],g,n];beta=tempbeta/Norm[Flatten[tempbeta]];,beta=VecToBeta[Table[1,{i,n*g}],g,n]],
(* If the option RandomBeta is set to true, then we take a random linear combination of elmeents of our basis for the dilation subspace. Otherwise take the first basis vector *)
  If[OptionValue[RandomBeta]==True,
tempbeta=Sum[RandomReal[{-1,1}]*DiSubBasis[[i]],{i,Length[DiSubBasis]}];
beta=tempbeta/Norm[Flatten[tempbeta]];,
beta=DiSubBasis[[1]]]]]]];
(* Having computed a beta in the dilation subspace, we can use Maximal1DilationGivenBeta to compute a Maximal1Dilation of X *)
  {XMax1Di,FunctionalCoefs}=Maximal1DilationGivenBeta[A,X,beta,MathematicaSDP-> OptionValue[MathematicaSDP],EigMagTol-> OptionValue[EigMagTol],EigGapTol-> OptionValue[EigGapTol],NumericsAssessment->OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff],TolGap-> OptionValue[TolGap],GammaFunctionalWeight-> OptionValue[GammaFunctionalWeight]];
  Return[{XMax1Di,FunctionalCoefs}]]

  (* Maxmial1DilationRepeated attempts to compute success maximal 1-dilations of the given tuple X. The function will stop after reaching an Arveson extreme point of the free spectrahedron or after a user specified number of iterations *)
 Options[Maximal1DilationRepeated]:={EigMagTol->10^(-6),EigGapTol->10^(-5),NumericsAssessment->True,NumericsAssessmentTol->10^(-2),ChopCutoff->10^(-3),TolGap->10^(-9),GammaFunctionalWeight-> Null,MathematicaSDP-> True,RandomBeta-> True,betaMethod-> "Projectionbeta"}
Maximal1DilationRepeated[lmi_,tuple_,MaxIters_,OptionsPattern[]]:=Block[{betaMethod,DiSubDim,DiSubDimTemp,DSD,tupleTemp,Max1Di,iters,failediters,EigMagTol,EigGapTol,NumericsAssessment,PreviousTuple,ChopCutoff,TolGap,GammaFunctionalWeight,MathematicaSDP,RandomBeta},
DiSubDim=DilationSubspaceDimension[lmi,tuple];
iters=0;
failediters=0;
Max1Di=tuple;
PreviousTuple=tuple;
DSD={DiSubDim};
While[DiSubDim>0&&iters<MaxIters,
tupleTemp=Maximal1Dilation[lmi,Max1Di,EigMagTol-> OptionValue[EigMagTol],EigGapTol-> OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],ChopCutoff-> OptionValue[ChopCutoff],TolGap-> OptionValue[TolGap],GammaFunctionalWeight-> OptionValue[GammaFunctionalWeight],MathematicaSDP-> OptionValue[MathematicaSDP],RandomBeta-> OptionValue[RandomBeta],betaMethod->OptionValue[betaMethod]][[1]];
If[MatrixQ[tupleTemp[[1]], NumericQ] == False, iters = iters + 1;Continue[]];
DiSubDimTemp=DilationSubspaceDimension[lmi,tupleTemp];
If[DiSubDim>DiSubDimTemp,
DSD=Append[DSD,DiSubDimTemp];
DiSubDim=DiSubDimTemp;
Max1Di=tupleTemp];
If[Max1Di==PreviousTuple,
failediters=failediters+1];
iters=iters+1;
PreviousTuple=Max1Di];
Return[{Max1Di,DSD,iters,failediters}]]


  (* Maxmial1DilationRepeated attempts to compute success maximal 1-dilations of the given tuple X. The function will stop after reaching an Arveson extreme point of the free spectrahedron or after a user specified number of iterations *)
 Options[DilateToArveson]:={betaMethod-> "Projectionbeta",EigMagTol->10^(-6),EigGapTol->10^(-5),NumericsAssessment->True,NumericsAssessmentTol->10^(-2),ChopCutoff->10^(-3),TolGap->10^(-9),GammaFunctionalWeight-> Null,MathematicaSDP-> True,RandomBeta-> False,MaxIters-> 1000}
DilateToArveson[lmi_,tuple_,OptionsPattern[]]:=Block[{betaMethod,DiSubDim,DiSubDimTemp,DSD,tupleTemp,Max1Di,iters,failediters,EigMagTol,EigGapTol,NumericsAssessment,PreviousTuple,ChopCutoff,TolGap,GammaFunctionalWeight,MathematicaSDP,RandomBeta,MaxIters},
DiSubDim=DilationSubspaceDimension[lmi,tuple];
iters=0;
failediters=0;
Max1Di=tuple;
PreviousTuple=tuple;
DSD={DiSubDim};
While[DiSubDim>0&&iters<OptionValue[MaxIters],
tupleTemp=Maximal1Dilation[lmi,Max1Di,EigMagTol-> OptionValue[EigMagTol],EigGapTol-> OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],ChopCutoff-> OptionValue[ChopCutoff],TolGap-> OptionValue[TolGap],GammaFunctionalWeight-> OptionValue[GammaFunctionalWeight],MathematicaSDP-> OptionValue[MathematicaSDP],RandomBeta-> OptionValue[RandomBeta],betaMethod->OptionValue[betaMethod]][[1]];
If[MatrixQ[tupleTemp[[1]], NumericQ] == False, iters = iters + 1;Continue[]];
DiSubDimTemp=DilationSubspaceDimension[lmi,tupleTemp];
If[DiSubDim>DiSubDimTemp,
DSD=Append[DSD,DiSubDimTemp];
DiSubDim=DiSubDimTemp;
Max1Di=tupleTemp];
If[Max1Di == PreviousTuple,
failediters=failediters+1];
iters=iters+1;
PreviousTuple = Max1Di];
Return[{Max1Di,DSD,iters,failediters}]]

 Options[DilateToEuclidean]:={betaMethod-> "Projectionbeta",EigMagTol->10^(-6),EigGapTol->10^(-5),NumericsAssessment->True,NumericsAssessmentTol->10^(-2),ChopCutoff->10^(-3),TolGap->10^(-9),GammaFunctionalWeight-> Null,MathematicaSDP-> True,RandomBeta-> False,MaxIters-> 1000}
DilateToEuclidean[lmi_,tuple_,OptionsPattern[]]:=Block[{betaMethod,DiSubDim,DiSubDimTemp,DSD,tupleTemp,Max1Di,iters,failediters,EigMagTol,EigGapTol,NumericsAssessment,PreviousTuple,ChopCutoff,TolGap,GammaFunctionalWeight,MathematicaSDP,RandomBeta,MaxIters,EuclideanQ},
DiSubDim=DilationSubspaceDimension[lmi,tuple];
EuclideanQ=EuclideanTest[lmi,tuple][[1]];
iters=0;
failediters=0;
Max1Di=tuple;
PreviousTuple=tuple;
DSD={DiSubDim};
While[EuclideanQ==False&&iters<OptionValue[MaxIters],
tupleTemp=Maximal1Dilation[lmi,Max1Di,betaMethod->OptionValue[betaMethod],EigMagTol-> OptionValue[EigMagTol],EigGapTol-> OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],ChopCutoff-> OptionValue[ChopCutoff],TolGap-> OptionValue[TolGap],GammaFunctionalWeight-> OptionValue[GammaFunctionalWeight],MathematicaSDP-> OptionValue[MathematicaSDP],RandomBeta-> OptionValue[RandomBeta]][[1]];
If[MatrixQ[tupleTemp[[1]], NumericQ] == False, iters = iters + 1;Continue[]];
DiSubDimTemp=DilationSubspaceDimension[lmi,tupleTemp];
If[DiSubDim>DiSubDimTemp,
DSD = Append[DSD, DiSubDimTemp];
DiSubDim=DiSubDimTemp;
EuclideanQ=EuclideanTest[lmi,tupleTemp][[1]];
Max1Di=tupleTemp];
If[Max1Di==PreviousTuple,
failediters=failediters+1];
iters=iters+1;
PreviousTuple=Max1Di];
Return[{Max1Di,DSD,iters,failediters}]]






(* ::Section:: *)
(*Matrix Extreme Classification*)


(* ::Text:: *)
(*This section contains rudimentary functions with a goal of finding matrix extreme points.*)


(* BetaCommutantDimension computes the dimension of a relaxation of the commutant. *)
Options[BetaCommutantDimension]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),ChopCutoff-> 10^(-3)}
BetaCommutantDimension[X_,beta_,OptionsPattern[]]:=Block[{g,n,YMat,CommutantEqs,CommutantSystemMat,CommutantSystemEigVals,CommutantSystemEigVecs,CommSolExistQ,CommSolConfidence,EigMagTol,EigGapTol,ChopCutoff,NumericsAssessment,NumericsAssessmentTol,CommDim,BadNumerics,BadSystemNumerics,DiSubDim,DilationBeta,YSquare,YCol},
g=Length[X];
n=Length[X[[1]]];
YMat=MakeY[n+1];
YSquare=YMat[[1;;n,1;;n]];
YCol=Transpose[{YMat[[1;;n,n+1]]}];
CommutantEqs=Map[EqualsZero,DeleteCases[Chop[Flatten[Table[YSquare . X[[i]]+YCol . Transpose[beta[[i]]]-X[[i]] . YSquare-beta[[i]] . Transpose[YCol],{i,g}]],OptionValue[ChopCutoff]],0]];
If[Length[CommutantEqs]==0,Return[{n*(n+1)/2+n,0}]];
CommutantSystemMat=N[Normal[CoefficientArrays[CommutantEqs,Variables[YMat]]][[2]]];
{CommutantSystemEigVals,CommutantSystemEigVecs}=Eigensystem[Transpose[CommutantSystemMat] . CommutantSystemMat];
{CommSolExistQ,CommSolConfidence}=DetermineNull[CommutantSystemEigVals,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[CommSolExistQ,BadNumerics],CommDim=BadSystemNumerics,CommDim=Length[CommutantSystemEigVals]-CommSolExistQ+1];
Return[{CommDim,CommSolConfidence}]]

(* Relaxed matrix extreme test checks if a tuple has a one dimensional dilation subspace and if it has a trivial beta commutant. This test is intended to help with finding matrix extreme points. *)
Options[RelaxedMatrixExtremeTest]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),ChopCutoff-> 10^(-3)}
RelaxedMatrixExtremeTest[A_,X_,OptionsPattern[]]:=Block[{g,n,YMat,CommutantEqs,CommutantSystemMat,CommutantSystemEigVals,CommutantSystemEigVecs,CommSolExistQ,CommSolConfidence,EigMagTol,EigGapTol,ChopCutoff,NumericsAssessment,NumericsAssessmentTol,CommDim,BadNumerics,BadSystemNumerics,DiSubDim,DilationBeta,YSquare,YCol,BetaCommDim,BetaCommConfidence},
g=Length[X];
n=Length[X[[1]]];
DiSubDim=DilationSubspaceDimension[A,X,EigMagTol-> OptionValue[EigMagTol],EigGapTol->  OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol->  OptionValue[NumericsAssessmentTol],ChopCutoff->  OptionValue[ChopCutoff]];
If[SameQ[SameQ[Element[DiSubDim,Integers],True],False],Return[{False,"There was an error in computation of the dilation subspace"}]];
If[DiSubDim==0,Return[{False,"The tuple is Arveson Extreme"}]];
If[DiSubDim>1,Return[{False,"The dilation subspace has dimension two or greater"}]];
DilationBeta=DilationSubspaceBasis[A,X,EigMagTol-> OptionValue[EigMagTol],EigGapTol->  OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol->  OptionValue[NumericsAssessmentTol],ChopCutoff->  OptionValue[ChopCutoff]][[1]];
{BetaCommDim,BetaCommConfidence}=BetaCommutantDimension[X,DilationBeta,EigMagTol-> OptionValue[EigMagTol],EigGapTol->  OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol->  OptionValue[NumericsAssessmentTol],ChopCutoff->  OptionValue[ChopCutoff]];
If[SameQ[BetaCommDim,BadNullNumerics],Return[{False,"The dimension of the BetaCommutant could not be determined"}],
If[BetaCommDim>1,Return[{False,{BetaCommDim,BetaCommConfidence}}],Return[{True,{BetaCommDim,BetaCommConfidence}}]]]]



(* ::Section:: *)
(*Utilities*)


(* ::Text:: *)
(*This section contains utility functions. Examples include viewing graphics of level 1 of a g=2 spectrahedron, viewing nice presentations of LMI to look at, and Random g=2 LMI coefficient generation*)


(* ::Input::Initialization:: *)
(* TupleNorm computes the norm of a tuple *)
TupleNorm[tuple_]:=Sqrt[Norm[Sum[tuple[[i]] . Transpose[tuple[[i]]],{i,Length[tuple]}]]]

(* LeftMultTuple left multiplies Tuple by the matrix M *)
LeftMultTuple[M_,tuple_]:=Table[M . tuple[[i]],{i,Length[tuple]}]

(* RightMultTuple Right multiplies Tuple by the matrix M *)
RightMultTuple[M_,tuple_]:=Table[tuple[[i]] . M,{i,Length[tuple]}]

(* ConjTuple right multiplies Tuple by M and left multiplies by M^* *)
ConjTuple[M_,tuple_]:=RightMultTuple[Transpose[M],LeftMultTuple[M,tuple]]

(* TupleComm commutes the commutante of Tuple with M *)
TupleComm[M_,tuple_]:=LeftMultTuple[M,tuple]-RightMultTuple[M,tuple]

(* ArvTanVec Computes the element of the Arveson tangent space corresponding to beta and M *)
ArvTanVec[M_,beta_]:=LeftMultTuple[M,Map[Transpose,beta]]+Map[Transpose,LeftMultTuple[M,Map[Transpose,beta]]]

(* SkewSymmetricBasis produces the standard basis for the collection of n x n skew symmetric matrices *)
SkewSymmetricBasis[n_]:=Block[{eye,skewsyms},
eye=IdentityMatrix[n];
skewsyms={};
For[i=1,i<n,i++,
For[j=i+1,j<= n,j++,
skewsyms=Append[skewsyms,Transpose[{eye[[i]]}] . {eye[[j]]}-Transpose[{eye[[j]]}] . {eye[[i]]}];]];
Return[skewsyms]]

(* VecToSquareBeta converts a vectors representing a g tuple of n x n matrices to a g tuple of n x n matrices *)
VecToSquareBeta[vec_,g_,n_]:=ArrayReshape[vec,{g,n,n}]

(* upperTriangular produces an upper triangular matrix with the specified entries *)
upperTriangular[v_]:=Block[{i=0,n},n=-1/2+Sqrt[1/4+2*Length[v]];
Return[Array[If[#>#2,0,v[[++i]]]&,{n,n}]]]

(* TakeUpper produces a vector containing the upper triangular entries of amatrices *)
TakeUpper[mat_?SquareMatrixQ]:=Join@@Table[mat[[i,j]],{i,Length[mat]},{j,i,Length[mat]}];

(* TakeUpperTuple produces a vector containing the upper triangular entries from each of a tuple of matrices *)
TakeUpperTuple[list_]:=Flatten[Map[TakeUpper,list]];

(* SymMatFromShortVec turns a vector of length n(n+1)/2 into a symmetric n x n matrix *)
SymMatFromShortVec[v_]:=Block[{upptri,symmat},
upptri=upperTriangular[v];
symmat=upptri+Transpose[upptri];
For[i=1,i<= Length[upptri],i++,
symmat[[i,i]]=symmat[[i,i]]/2];
Return[symmat]]

(* ShortVecToSymBeta takes a vector of length gn(n+1)/2 and turns it into a g tuple of n x n symmetric matrices *)
ShortVecToSymBeta[vec_,g_,n_]:=Map[SymMatFromShortVec,ArrayReshape[vec,{g,n (n+1)/2}]]


(* ViewTuple is short for Map[MatrixForm,Tuple] *)
ViewTuple[tuple_]:=Map[MatrixForm,tuple]

(* Shows evaluation of the LMI[A,X] on a symbolic variable X *)
Options[ViewLMIGraphic]:={MonicLMI-> True}
ViewLMIGraphic[a_,OptionsPattern[]]:=Block[{X},
If[SameQ[OptionValue[MonicLMI],False],Print[a[[1]]-Sum[KroneckerProduct[a[[i+1]],{{X[i]}}],{i,Length[a]-1}]//MatrixForm],
Print[IdentityMatrix[Length[a[[1]]]]-Sum[KroneckerProduct[a[[i]],{{X[i]}}],{i,Length[a]}]//MatrixForm]]]

(* Note: ViewPolyhedron2D only works when the input is a polyhedron, i.e. defined by a tuple of diagonal matrices*)
ViewPolyhedron2D[a_]:=Block[{ConstraintList,Constraint,d,g,x,RegionUpperBoundList,RegionLowerBoundList,ACoefBoundList},(
d=Length[a[[1]]];
g=Length[a];
ConstraintList=Table[1-Sum[a[[j,i,i]]*x[j],{j,g}]>0,{i,d}];
Constraint=ConstraintList[[1]];
Do[Constraint=And[Constraint,ConstraintList[[i]]],{i,2,d}];
ACoefBoundList=Table[Table[If[a[[j,i,i]]!=0,1/a[[j,i,i]],0],{i,d}],{j,g}];
RegionUpperBoundList=Table[Max[ACoefBoundList[[j]]]+4,{j,g}];
RegionLowerBoundList=Table[Min[ACoefBoundList[[j]]]-4,{j,g}];
Return[RegionPlot[Constraint,{x[1],RegionLowerBoundList[[1]],RegionUpperBoundList[[1]]},{x[2],RegionLowerBoundList[[2]],RegionUpperBoundList[[2]]}]]
(*Return[RegionUpperBoundList]*)
)]

(* Level1ExtremePlot makes a plot of the extreme points at level 1 of the given spectrahedron *)
Options[Level1ExtremePlot]:={PointCount-> 10000,g4GraphicsStyle-> Graphics3D,MonicLMI-> True}
Level1ExtremePlot[A_,OptionsPattern[]]:=Block[{g,ExtremePointList,PointCount,DiagnosticLevel,minval,maxval,midval,g4GraphicsStyle,MonicLMI,ConvexHull},
If[OptionValue[MonicLMI],g=Length[A],g=Length[A]-1];
If[g!=2&&g!=3&&g!=4,Return["SpectrahedronLevel1ExtremePlot is not supported on a g-tuple of this size"];];
ExtremePointList=Table[Flatten[FindExtremePoint[A,1,DiagnosticLevel-> 0,MonicLMI-> OptionValue[MonicLMI]]],{i,OptionValue[PointCount]}];
If[g==2,ConvexHull=ConvexHullMesh[ExtremePointList,Axes->True];
Return[Show[ConvexHull,Graphics[Point[ExtremePointList]]]],
If[g==3,Return[ListPointPlot3D[ExtremePointList, Axes -> True, BoxRatios -> {1, 1, 1/GoldenRatio}]],
If[SameQ[OptionValue[g4GraphicsStyle],Graphics3D],
Return[Graphics3D[{PointSize[0.004],
   Point[ExtremePointList[[All, 1 ;; 3]], VertexColors -> Hue /@ ExtremePointList[[All, 4]]],
   Axes -> True, BoxRatios -> {1, 1, 1/GoldenRatio}}]];,
minval=Min[ExtremePointList[[All,4]]];
maxval=Max[ExtremePointList[[All,4]]];
midval=(minval+maxval)/2;
Return[ListPointPlot3D[List /@ ExtremePointList[[All, {1, 2, 3}]], 
 PlotStyle -> ({PointSize[Small], 
      Blend[{{minval, Blue}, {midval, Darker[Green]}, {maxval, 
         Red}}, #1]} & /@ Flatten[ExtremePointList[[All, {4}]]])]]]]
];]


(* DeleteZeros deletes the zeros from a given list *)

DeleteZeros[list_]:=DeleteCases[list,0]

(* CountIrreducibles counts the number of irreducible tuples in a table generated using FindExtremePoint *)

CountIrreducibles[ExtremeList_]:=Block[{iterate,IrredCount},
iterate=1;
IrredCount=0;
While[iterate<= Length[ExtremeList],
If[SameQ[ExtremeList[[iterate,9]],True],
IrredCount=IrredCount+1];
iterate=iterate+1];
Return[IrredCount]]

(* countNullDims and countNullTan is are specialty functions that are called by ExtremeDataAnalysis. countNullDims counts the number of null spaces of a given size in a list and  countNullTan counts the number of pairs of a fixed kernel and tangent space size *)

Options[countNullDims]:={AnalyzeIrredOnly-> True}
countNullDims[list_,n_,OptionsPattern[]]:=Block[{iterate,count,AnalyzeIrredOnly},
iterate=1;
count=0;
If[SameQ[OptionValue[AnalyzeIrredOnly],True],
While[iterate<= Length[list],
If[SameQ[list[[iterate,7]],n]&&SameQ[list[[iterate,9]],True],
count=count+1];
iterate=iterate+1];
If[SameQ[count,0],Return[0],Return[{n,count}]],
While[iterate<= Length[list],
If[SameQ[list[[iterate,7]],n],
count=count+1];
iterate=iterate+1];
If[SameQ[count,0],Return[0],Return[{n,count}]]]]

Options[countNullTan]:={AnalyzeIrredOnly-> True}
countNullTan[list_,n_,m_,OptionsPattern[]]:=Block[{iterate,count,AnalyzeIrredOnly},
iterate=1;
count=0;
If[SameQ[OptionValue[AnalyzeIrredOnly],True],
While[iterate<= Length[list],
If[SameQ[list[[iterate,7]],n]&&SameQ[list[[iterate,8]],m]&&SameQ[list[[iterate,9]],True],
count=count+1];
iterate=iterate+1];
If[SameQ[count,0],Return[0],Return[{n,m,count}]],
While[iterate<= Length[list],
If[SameQ[list[[iterate,7]],n]&&SameQ[list[[iterate,8]],m],
count=count+1];
iterate=iterate+1];
If[SameQ[count,0],Return[0],Return[{n,m,count}]]]]


(* ExtremeDataAnalysis takes a list generated by GenerateExtremeData and counts the number of points with specificed null space size and null space tangent space size pairs for Arveson and Euclidean extreme points *)

Options[ExtremeDataAnalysis]:={AnalyzeIrredOnly-> True}
ExtremeDataAnalysis[A_,list_,OptionsPattern[]]:=Block[{n,d,g,listLength,ReducibleArvEucCount,ArvesonPointList,ArvesonListIterate,BadNullNumerics,BadSystemNumerics,BadNullNumericsList,BadNullNumericsIterateList,EuclideanPointList,NonExtremePointList,NonExtremePointCount,ArvesonPointCount,EuclideanPointCount,ArvesonNullData,EuclideanNullData,ArvesonPointsCounted,EuclideanPointsCounted,ArvesonTangentData,EuclideanTangentData,IrredArvCount,IrredEucCount,AnalyzeIrredOnly},
n=Length[list[[1,1,1]]];
d=Length[A[[1]]];
g=Length[list[[1,1]]];
listLength=Length[list];
ArvesonPointList={};
BadNullNumericsList={};
BadNullNumericsIterateList={};
EuclideanPointList={};
ArvesonListIterate=1;

While[ArvesonListIterate<= listLength,
If[SameQ[list[[ArvesonListIterate,3]],True],ArvesonPointList=Append[ArvesonPointList,list[[ArvesonListIterate]]],
If[SameQ[list[[ArvesonListIterate,3]],BadNullNumerics]||SameQ[list[[ArvesonListIterate,3]],BadSystemNumerics],BadNullNumericsList=Append[BadNullNumericsList,list[[ArvesonListIterate]]];
BadNullNumericsIterateList=Append[BadNullNumericsIterateList,ArvesonListIterate];,
If[SameQ[list[[ArvesonListIterate,3]],False]&&SameQ[list[[ArvesonListIterate,5]],True],EuclideanPointList=Append[EuclideanPointList,list[[ArvesonListIterate]]]]]];
;
ArvesonListIterate=ArvesonListIterate+1];
NonExtremePointList=Complement[list,Join[ArvesonPointList,BadNullNumericsList,EuclideanPointList]];
ReducibleArvEucCount=Length[Join[ArvesonPointList,EuclideanPointList]]-CountIrreducibles[Join[ArvesonPointList,EuclideanPointList]];

NonExtremePointCount=Length[NonExtremePointList];
ArvesonPointCount=Length[ArvesonPointList];
EuclideanPointCount=Length[EuclideanPointList];

If[ArvesonPointCount!= 0,ArvesonNullData=DeleteZeros[Table[countNullDims[ArvesonPointList,l,AnalyzeIrredOnly-> OptionValue[AnalyzeIrredOnly]],{l,0,d*n}]];,
ArvesonNullData=False];

If[EuclideanPointCount!= 0,EuclideanNullData=DeleteZeros[Table[countNullDims[EuclideanPointList,l,AnalyzeIrredOnly-> OptionValue[AnalyzeIrredOnly]],{l,0,d*n}]];,
EuclideanNullData=False];

IrredArvCount=CountIrreducibles[ArvesonPointList];
IrredEucCount=CountIrreducibles[EuclideanPointList];
If[Length[ArvesonNullData]!= 0,ArvesonTangentData=Map[DeleteZeros,Table[countNullTan[ArvesonPointList,l,k],{l,ArvesonNullData[[1,1]],ArvesonNullData[[Length[ArvesonNullData],1]]},{k,-n*(n-1)/2,n*(n+1)*g/2}]];,
ArvesonTangentData=False];
If[Length[EuclideanNullData]!= 0,EuclideanTangentData=Map[DeleteZeros,Table[countNullTan[EuclideanPointList,l,k],{l,EuclideanNullData[[1,1]],EuclideanNullData[[Length[EuclideanNullData],1]]},{k,-n*(n-1)/2,n*(n+1)*g/2}]];,
EuclideanTangentData=False];
Return[{ArvesonNullData,IrredArvCount,ArvesonTangentData,EuclideanNullData,IrredEucCount,EuclideanTangentData,{BadNullNumericsIterateList,Length[BadNullNumericsIterateList]},ReducibleArvEucCount,NonExtremePointCount,EuclideanPointList} ]] 


(* FindExtremeAndAnalyze is an all in one function that generates data using GenerateExtremeData then prints the analysis given by ExtremeDataAnalysis *)

Options[FindExtremeAndAnalyze]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),ChopCutoff-> 10^(-3),TolGap-> 10^(-9),AnalyzeIrredOnly-> True,OutputFile->False, Sig->0,MyFunctional->MakeFunctionalRational,MathematicaSDP-> True,Distribution-> "uniform",IntegerRange-> {-200000,200000},StepDenominator-> 100000,MonicLMI-> True}
FindExtremeAndAnalyze[A_,n_,DataLength_,Seed_,OptionsPattern[]]:=Block[{ExtremeDataTable,ExtremeAnalysisTable,EigMagTol,EigGapTol,NumericsAssessment,IrredAssessment,NumericsAssessmentTol,ChopCutoff,TolGap,AnalyzeIrredOnly,OutputFile,EuclideanFunctionalsTable,filename,filepath,fileStream,WeightVector,WeightMatrix,Sig,MyFunctional,MathematicaSDP,DiagnosticLevel,Distribution,IntegerRange,StepDenominator,MonicLMI},
ExtremeDataTable=GenerateExtremeData[A,n,DataLength,Seed,DiagnosticLevel->4,EigMagTol-> OptionValue[EigMagTol],MathematicaSDP-> OptionValue[MathematicaSDP],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff],TolGap-> OptionValue[TolGap], Sig->OptionValue[Sig],MyFunctional-> OptionValue[MyFunctional],Distribution-> OptionValue[Distribution],IntegerRange-> OptionValue[IntegerRange],StepDenominator-> OptionValue[StepDenominator],MonicLMI-> OptionValue[MonicLMI]];
ExtremeAnalysisTable=ExtremeDataAnalysis[A,ExtremeDataTable,AnalyzeIrredOnly-> OptionValue[AnalyzeIrredOnly]];
Do[Print[ExtremeAnalysisTable[[i]]],{i,Length[ExtremeAnalysisTable]-1}];
If[SameQ[OptionValue[OutputFile],False]==False,
EuclideanFunctionalsTable=Table[ExtremeAnalysisTable[[10,i,2]],{i,Length[ExtremeAnalysisTable[[10]]]}];
filename=StringJoin[OptionValue[OutputFile]," n=",ToString[n]," iter=", ToString[DataLength], " seed=", ToString[Seed],".m"];
filepath=FileNameJoin[{$TemporaryDirectory,filename}];
fileStream=OpenWrite[filename];
WriteLine[fileStream,"The number functionals found that generate non-Arveson extreme points is"];
Write[fileStream,Length[EuclideanFunctionalsTable]];
WriteLine[fileStream," "];
WriteLine[fileStream, "This data was generated on "];
Write[fileStream,DateString[]];
WriteLine[fileStream,"The following linear functionals generate non-Arveson extreme points on the spectrahedron"];
WriteLine[fileStream," "];
Write[fileStream,A];
WriteLine[fileStream," "];
WriteLine[fileStream,"at level "];
Write[fileStream, n];
WriteLine[fileStream," "];
Write[fileStream,EuclideanFunctionalsTable];
WriteLine[fileStream," "];
Close[fileStream]];
Return[{ExtremeDataTable,ExtremeAnalysisTable}];]


(* MakeIrreducibleBoundedA makes a g tuple of d x d matrices A which define a bounded irreducible free spectrahedron. This is done randomly using the given seed. *)
Options[MakeIrreducibleBoundedA]:={Distribution->"uniform"}
MakeIrreducibleBoundedA[g_,d_,seed_,OptionsPattern[]]:=Block[{PreTuple,SymTuple,GoodQ,Distribution},
BlockRandom[
SeedRandom[seed];
GoodQ=False;
While[GoodQ==False||BoundedQ,
If[OptionValue[Distribution]=="uniform",
	PreTuple=Table[RandomInteger[{-25,25}]/10,{k,g},{j,d},{i,d}];
];
If[OptionValue[Distribution]=="gaussian",
	PreTuple=Table[RandomReal[NormalDistribution[0, 1]],{k,g},{j,d},{i,d}];
];
SymTuple=PreTuple+Map[Transpose,PreTuple];
If[CommutantDimension[SymTuple][[1]]==1&&BoundedQ[SymTuple],GoodQ=True];];
Return[SymTuple]]]

(* MakeIrreducibleBoundedA makes a g tuple of d x d matrices A which define a bounded irreducible free spectrahedron. This is done randomly but does not require a seed input*)
Options[MakeIrreducibleBoundedANoSeed]:={Distribution->"uniform",MathematicaSDP->True}
MakeIrreducibleBoundedANoSeed[g_,d_,OptionsPattern[]]:=Block[{PreTuple,SymTuple,GoodQ, numRejected,Distribution,MathematicaSDP},
GoodQ=False;
numRejected = 0;
While[GoodQ==False||BoundedQ,
If[OptionValue[Distribution]=="uniform",
	PreTuple=Table[RandomInteger[{-25,25}]/10,{k,g},{j,d},{i,d}];
];
If[OptionValue[Distribution]=="gaussian",
	PreTuple=Table[RandomReal[NormalDistribution[0, 1]],{k,g},{j,d},{i,d}];
];
SymTuple=PreTuple+Map[Transpose,PreTuple];
If[CommutantDimension[SymTuple][[1]]==1&&BoundedQ[SymTuple,MathematicaSDP->OptionValue[MathematicaSDP]],GoodQ=True,numRejected+=1;];];
Return[{SymTuple,numRejected}]]

Options[MakeIrreducibleA]:={Distribution->"uniform"}
MakeIrreducibleA[g_,d_,seed_,OptionsPattern[]]:=Block[{PreTuple,SymTuple,IrreducibleQ,Distribution},
BlockRandom[SeedRandom[seed];
IrreducibleQ=False;
While[IrreducibleQ==False,
If[OptionValue[Distribution]=="uniform",
	PreTuple=Table[RandomInteger[{-25,25}]/10,{k,g},{j,d},{i,d}];
];
If[OptionValue[Distribution]=="gaussian",
	PreTuple=Table[RandomReal[NormalDistribution[0, 1]],{k,g},{j,d},{i,d}];
];
SymTuple=PreTuple+Map[Transpose,PreTuple];
If[CommutantDimension[SymTuple][[1]]==1,IrreducibleQ=True];];
Return[SymTuple]]]

MakeBoundedA[g_,d_,seed_]:=Block[{PreTuple,SymTuple,GoodQ,testedTuples},
BlockRandom[SeedRandom[seed];
GoodQ=False;
While[GoodQ==False||BoundedQ,
PreTuple=Table[RandomInteger[{-25,25}]/10,{k,g},{j,d},{i,d}];
SymTuple=PreTuple+Map[Transpose,PreTuple];
If[BoundedQ[SymTuple],GoodQ=True];];
Return[SymTuple]]]


GrabNonArvesonExtreme[list_]:=Block[{EucTable},
EucTable={};
Do[If[SameQ[list[[1,i,3]],False]==True&&SameQ[list[[1,i,5]],True]==True&&SameQ[list[[1,i,9]],True]==True,EucTable=Append[EucTable,list[[1,i]]]],{i,Length[list[[1]]]}];
Return[EucTable]]


Options[MakeMatrixSigned]:={Distribution->"uniform",IntegerRange-> {-200000,200000},StepDenominator-> 100000}
MakeMatrixSigned[d_,Sig_,OptionsPattern[]]:=Block[{M,Signa,Signat,Distribution,IntegerRange,StepDenominator},
If[OptionValue[Distribution]=="uniform",
M=Table[RandomInteger[{Min[OptionValue[IntegerRange]],Max[OptionValue[IntegerRange]]}]/OptionValue[StepDenominator],{i,d},{j,d}];];
If[OptionValue[Distribution]=="gaussian",
M=Table[RandomReal[NormalDistribution[0, 1]],{i,d},{j,d}];];
For[i=1,i<=d,i++,
For[j=1,j<i,j++,
M[[i,j]]=0;
]
];
Signa=Floor[Sig];
If[Signa<0,Signa=0];
If[Signa>d,Signa=d];
Signat=DiagonalMatrix[Join[Table[1,{i,d-Signa}],Table[-1,{i,Signa}]]];
M=ConjugateTranspose[M] . Signat . M;
Return[M];
]

Options[MakeBlockLinearFunctional]:={WeightMatrix->Null, Sig->0}
MakeBlockLinearFunctional[A_,n_,OptionsPattern[]]:=Block[{M,MBlock,GenX,g,d,WeightMatrix,Sig},
g=Length[A];
d=Length[A[[1]]];
GenX=MakeX[g,n];
If[SameQ[OptionValue[WeightMatrix],Null],
M=MakeMatrixSigned[d,OptionValue[Sig]];
MBlock=KroneckerProduct[M,IdentityMatrix[n]];,
M=OptionValue[WeightMatrix];
MBlock=KroneckerProduct[M,IdentityMatrix[n]]];
Return[{M,Simplify[Tr[MBlock . LMI[A,GenX]]]/(d*n)}];
]

Options[MakeFunctionalTrace]:={WeightMatrix->Null, Sig->0,Distribution->"uniform",IntegerRange-> {-200000,200000},StepDenominator-> 100000}
MakeFunctionalTrace[A_,n_,OptionsPattern[]]:=Block[{M,GenX,g,d,WeightMatrix,Sig,Signat,Distribution,IntegerRange,StepDenominator},
g=Length[A];
d=Length[A[[1]]];
GenX=MakeX[g,n];
Signat=Floor[OptionValue[Sig]];
If[Signat<0,Signat=0];
If[Signat>d*n,Signat=d*n];
If[SameQ[OptionValue[WeightMatrix],Null],
M=MakeMatrixSigned[d*n,Signat,Distribution-> OptionValue[Distribution],IntegerRange-> OptionValue[IntegerRange],StepDenominator-> OptionValue[StepDenominator]];,
If[Length[OptionValue[WeightMatrix]]==d*n&&Length[OptionValue[WeightMatrix][[1]]]==d*n,
M=OptionValue[WeightMatrix],
Print["WARNING: The WeightMatrix Option does not have the correct format."];
Return[Null];];];
Return[{M,Simplify[Tr[M . LMI[A,GenX]]]/(d*n)}];
]

GrabFunctionalCoefs[g_,n_,Functional_]:=Normal[CoefficientArrays[Functional,Variables[MakeX[g,n]]]][[2]]


(* BoundedQ maximizes and minimizes coordinate linear functionals over a spectrahedron which has been intersected with a cube of radius OptionValue[Radius]. The spectrahedron is reported to be unbounded if the optimizers have magnitude larger than OptionValue[ReferenceRadiusRation] times the radius of the cube. *)
Options[BoundedQ]:={Radius->1000, TolGap-> 10^(-9), ReferenceRadiusRatio->.99,MathematicaSDP->True,MonicLMI-> True}
BoundedQ[A_,OptionsPattern[]]:=Block[{g, d, cube, Radius, AugmentedA, Xg, lmi, SDPVars, sdp, Y, Z, S, flags, SDPWeight, SDPFunctional,TolGap,X,rule,ExtremeX,constraint,ReferenceRadiusRatio,MathematicaSDP,MonicLMI,Xlength},
g=Length[A];
d=Length[A[[g]]];
If[SameQ[OptionValue[MonicLMI],False],Xlength=g-1;
cube=Join[{IdentityMatrix[2*Xlength]},Table[DiagonalMatrix[Join[ConstantArray[0,2(j-1)],{1,-1},ConstantArray[0,2(Xlength-j)]]],{j,Xlength}]/OptionValue[Radius]];
,Xlength=g;
cube=Table[DiagonalMatrix[Join[ConstantArray[0,2(j-1)],{1,-1},ConstantArray[0,2(g-j)]]],{j,g}]/OptionValue[Radius];];
AugmentedA=DirectSumTuple[{A, cube}];
Xg = MakeX[Xlength, 1];
lmi = LMI[AugmentedA, Xg];
SDPVars = MakeSDPVars[Xg];
(* If OptinValue[MathematicaSDP] is True then use MMA SDP. *)
If[SameQ[OptionValue[MathematicaSDP],True],
(* First minimize linear functionals *)
For[i=1, i<=Xlength, i++,
	{SDPWeight, SDPFunctional} = MakeFunctionalRational[Xlength, 1, Symbol["WeightVector"] -> Join[ConstantArray[0,(i-1)],{1},ConstantArray[0,(Xlength-i)]]];
		constraint=VectorGreaterEqual[{lmi,0},{"SemidefiniteCone",d+2*Xlength}];
		rule=Quiet[SemidefiniteOptimization[SDPFunctional,constraint,SDPVars]];
		ExtremeX=Xg/.rule;
	If[Max[Abs[ExtremeX]]/OptionValue[Radius] > OptionValue[ReferenceRadiusRatio],
		Return[False];
	]
];
(* Next maximize Linear Functionals *)
For[i=1, i<=Xlength, i++,
	{SDPWeight, SDPFunctional} = MakeFunctionalRational[Xlength, 1, Symbol["WeightVector"] -> Join[ConstantArray[0,(i-1)],{-1},ConstantArray[0,(Xlength-i)]]];
		constraint=VectorGreaterEqual[{lmi,0},{"SemidefiniteCone",d+2*Xlength}];
		rule=Quiet[SemidefiniteOptimization[SDPFunctional,constraint,SDPVars]];
		ExtremeX=Xg/.rule;
	If[Max[Abs[ExtremeX]]/OptionValue[Radius] > OptionValue[ReferenceRadiusRatio],
		Return[False];
	]
];,
(* If OptionValue[MathematicaSDP] is not true then use NC SDP. Again minimize linear functionals first.  *)
For[i=1, i<=Xlength, i++,
	{SDPWeight, SDPFunctional} = MakeFunctionalRational[Xlength, 1, Symbol["WeightVector"] -> Join[ConstantArray[0,(i-1)],{1},ConstantArray[0,(Xlength-i)]]];
	sdp = SDPMatrices[SDPFunctional, lmi, SDPVars];
	{Y,Z,S,flags}=SDPSolve[sdp,Symbol["GapTol"]-> OptionValue[TolGap],Symbol["FeasibilityTol"]-> 10.^(3)*OptionValue[TolGap],Symbol["PrintIterations"]-> False,Symbol["PrintSummary"]-> False];
	If[Max[Abs[Y[[1,1]]]]/OptionValue[Radius] > OptionValue[ReferenceRadiusRatio],
		Return[False];
	]
];
(* Maximize linear functionals *)
For[i=1, i<=Xlength, i++,
	{SDPWeight, SDPFunctional} = MakeFunctionalRational[Xlength, 1, Symbol["WeightVector"] -> Join[ConstantArray[0,(i-1)],{-1},ConstantArray[0,(Xlength-i)]]];
	sdp = SDPMatrices[SDPFunctional, lmi, SDPVars];
	{Y,Z,S,flags}=SDPSolve[sdp,Symbol["GapTol"]-> OptionValue[TolGap],Symbol["FeasibilityTol"]-> 10.^(3)*OptionValue[TolGap],Symbol["PrintIterations"]-> False,Symbol["PrintSummary"]-> False];
	If[Max[Abs[Y[[1,1]]]]/OptionValue[Radius] > OptionValue[ReferenceRadiusRatio],
		Return[False];
	]
];];
Return[True];
]



(* ::Section:: *)
(*Extreme point generation for (A,ell) pair experiments.*)


(* ::Text:: *)
(* In these functions, a user specifies g and d rather than a defining tuple A. The defining tuples used are then randomly generated tuples of size (g,d) which define bounded irreducible free spectrahedra *)


(* ::Input::Initialization:: *)
Options[FindExtremeAndAnalyze2]:={Distribution->"uniform", EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,IrredAssessment-> True,NumericsAssessmentTol-> 10^(-2),ChopCutoff-> 10^(-3),TolGap-> 10^(-9),AnalyzeIrredOnly-> True,OutputFile->False,WeightVector-> Null,WeightMatrix->Null, Sig->0,MyFunctional->MakeFunctionalRational,MathematicaSDP->True,IntegerRange-> {-200000,200000},StepDenominator-> 100000}
FindExtremeAndAnalyze2[g_,d_,n_,DataLength_,Seed_,OptionsPattern[]]:=Block[{Distribution,s,ExtremeDataTable,ExtremeAnalysisTable,EigMagTol,EigGapTol,NumericsAssessment,IrredAssessment,NumericsAssessmentTol,ChopCutoff,TolGap,AnalyzeIrredOnly,OutputFile,EuclideanFunctionalsTable,filename,filepath,fileStream,WeightVector,WeightMatrix,Sig,MyFunctional,MathematicaSDP,IntegerRange,StepDenominator},
ExtremeDataTable=GenerateExtremeData2[g,d,n,DataLength,Seed,Distribution->OptionValue[Distribution],EigMagTol-> OptionValue[EigMagTol],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],IrredAssessment-> OptionValue[IrredAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff],TolGap-> OptionValue[TolGap],WeightVector->OptionValue[WeightVector],WeightMatrix->OptionValue[WeightMatrix], Sig->OptionValue[Sig],MyFunctional-> OptionValue[MyFunctional],MathematicaSDP->OptionValue[MathematicaSDP],IntegerRange-> OptionValue[IntegerRange],StepDenominator-> OptionValue[StepDenominator]];
ExtremeAnalysisTable=ExtremeDataAnalysis2[g,d,ExtremeDataTable,AnalyzeIrredOnly-> OptionValue[AnalyzeIrredOnly]];
Do[Print[ExtremeAnalysisTable[[i]]],{i,Length[ExtremeAnalysisTable]-1}];
If[SameQ[OptionValue[OutputFile],False]==False,
EuclideanFunctionalsTable=Table[ExtremeAnalysisTable[[11,i,2]],{i,Length[ExtremeAnalysisTable[[11]]]}];
EuclideanSpecsTable=Table[ExtremeAnalysisTable[[11,i,12]],{i,Length[ExtremeAnalysisTable[[11]]]}];

BigKernelFunctionalsTable=Table[ExtremeAnalysisTable[[12,i,2]],{i,Length[ExtremeAnalysisTable[[12]]]}];
BigKernelSpecsTable=Table[ExtremeAnalysisTable[[12,i,12]],{i,Length[ExtremeAnalysisTable[[12]]]}];

filename=StringJoin[OptionValue[OutputFile]," n=",ToString[n]," iter=", ToString[DataLength], " seed=", ToString[Seed],".m"];
filepath=FileNameJoin[{$TemporaryDirectory,filename}];
fileStream=OpenWrite[filename];
WriteLine[fileStream,"The number functionals found that generate non-Arveson extreme points is"];
Write[fileStream,Length[EuclideanFunctionalsTable]];
WriteLine[fileStream,"The number functionals found that generate high kernel dimension (greater than ceiling(3n/2)) extreme points is"];
Write[fileStream,Length[BigKernelFunctionalsTable]];
WriteLine[fileStream," "];
WriteLine[fileStream, "This data was generated on "];
Write[fileStream,DateString[]];
s=StringJoin["The following are pairs {Spectrahedron, LinearFunctional} where LinearFunctional generates an Euclidean point on Spectrahedron with g=", ToString[g], " and d=", ToString[d], " at level n=", ToString[n]];
WriteLine[fileStream,s];
WriteLine[fileStream," "];
For[i=1,i<=Length[EuclideanSpecsTable],i++,
Write[fileStream,{EuclideanSpecsTable[[i]],EuclideanFunctionalsTable[[i]]}];
];
s=StringJoin["The following are pairs {Spectrahedron, LinearFunctional} where LinearFunctional generates an extreme point on Spectrahedron with g=", ToString[g], " and d=", ToString[d], " at level n=", ToString[n], " such that k>ceiling(3n/2)."];
WriteLine[fileStream,s];
WriteLine[fileStream," "];
For[i=1,i<=Length[BigKernelSpecsTable],i++,
Write[fileStream,{BigKernelSpecsTable[[i]],BigKernelFunctionalsTable[[i]]}];
];

Close[fileStream]];
Return[{ExtremeDataTable,ExtremeAnalysisTable}];]


Options[GenerateExtremeData2]={Distribution->"uniform", EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,IrredAssessment-> True,NumericsAssessmentTol-> 10^(-2),ChopCutoff-> 10^(-3),TolGap-> 10^(-9),WeightVector-> Null,WeightMatrix->Null,Sig->0,MyFunctional-> MakeFunctionalRational, MathematicaSDP->True,IntegerRange-> {-200000,200000},StepDenominator-> 100000};
GenerateExtremeData2[g_,d_,n_,DataLength_,Seed_,OptionsPattern[]]:=Block[{Distribution,DataTable,EigMagTol,EigGapTol,NumericsAssessment,IrredAssessment,NumericsAssessmentTol,ChopCutoff,TolGap,WeightMatrix,Sig,WeightVector,MyFunctional,MathematicaSDP,IntegerRange,StepDenominator},
BlockRandom[SeedRandom[Seed];
DataTable=Table[FindExtremePoint2[g,d,n,Distribution->OptionValue[Distribution], EigMagTol-> OptionValue[EigMagTol],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],IrredAssessment-> OptionValue[IrredAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff],TolGap-> OptionValue[TolGap],WeightVector->OptionValue[WeightVector],WeightMatrix->OptionValue[WeightMatrix], Sig->OptionValue[Sig],MyFunctional->OptionValue[MyFunctional],MathematicaSDP->OptionValue[MathematicaSDP],IntegerRange-> OptionValue[IntegerRange],StepDenominator-> OptionValue[StepDenominator]],{i,1,DataLength}];
Return[DataTable]]]


Options[ExtremeDataAnalysis2]:={AnalyzeIrredOnly-> True}
ExtremeDataAnalysis2[g_,d_,list_,OptionsPattern[]]:=Block[{numRejected,n,listLength,ReducibleArvEucCount,ArvesonPointList,ArvesonListIterate,BadNullNumerics,BadSystemNumerics,BadNullNumericsList,BadNullNumericsIterateList,EuclideanPointList,NonExtremePointList,NonExtremePointCount,ArvesonPointCount,EuclideanPointCount,ArvesonNullData,EuclideanNullData,ArvesonPointsCounted,EuclideanPointsCounted,ArvesonTangentData,EuclideanTangentData,IrredArvCount,IrredEucCount,AnalyzeIrredOnly,BigKernelPointList},
n=Length[list[[1,1,1]]];
listLength=Length[list];
ArvesonPointList={};
BadNullNumericsList={};
BadNullNumericsIterateList={};
EuclideanPointList={};
BigKernelPointList={};
ArvesonListIterate=1;
numRejected = 0;

For[i=1,i<=Length[list],i++,
numRejected+=list[[i,11]];
]

While[ArvesonListIterate<= listLength,
If[SameQ[list[[ArvesonListIterate,3]],True],ArvesonPointList=Append[ArvesonPointList,list[[ArvesonListIterate]]],
If[SameQ[list[[ArvesonListIterate,3]],BadNullNumerics]||SameQ[list[[ArvesonListIterate,3]],BadSystemNumerics],BadNullNumericsList=Append[BadNullNumericsList,list[[ArvesonListIterate]]];
BadNullNumericsIterateList=Append[BadNullNumericsIterateList,ArvesonListIterate];,
If[SameQ[list[[ArvesonListIterate,3]],False]&&SameQ[list[[ArvesonListIterate,5]],True],EuclideanPointList=Append[EuclideanPointList,list[[ArvesonListIterate]]]]]];
;
ArvesonListIterate=ArvesonListIterate+1];
NonExtremePointList=Complement[list,Join[ArvesonPointList,BadNullNumericsList,EuclideanPointList]];
ReducibleArvEucCount=Length[Join[ArvesonPointList,EuclideanPointList]]-CountIrreducibles[Join[ArvesonPointList,EuclideanPointList]];

NonExtremePointCount=Length[NonExtremePointList];
ArvesonPointCount=Length[ArvesonPointList];
EuclideanPointCount=Length[EuclideanPointList];

If[ArvesonPointCount!= 0,ArvesonNullData=DeleteZeros[Table[countNullDims[ArvesonPointList,l,AnalyzeIrredOnly-> OptionValue[AnalyzeIrredOnly]],{l,0,d*n}]];,
ArvesonNullData=False];

If[EuclideanPointCount!= 0,EuclideanNullData=DeleteZeros[Table[countNullDims[EuclideanPointList,l,AnalyzeIrredOnly-> OptionValue[AnalyzeIrredOnly]],{l,0,d*n}]];,
EuclideanNullData=False];

ArvesonListIterate=1;
While[ArvesonListIterate<= listLength,
If[n>=2&&((SameQ[list[[ArvesonListIterate,3]],BadNullNumerics]||SameQ[list[[ArvesonListIterate,3]],BadSystemNumerics])==False)&&list[[ArvesonListIterate,7]]>Ceiling[3*n/2],BigKernelPointList=Append[BigKernelPointList,list[[ArvesonListIterate]]];
];
;
ArvesonListIterate=ArvesonListIterate+1];
IrredArvCount=CountIrreducibles[ArvesonPointList];
IrredEucCount=CountIrreducibles[EuclideanPointList];
If[Length[ArvesonNullData]!= 0,ArvesonTangentData=Map[DeleteZeros,Table[countNullTan[ArvesonPointList,l,k],{l,ArvesonNullData[[1,1]],ArvesonNullData[[Length[ArvesonNullData],1]]},{k,-n*(n-1)/2,n*(n+1)*g/2}]];,
ArvesonTangentData=False];
If[Length[EuclideanNullData]!= 0,EuclideanTangentData=Map[DeleteZeros,Table[countNullTan[EuclideanPointList,l,k],{l,EuclideanNullData[[1,1]],EuclideanNullData[[Length[EuclideanNullData],1]]},{k,-n*(n-1)/2,n*(n+1)*g/2}]];,
EuclideanTangentData=False];
Return[{ArvesonNullData,IrredArvCount,ArvesonTangentData,EuclideanNullData,IrredEucCount,EuclideanTangentData,{BadNullNumericsIterateList,Length[BadNullNumericsIterateList]},ReducibleArvEucCount,NonExtremePointCount,numRejected,EuclideanPointList, BigKernelPointList} ]] 


(* FindExtremePoint2 randomly generates a tuple A of size (g,d) which defines a bounded irreducible free spectrahedron, then optimizes a random linear functional over D_A at level n *)
Options[FindExtremePoint2]:={Distribution->"uniform", EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,IrredAssessment-> True,NumericsAssessmentTol-> 10^(-2),TestExtremePointType->True,MyFunctional-> MakeFunctionalRational,ChopCutoff-> 10^(-3),TolGap-> 10^(-9),WeightVector-> Null,WeightMatrix->Null, Sig->0, MathematicaSDP->True,IntegerRange-> {-200000,200000},StepDenominator-> 100000}
FindExtremePoint2[g_,d_,n_,OptionsPattern[]]:=Block[{Distribution,numRejected,ExtremeX,SDPFunctional,X,Xg,lmi,MyFunctional,SDPVars,sdp,XRule,A,Y,Z,S,flags,ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance,PencilEigenvalues,NullSpaceAnalysis,NullSpaceDimension,TangentAnalysis,TangentSpaceDimension,X1Diag,TestExtremePointType,IrredAssessment,IrredData,CommDim,CommTol,ChopCutoff,TolGap,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,WeightVector,WeightMatrix,Sig,MathematicaSDP,IntegerRange,StepDenominator},
{A,numRejected}=MakeIrreducibleBoundedANoSeed[g,d,Distribution->OptionValue[Distribution],MathematicaSDP->OptionValue[MathematicaSDP]];
(* Calls appropriate Generate extreme point function to generate an extreme point candadite. Will Generate an extreme point that has X1 diagonal if X1Diag option is True *)
{ExtremeX,SDPFunctional}=GenerateExtremePoint[A,g,n,Distribution->OptionValue[Distribution],MyFunctional-> OptionValue[MyFunctional],ChopCutoff-> OptionValue[ChopCutoff],TolGap->OptionValue[TolGap],WeightMatrix->OptionValue[WeightMatrix], Sig->OptionValue[Sig],WeightVector-> OptionValue[WeightVector],MathematicaSDP->OptionValue[MathematicaSDP],IntegerRange-> OptionValue[IntegerRange],StepDenominator-> OptionValue[StepDenominator]];

(* If TestExtremePointType is True then ClassifyExtremePoint is run. ClassifyExtremePoint first determines if an extreme point is Arveson. If it is not Arveson then it checks to see if the extreme point is Euclidean. *)
 If[OptionValue[TestExtremePointType]==True,
{ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance}=ClassifyExtremePoint[A,ExtremeX,EigMagTol->OptionValue[EigMagTol],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol]]; ];
PencilEigenvalues=Eigenvalues[LMI[A,ExtremeX]];
NullSpaceAnalysis=DetermineNull[PencilEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol]][[1]];
If[SameQ[NullSpaceAnalysis,False],NullSpaceDimension=False,If[SameQ[NullSpaceAnalysis,BadNumerics],NullSpaceDimension=BadNullNumerics,NullSpaceDimension=n*d-NullSpaceAnalysis+1]];
TangentSpaceDimension=FreeTangentNumerical[A,ExtremeX];

If[SameQ[OptionValue[IrredAssessment],False],IrredData="Not Analyzed",
If[SameQ[n,1],{CommDim,CommTol}={True,0},
IrredData=CommutantDimension[ExtremeX,EigMagTol-> OptionValue[EigMagTol]*10^(-3),EigGapTol-> OptionValue[EigGapTol]*10^-3,NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff]*10^(-5)];
If[Length[IrredData]<2,{CommDim,CommTol}={1,0},
If[SameQ[IrredData[[1]],1],{CommDim,CommTol}={True,IrredData[[2]]},{CommDim,CommTol}={IrredData[[1]],IrredData[[2]]}]]]];
Return[{ExtremeX,SDPFunctional,ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance,NullSpaceDimension,TangentSpaceDimension,CommDim,CommTol,numRejected,A}]]


(* ::Section:: *)
(*Statistics from extreme point data*)


(* ::Text:: *)
(* These functions are used for generating various statistics about extreme points found using extreme point generation commands *)


(* ::Input::Initialization:: *)
  Options[GeneratePDFFromTable]:= {}
GeneratePDFFromTable[g_,d_,n_,list_, OptionsPattern[]] := Block[{listLength,ReducibleArvEucCount,ArvesonPointList,ArvesonListIterate,BadNullNumerics,BadSystemNumerics,BadNullNumericsList,BadNullNumericsIterateList,EuclideanPointList,NonExtremePointList,NonExtremePointCount,ArvesonPointCount,EuclideanPointCount,ArvesonNullData,EuclideanNullData,ArvesonPointsCounted,EuclideanPointsCounted,ArvesonTangentData,EuclideanTangentData,IrredArvCount,IrredEucCount,AnalyzeIrredOnly,ArvesonIrredNullData,EuclideanIrredNullData,TotalArv,TotalIrredArv,TotalEuc,TotalIrredEuc},
	listLength=Length[list];
	ArvesonPointList={};
	BadNullNumericsList={};
	BadNullNumericsIterateList={};
	EuclideanPointList={};
	ArvesonListIterate=1;

	While[ArvesonListIterate<= listLength,
	If[SameQ[list[[ArvesonListIterate,3]],True],ArvesonPointList=Append[ArvesonPointList,list[[ArvesonListIterate]]],
	If[SameQ[list[[ArvesonListIterate,3]],BadNullNumerics]||SameQ[list[[ArvesonListIterate,3]],BadSystemNumerics],BadNullNumericsList=Append[BadNullNumericsList,list[[ArvesonListIterate]]];
	BadNullNumericsIterateList=Append[BadNullNumericsIterateList,ArvesonListIterate];,
	If[SameQ[list[[ArvesonListIterate,3]],False]&&SameQ[list[[ArvesonListIterate,5]],True],EuclideanPointList=Append[EuclideanPointList,list[[ArvesonListIterate]]]]]];
	ArvesonListIterate=ArvesonListIterate+1];
	ArvesonPointCount=Length[ArvesonPointList];
	EuclideanPointCount=Length[EuclideanPointList];

	If[ArvesonPointCount!= 0,ArvesonNullData=DeleteZeros[Table[countNullDims[ArvesonPointList,l,AnalyzeIrredOnly-> False],{l,0,d*n}]];,
	ArvesonNullData=False];
	If[EuclideanPointCount!= 0,EuclideanNullData=DeleteZeros[Table[countNullDims[EuclideanPointList,l,AnalyzeIrredOnly-> False],{l,0,d*n}]];,
	EuclideanNullData=False];
	If[ArvesonPointCount!= 0,ArvesonIrredNullData=DeleteZeros[Table[countNullDims[ArvesonPointList,l,AnalyzeIrredOnly-> True],{l,0,d*n}]];,
	ArvesonIrredNullData=False];
	If[EuclideanPointCount!= 0,EuclideanIrredNullData=DeleteZeros[Table[countNullDims[EuclideanPointList,l,AnalyzeIrredOnly-> True],{l,0,d*n}]];,
	EuclideanIrredNullData=False];
	
	TotalArv = 0;
	TotalIrredArv = 0;
	TotalEuc = 0;
	TotalIrredEuc = 0;
	
	For[i=1,i<=Length[ArvesonNullData],i++,
		TotalArv += ArvesonNullData[[i,2]];
	];
	For[i=1,i<=Length[ArvesonIrredNullData],i++,
		TotalIrredArv += ArvesonIrredNullData[[i,2]];
	];
	For[i=1,i<=Length[EuclideanNullData],i++,
		TotalEuc += EuclideanNullData[[i,2]];
	];
	For[i=1,i<=Length[EuclideanIrredNullData],i++,
		TotalIrredEuc += EuclideanIrredNullData[[i,2]];
	];
	
	For[i=1,i<=Length[ArvesonNullData],i++,
		ArvesonNullData[[i,2]] /= TotalArv;
	];
	For[i=1,i<=Length[ArvesonIrredNullData],i++,
		ArvesonIrredNullData[[i,2]] /= TotalIrredArv;
	];
	For[i=1,i<=Length[EuclideanNullData],i++,
		EuclideanNullData[[i,2]] /= TotalEuc;
	];
	For[i=1,i<=Length[EuclideanIrredNullData],i++,
		EuclideanIrredNullData[[i,2]] /= TotalIrredEuc;
	];
Return[{ArvesonNullData,ArvesonIrredNullData,EuclideanNullData,EuclideanIrredNullData}]]

Options[GenerateCDFFromTable]:= {}
GenerateCDFFromTable[g_,d_,n_,list_, OptionsPattern[]] := Block[{ArvesonNullData,ArvesonIrredNullData,EuclideanNullData,EuclideanIrredNullData},
	{ArvesonNullData,ArvesonIrredNullData,EuclideanNullData,EuclideanIrredNullData} = GeneratePDFFromTable[g,d,n,list];
	
	For[i=2,i<=Length[ArvesonNullData],i++,
		ArvesonNullData[[i,2]]+=ArvesonNullData[[i-1,2]];
	];
	For[i=2,i<=Length[ArvesonIrredNullData],i++,
		ArvesonIrredNullData[[i,2]]+=ArvesonIrredNullData[[i-1,2]];
	];
	For[i=2,i<=Length[EuclideanNullData],i++,
		EuclideanNullData[[i,2]]+=EuclideanNullData[[i-1,2]];
	];
	For[i=2,i<=Length[EuclideanIrredNullData],i++,
		EuclideanIrredNullData[[i,2]]+=EuclideanIrredNullData[[i-1,2]];
	];
	Return[{ArvesonNullData,ArvesonIrredNullData,EuclideanNullData,EuclideanIrredNullData}]
]

Options[GenerateKerDimListFromTable]:= {}
GenerateKerDimListFromTable[d_,n_,list_, OptionsPattern[]] := Block[{listLength,ReducibleArvEucCount,ArvesonPointList,ArvesonListIterate,BadNullNumerics,BadSystemNumerics,BadNullNumericsList,BadNullNumericsIterateList,EuclideanPointList,NonExtremePointList,NonExtremePointCount,ArvesonPointCount,EuclideanPointCount,ArvesonNullData,EuclideanNullData,ArvesonPointsCounted,EuclideanPointsCounted,ArvesonTangentData,EuclideanTangentData,IrredArvCount,IrredEucCount,AnalyzeIrredOnly,ArvesonIrredNullData,EuclideanIrredNullData,TotalArv,TotalIrredArv,TotalEuc,TotalIrredEuc,ArvesonData,ArvesonIrredData,EuclideanData,EuclideanIrredData},
	listLength=Length[list];
	ArvesonPointList={};
	BadNullNumericsList={};
	BadNullNumericsIterateList={};
	EuclideanPointList={};
	ArvesonListIterate=1;
	While[ArvesonListIterate<= listLength,
	If[SameQ[list[[ArvesonListIterate,3]],True],ArvesonPointList=Append[ArvesonPointList,list[[ArvesonListIterate]]],
	If[SameQ[list[[ArvesonListIterate,3]],BadNullNumerics]||SameQ[list[[ArvesonListIterate,3]],BadSystemNumerics],BadNullNumericsList=Append[BadNullNumericsList,list[[ArvesonListIterate]]];
	BadNullNumericsIterateList=Append[BadNullNumericsIterateList,ArvesonListIterate];,
	If[SameQ[list[[ArvesonListIterate,3]],False]&&SameQ[list[[ArvesonListIterate,5]],True],EuclideanPointList=Append[EuclideanPointList,list[[ArvesonListIterate]]]]]];
	ArvesonListIterate=ArvesonListIterate+1];
	ArvesonPointCount=Length[ArvesonPointList];
	EuclideanPointCount=Length[EuclideanPointList];

	If[ArvesonPointCount!= 0,ArvesonNullData=DeleteZeros[Table[countNullDims[ArvesonPointList,l,AnalyzeIrredOnly-> False],{l,0,d*n}]];,
	ArvesonNullData=False];
	If[EuclideanPointCount!= 0,EuclideanNullData=DeleteZeros[Table[countNullDims[EuclideanPointList,l,AnalyzeIrredOnly-> False],{l,0,d*n}]];,
	EuclideanNullData=False];
	If[ArvesonPointCount!= 0,ArvesonIrredNullData=DeleteZeros[Table[countNullDims[ArvesonPointList,l,AnalyzeIrredOnly-> True],{l,0,d*n}]];,
	ArvesonIrredNullData=False];
	If[EuclideanPointCount!= 0,EuclideanIrredNullData=DeleteZeros[Table[countNullDims[EuclideanPointList,l,AnalyzeIrredOnly-> True],{l,0,d*n}]];,
	EuclideanIrredNullData=False];
	
	ArvesonData = {};
	For[i=1,i<=Length[ArvesonNullData],i++,
		ArvesonData = Join[ArvesonData,Table[ArvesonNullData[[i,1]],ArvesonNullData[[i,2]]]];
	];
	EuclideanData = {};
	For[i=1,i<=Length[EuclideanNullData],i++,
		EuclideanData = Join[EuclideanData,Table[EuclideanNullData[[i,1]],EuclideanNullData[[i,2]]]];
	];
	ArvesonIrredData = {};
	For[i=1,i<=Length[ArvesonIrredNullData],i++,
		ArvesonIrredData = Join[ArvesonIrredData,Table[ArvesonIrredNullData[[i,1]],ArvesonIrredNullData[[i,2]]]];
	];
	EuclideanIrredData = {};
	For[i=1,i<=Length[EuclideanIrredNullData],i++,
		EuclideanIrredData = Join[EuclideanIrredData,Table[EuclideanIrredNullData[[i,1]],EuclideanIrredNullData[[i,2]]]];
	];
	
	Return[{ArvesonData,ArvesonIrredData,EuclideanData,EuclideanIrredData}]
]

End[]
EndPackage[]


(* ::Section:: *)
(*Version History*)


(* ::Text:: *)
(*Version history for NCSE. *)
(**)
(*17 Feb 2021 Version 2.3.0*)
(**)
(*Updated NearFlatAssessment and related code. The code now produces more detailed tables, and is more modular. *)
(*Updated use of random seeds so that setting a random seed in an NCSE function does not affect the random seed in a notebook. *)
(**)
(*E.g. Previously if the user called MakeIrreducibleA[3,4,100], then the random seed in the entire MMA notebook would be set to 100, thus all random number generator calls after calling MakeIrreducibleA would be impacted. Now the random seed is only set locally to the function.*)
(**)
(**)
(**)
(*30Oct 2020 Version 2.2.1*)
(**)
(*Removed DilationAssessment from NCSE and created a subpackage for NCSE which contains DilationAssessment*)
(**)
(*Updated TupleNorm to work on nonsymmetric matrices. Also fixed a error where TupleNorm failed to use matrix power. *)
(**)
(*15 Sept 2020 Version 2.1*)
(**)
(*1. Added several functions. These are:*)
(**)
(*DilationAssessment*)
(*NonArvProjOntoNearFlat*)
(*FreeTangentMemberTest*)
(*FreeTangentBasis*)
(*BetaCommutantDimension*)
(*RelaxedMatrixExtremeTest*)
(*DilateToArveson*)
(*DilateToEuclidean*)
(**)
(*2. Minor improvements to FreeTangentNumerical.*)
(**)
(*20 August 2020 Version 2.0.2.2*)
(**)
(*1. Fixed a bug where Maximal1Dilation would choke is DilationSubspace was unable to compute a basis for the dilation subspace due to numerical issues, e.g. if the null space of an one of the matrices involved in the computation could not be determined. *)
(*2. Added very basic functionality for working with "nonfree" nonmonic LMI. *)
(**)
(*6 July 2020 Version 2.0.2.1*)
(**)
(*Made Level1ExtremePlot plot the convex hull of the points in the g=2 case.*)
(**)
(*29 May 2020 Version 2.0.2*)
(**)
(*1. Greatly improved the speed of FreeTangentNumerical. At the default DiagnosticLevel, FindExtremePoint calls FreeTangentNumerical. The  overall FindExtremePoint with default DiagnosticLevel is greatly improved as well.*)
(*2. Added the "RandomBeta" option to Maximal1Dilation. If set True, a random beta from the dilation subspace will be used to compute a maximal 1 dilation, rather than the default beta.*)
(*3. Added all options present in Maximal1Dilation to Maximal1DilationRepeated. Previously Maximal1DilationRepeated had no options. *)
(*4. Added "NCSEVersion" function which returns a string telling the user their current version of NCSE. *)
(**)
(*Added option in Maximal1Dilation to choose a random beta from the dilation subspace for dilating, rather than the beta given by the first column of the matrix representing the dilation subspace. *)
(**)
(*21 Apr 2020*)
(**)
(*1. Added "IntegerRange" and "StepDenominator" options to several functions. IntegerRange allows for user specified ranges when RandomInteger is called e.g. in generation of random linear functionals. StepDenominator is a divisor the generated random integers. *)
(*2. Updated name of GenerateExtremeAndAnalyze2 to FindExtremeAndAnalyze2 to be consistent with other names. Added GenerateExtremeAndAnalyze2 to the NCSEBackwardsCompatible.m*)
(*3. Added Distribution in FindExtremePoint and all functions calling this function. Currently available options are "uniform" and "gaussian". FindExtremePoint2 already supports the Distribution option.*)
(*4. Updated the NCSE.usage file. Several functions previously have had options added which were not explained in the usage. *)
(*5. Fixed a crash that could occur when using DilationSubspaceBasis and DilationSubspaceDimension with nonmonic pencils.*)
(*6. Extended support for nonmonic linear pencils.  *)
(**)
(*7 Feb 2020*)
(**)
(*Added the "Distribution" option to several functions. *)
(*Changed BoundedQ to use MathematicaSDP by default and added the MathematicaSDP function.*)
(*Fixed erroneously placed quotation marks in usage file which caused several issues. *)
(**)
(*17 Jan 2020*)
(**)
(*Reorganized body of notebook. Added descriptions to several functions. *)
(**)
(*Added reconciled version differences. Several functions had been added in another version for working with randomly generated A. These functions were added to the main branch *)
(**)
(*Removed the following functions which are no longer supported.*)
(*1. DiagonalGammaSearch*)
(*2. ArvesonDilateOnZero*)
(*3. ArvesonDoubleDilateOnZero*)
(**)
(*Dec 2020 *)
(**)
(*1. Converted almost all functions to used mathematica SDP by default. *)
(*2. Added support for non Monic LMIs*)
(**)
(*29 Aug 2019 *)
(**)
(*1. Fixed bug in interaction of CommutantDimension and FindExtremePoint that in rare situations caused n(n+1)/2 dimensional commutant to be reported as 1 dimensional. Fortuantely FindExtremePoint reports "True" *)
(* for irreducible points rather than returning a commutant dimension, so in the eyes of FindExtremeAndAnalyze, these points were still considered reducible. .*)
(*2. Fixed possible bug in DetermineNull. In all cases where DetermineNull is used in the package, the input list is ordered from largest to smallest magnitutde. However a bug could occur if DetermineNull is given a list which is not ordered in this way. DetermineNull now orders lists from largest to smallest magnitutde *)
(**)
(**)
(*20May 2018 *)
(**)
(*Finished Functionality for MakeFunctionalTrace and MakeBlockFunctional in FindExtremePoint and GenerateExtreme and Analyze. These make linear functionals of the form Trace[M.LMI[A,X]] and Trace[M otimes I . LMI[A,X]], respectively.*)
(**)
(*Removed option to make functional with nonrational coefficients, and removed option to in FindExtremePoint to generate tuple with X1 diagonal. These have not been used in experiments. *)
(**)
(*15Apr 2018*)
(**)
(*1. Removed outdated functions for package version.*)
(*2. Changed FindExtremePointNoPrint to FindExtremePoint, and changed all calls for FindExtremePointNoPrint to FindExtremePointPrint. Removed old FindExtremePoint function.*)
(*3. Changed id and mf to IdentityMatrix and MatrixForm respectively. Short hand names will not be included in package.*)
(*4. Removed collection of LMI coefficients for package.*)
(*5. Changed write functionality in GenerateExtremeAndAnalyze to write to a directory*)
(*6. Changed write in GenerateExtremeAndAnalyze to output a table of linear functionals rather than individual linear functionals.*)
(**)
(*8 April 2018*)
(**)
(*Added the GrabNonArvesonExtreme function*)
(**)
(*6 April 2018 *)
(**)
(*1. Added a collection of functions to dilate Euclidean extreme to Arveson extreme. See functions whose name starts with "ArvesonDilate"*)
(*2. Added writing to generate extreme and analyze which writes functionals that generate Euclidean extreme points to an output file if an output name is specified.*)
(*3. Changed exact math to Numerical math in ArvesonTest and EuclideanTest to prevent kernel crashes*)
(*4. Closed comments left open in the preamble. *)
(*5. Added the TupleNorm utility function. This computes the 2 norm of a tuple. *)
(**)
(*26 March 2018 Fixed bug in GenerateExtremeAndAnalyze causing additional output. *)
(**)
(*18 March 2018: Added MakeIrreducibleA function which makes an irreducible g tuple of d x d symmetric matrices. Changed CommutantDimension to always use numerical arithemtic instead of exact.*)
(**)
(*15 March 2018:*)
(*1. Rearragned the functions under Extreme Point Generation and Classification section of preamble. Moved functions into subsubsections based on use. Identified and grouped currently unsupported functions.*)
(**)
(* 2. Added several utility functions. These are*)
(* *)
(* LeftMultTuple*)
(* RightMultTuple*)
(* TupleConj*)
(* ViewTuple*)
(* ArvTanVec*)
(* *)
(**)
(*10 March 2018: Bug fixes in ExtremeDataAnalysis. First bug caused points with BadSystemNumerics as Arveson True False value to be reported as Euclidean extreme points. The second bug caused points which were neither Arveson nor Euclidean extreme to be reported as Euclidean extreme points.*)
(**)
(*ExtremeDataAnalysis now outputs the number of points which are neither Arveson or Euclidean, although does not output data on these points. Additionally, the number reducible Arveson and Euclidean extreme points is now output.*)
(**)
(*7 March 2018: Fixed a bug in DeterimeNull that occured when the list contained negative values.*)
(**)
(*13 Feb 2018: Made new all in one function for extreme point generation and data analysis named "GenerateExtremeAndAnalyze". IMPORTANT: By default GenerateExtremeAndAnalyze only looks at irreducible points when generating data.*)


(* ::Text:: *)
(*2 February 2018: Updated ArvesonTest and EuclideanTest to work by solving the appropriate Kernel containment conditions. This should greatly improve speed and precision. Nullspace sizes are now determined using the DetermineNull command. This command finds a null space by looking for sufficiently sized gaps and small eigenvalues. Certain eigenvalue lists will cause the command to return "BadNullNumerics". This is intended to occur when the command cannot adequately *)
(* asses which values should be zero and which should not. An example of a list which should return this is {1,10^(-3),10^(-7),10^(-10)}. The issue is that 10^(-10) is likely 0, but the gaps between 10^(-10) and 10^(-7) and 10^(-3) are poor. It is also hard to say if 10^(-7) should be 0. *)
(* *)
(* ExtremePointListKernelAnalysis has been updated to handle when BadNullNumerics is returned by FindExtremePointNoPrint.*)
(* *)
(* Many old functions, including FindExtremePoint, may be broken after this update. The key functions, ArvesonTest, EuclideanTest, FindExtremePointNoPrint, and ExtremePointListKernelAnalysis should all be working. *)
(**)
(**)
(**)
(**)
(*20 November 2017: Replaced Substitute with NCReplaceRepeated throughout the notebook.*)
(**)
(*Restructured the main functions into one chapter which has several subsections for related types of functions. This is in hopes of making it easier to find a specific function in the future. Furthermore, this makes it so that all that needs to be compiled is the "Main Functions" section in order to work with the notebook. Old functions or functions that failed to meet their intended purpose are moved into the unsupported chapter. This section should not be compiled as it could break other sections. It has been kept in case we ever want to work with the functions again.*)
(**)
(*Add several variables to blocks which had failed to be put in the block previously. *)
(**)
(*Added a function to count kernel data for a list of extreme points. The function is ExtremePointListKernelAnalysis found in the Utilities section*)
(**)
(*Removed an extraneous print[] from ClassifyExtremePoint. This was previously generating lots of undesired blank lines in large data generation tests.*)
