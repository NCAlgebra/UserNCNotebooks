(* ::Package:: *)
(* This file was created in 21Aug2018 because there were some changes in command names. *)

BeginPackage["NCSEBackwardsCompatible`",{"NCSE`"}]

MakeTraceFunctional=MakeFunctionalTrace;

MakeRationalFunctional=MakeFunctionalRational;

MakeFunctional=MakeFunctionalReal;

MakePositiveMatrix=MakeMatrixSigned;

GenerateExtremeAndAnalyze=FindExtremeAndAnalyze;

Get["NCSEBackwardsCompatible.usage"];

Begin["`Private`"];

Options[GenerateExtremePoint]:={MyFunctional-> MakeFunctionalRational,ChopCutoff-> 10^(-3),TolGap-> 10^(-9),WeightVector-> Null,WeightMatrix->Null, Sig->0}
GenerateExtremePoint[A_,g_,n_,OptionsPattern[]]:=Block[{ArvesonTolerance,ArvesonQ,ExtremeX,EuclideanQ,EuclideanTolerance,lmi,MyFunctional,SDPVars,sdp,XRule,retVal,Y,Z,S,flags,OutputFileName,PencilEigenvalues,SDPFunctional,SDPWeight,Sig,TraceAnalysisValue,WeightMatrix,WeightVector,X,Xg},
Return[FindExtremePoint[A,n,DiagnosticLevel->1,ChopCutoff-> OptionValue[ChopCutoff],TolGap-> OptionValue[TolGap], Sig->OptionValue[Sig],MyFunctional->OptionValue[MyFunctional],WeightVector-> OptionValue[WeightVector],WeightMatrix->OptionValue[WeightMatrix]]];
]

End[]
EndPackage[]