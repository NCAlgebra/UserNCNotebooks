(* ::Package:: *)

BeginPackage["NCSE`",{"NCReplace`","SDP`"}]

Get["NCSE.usage"];
X;
Y;
Z;
BadNullNumerics;

Begin["`Private`"];

(*This section includes the basic functions used in the notebook. Examples include direct sum computation of a list of matrices, LMI evaluation and manipulation (such as Eigenvalue calculations), linear functional generation, random matrix generation, and and basic Variable Generation. The basic variables are used in Extreme Point generation and classification.*)


(* ::Input::Initialization:: *)
(* EqualsZero sets equation\[Equal]0 *)
EqualsZero[equation_]:=Equal[equation,0]

(* Takes the direct sum of a list *)
DirectSum[list_]:=Block[{M},
M=list[[1]];
Do[M=ArrayFlatten[{{M,0},{0,list[[i+1]]}}],{i,Length[list]-1}];
M]

DirectSumTuple[tuples_]:=Block[{g,T},
g=Length[tuples[[1]]];
T=Table[DirectSum[tuples[[All,j]]],{j,g}];
T]

(* Just calculates an LMI *)
LMI[A_,X_]:=KroneckerProduct[IdentityMatrix[Length[A[[1]]]],IdentityMatrix[Length[X[[1]]]]]-Sum[KroneckerProduct[A[[i]],X[[i]]],{i,Length[X]}];
Lambda[A_,X_]:=Sum[KroneckerProduct[A[[i]],X[[i]]],{i,Length[X]}]

(* Calculates eigenvalues of LMI evaluated on X *)

PencilEig[A_,X_]:=Eigenvalues[LMI[A,X]];

(* Generates a symmetric g-tuple of n x n matrices*)
MakeX[g_,n_]:=Block[{X},
Table[If[i<j,X[k,i,j],X[k,j,i]],{k,g},{i,n},{j,n}]]

MakeY[n_]:=Block[{Y},
Table[If[i<j,Y[i,j],Y[j,i]],{i,n},{j,n}]]

MakeZ[g_,n_]:=Block[{Z},
Table[If[i<j,Z[k,i,j],Z[k,j,i]],{k,g},{i,n},{j,n}]]

MakeZArv[g_,n_]:=Block[{Z},
Table[{Table[Z[k,j],{j,n}]},{k,g}]]

(* Generates a random linear functional on symmetric g-tuples of n x n matrices *)
MakeFunctionalReal[g_,n_]:=Sum[Sum[Sum[RandomReal[{-1,1}]*X[k,i,j],{i,j}],{j,n}],{k,g}];

(*Generates a random linear functional with rational coefficients on symmetric g-tuples of n times n matrices *)
Options[MakeFunctionalRational]:={WeightVector-> Null}
MakeFunctionalRational[g_,n_,OptionsPattern[]]:=Block[{Functional,FunctionalLength,FunctionalVariables,FunctionalWeight,WeightVector},


(* A functional will be made by taking innerproduct of FunctionalVariables with a weight vector FunctionalWeight *)
FunctionalVariables=Variables[MakeX[g,n]];
FunctionalLength=Length[FunctionalVariables];

(* The following if loop determines how to make FunctionalWeight. First is a check if the Option WeightVector is a vector which has the same number of entries as variables in FunctionalVariables *)
If[SameQ[Head[OptionValue[WeightVector]],List]&&SameQ[Length[OptionValue[WeightVector]],FunctionalLength],
FunctionalWeight=OptionValue[WeightVector],

(* If Option WeightVector is NOT a vector which has the same number of entries as variables in FunctionalVariables, check if WeightVector has the default value of Null. In this case, create a random weight vector *)
If[SameQ[OptionValue[WeightVector],Null],
FunctionalWeight=Table[RandomInteger[{-200,200}]/100,{k,FunctionalLength}],

(* If Option WeightVector does not have either of the previous forms, create a random FunctionalWeight, but also print a Warning to the user that their option does not have the correct form *)

FunctionalWeight=Table[RandomInteger[{-200,200}]/100,{k,FunctionalLength}];
Print["WARNING: The WeightVector Option does not have the correct format."];
Return[Null];];];
Functional=Dot[FunctionalWeight,FunctionalVariables];
Return[{FunctionalWeight,Functional}]]

(* Indices are switched in the problem. This is a tool for switching back *)
FindIndex[n_,k_,i_,j_]:=(k-1)*(n^2+n)/2+Sum[n+1-s,{s,i}]+j-n

(* Indices are switched in the problem. This is a tool for switching back in the case X1 is diagonal*)
FindIndexDiag[n_,k_,i_,j_]:=If[k==1,i,((k-1)*(n^2+n)/2+Sum[n+1-s,{s,i}]+j-n)-Binomial[n+1,2]+n]

(* Rule for subsituting in to Xg after running the SDP *)
MakeXRule[g_,n_]:=Flatten[Table[X[k,i,j]->  Y[[1,1,FindIndex[n,k,i,j]]],{k,g},{j,n},{i,j}]]

(* Finds the variables the SDP is in from the input Xg. Stores this in SDPVars *)
MakeSDPVars[MatrixTuple_]:=DeleteDuplicates[Flatten[MatrixTuple]];

(* Makes a column vector beta that will be used in the test to see if the extreme point is arverson *)
MakeBeta[g_,n_]:=Block[{beta},
Table[Transpose[{Table[beta[k,j],{j,n}]}],{k,g}]]

(* Makes a symmetric beta to be used in the test to see if beta is Euclidean *)
MakeSymBeta[g_,n_]:=Block[{SymBeta},
Table[If[i<j,SymBeta[k,i,j],SymBeta[k,j,i]],{k,g},{i,n},{j,n}]]

(* Create a list of zeros with the appriate size to check beta=0 against for the Euclidean test *)
MakeZeroSymBetaList[g_,n_]:={{Table[0,{k,g*(n(n+1))/2}]}}

(* Create a list of zeros with the appriate size to check beta=0 against for the Arveson test *)
MakeZeroBetaList[g_,n_]:={{Table[0,{k,g*n}]}}

(* Makes the matrix {{Extremepoint, Beta},{Transpose[Beta],0}}   *)
MakeExtendX[Xg_,beta_,g_]:=Table[ArrayFlatten[{{Xg[[k]],beta[[k]]},{Transpose[beta[[k]]],0*IdentityMatrix[Length[beta[[1,1]]]]}}],{k,g}]

(* randmat generates a random r by c matrix with inputs which are rational numbers of the form j/10 for -10\[LessEqual] j\[LessEqual] 10 *)
randmat[r_,c_]:=Table[RandomInteger[{-10,10}]/10,{i,r},{j,c}]

(* Makegamma generates a g tuple of gamma n x n symmetric matrices with entires gamma[k,i,j]. *)
Makegamma[g_,n_]:=Block[{gamma},
Table[If[i<j,gamma[k,i,j],gamma[k,j,i]],{k,g},{i,n},{j,n}]]

MakeExtendXwithGamma[Xg_,beta_,g_]:=Block[{ExtendX,betaLength,gamma,gammag},
betaLength=Length[beta[[1,1]]];
gammag=Makegamma[g,betaLength];
ExtendX=Table[ArrayFlatten[{{Xg[[k]],beta[[k]]},{Transpose[beta[[k]]],gammag[[k]]}}],{k,g}]]

NullDimension[Mat_,Cutoff_]:=Count[Chop[Eigenvalues[Mat],Cutoff],0]

(* Determine Nulls attempts to decide what values should be called zero in a give list. The function looks for small values which have a large gap from the next value. By default, if the gap is not sufficiently large or small, the function reports that the numerics are poor. *)
Options[DetermineNull]:={NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2)}
DetermineNull[list_,EigMagTol_,EigGapTol_,OptionsPattern[]]:=Block[{AbsList,NullFound,iterate,EigGap,BestGap,NumericsAssessment,NumericsAssessmentTol,BadNumerics},
AbsList=Map[Abs,list];
If[AbsList[[1]]<= EigMagTol,
{Return[1],0}];
iterate=2;
NullFound=False;
BestGap=Infinity;
While[NullFound==False &&iterate<= Length[AbsList],
If[Abs[AbsList[[iterate]]]<= EigMagTol&&AbsList[[iterate]]/AbsList[[iterate-1]]<=  EigGapTol,
NullFound=True;
BestGap=AbsList[[iterate]]/AbsList[[iterate-1]],
If[AbsList[[iterate]]/AbsList[[iterate-1]]<BestGap,BestGap=AbsList[[iterate]]/AbsList[[iterate-1]]];
iterate=iterate+1;]];
If[SameQ[NullFound,True],Return[{iterate,BestGap}],If[SameQ[OptionValue[NumericsAssessment],True]&&BestGap*OptionValue[NumericsAssessmentTol]< EigGapTol,
Return[{BadNumerics,BestGap}],If[SameQ[OptionValue[NumericsAssessment],True]&&AbsList[[Length[list]]]<10^(-2)* EigMagTol,Return[{BadNumerics,BestGap}], Return[{False,BestGap}]]]]]


(* ::Section::Initialization::Closed:: *)
(*(*(*(*(*(*(*Free Tangent Planes and Commutants*)*)*)*)*)*)*)

Options[FreeTangentNumerical]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2)}
FreeTangentNumerical[A_,X_,OptionsPattern[]]:=Block[{g,n,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZEucMat,TangentEqsBasic,TangentEqs,TangentEqsTable,TangentSystemMat,TangentSystemEigVals,TangentSystemEigVecs,ZSolExistQ,ZSolConfidence,TangentQ,BadSystemNumerics},
g=Length[A];
n=Length[X[[1]]];
{LMIEigenvalues,LMIEigenvectors}=Eigensystem[LMI[A,X]];
{NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[NullVecStartIterate,False],Return[{False,NullConfidence,False,LMIEigenvalues}],
If[SameQ[NullVecStartIterate,BadNumerics],Return[{BadNullNumerics,{NullConfidence,BadNullNumerics}}],
NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
ZEucMat=MakeZ[g,n];
TangentEqsBasic=ConjugateTranspose[NullInclusionMatrix].Lambda[A,ZEucMat].NullInclusionMatrix;
TangentEqs=DeleteCases[DeleteCases[Flatten[TangentEqsBasic],0.],0];
TangentEqsTable=Table[TangentEqs[[i]]==0,{i,1,Length[TangentEqs]}];
TangentSystemMat=Normal[CoefficientArrays[TangentEqsTable,Variables[ZEucMat]]][[2]];
{TangentSystemEigVals,TangentSystemEigVecs}=Eigensystem[Transpose[TangentSystemMat].TangentSystemMat];
{ZSolExistQ,ZSolConfidence}=DetermineNull[TangentSystemEigVals,OptionValue[EigMagTol]*10^(-3),OptionValue[EigGapTol]*10^(-3),NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
TangentQ=If[SameQ[False,ZSolExistQ],0,
If[SameQ[ZSolExistQ,BadNumerics],BadSystemNumerics,Length[TangentSystemEigVals]-ZSolExistQ+1-n*(n-1)/2]];
Return[TangentQ]]]];

(* CommutantDimension determines the dimension of the commutant of the tuple X={X[[1]],X[[2]],...,X[[g]]}. by determining the dimension of the null space of the linear system Y.X[[i]]-X[[i]].Y\[Equal]0 for i=1,...,g. *)

Options[CommutantDimension]:={EigMagTol-> 10^(-9),EigGapTol-> 10^(-8),ChopCutoff->10^(-8),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2)}
CommutantDimension[X_,OptionsPattern[]]:=Block[{g,n,YMat,CommutantEqs,CommutantSystemMat,CommutantSystemEigVals,CommutantSystemEigVecs,CommSolExistQ,CommSolConfidence,EigMagTol,EigGapTol,ChopCutoff,NumericsAssessment,NumericsAssessmentTol,CommDim,BadNumerics,BadSystemNumerics},
g=Length[X];
n=Length[X[[1]]];
YMat=MakeY[n];
CommutantEqs=Map[EqualsZero,DeleteCases[Chop[Flatten[Table[YMat.X[[i]]-X[[i]].YMat,{i,g}]],OptionValue[ChopCutoff]],0]];
If[Length[CommutantEqs]==0,Return[n*(n+1)/2]];
CommutantSystemMat=N[Normal[CoefficientArrays[CommutantEqs,Variables[YMat]]][[2]]];
{CommutantSystemEigVals,CommutantSystemEigVecs}=Eigensystem[Transpose[CommutantSystemMat].CommutantSystemMat];
{CommSolExistQ,CommSolConfidence}=DetermineNull[CommutantSystemEigVals,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[CommSolExistQ,BadNumerics],CommDim=BadSystemNumerics,CommDim=Length[CommutantSystemEigVals]-CommSolExistQ+1];
Return[{CommDim,CommSolConfidence}]]



(* ::Section::Initialization:: *)
(*(*(*(*(*(*(*Extreme Point Generation and Classification*)*)*)*)*)*)*)


(* ::Text::Initialization:: *)
(*(*(*(*(*(*(*This section contains the major functions for extreme point generation and classification. There are two subsections. The first subsection is main subsection. In this section linear functionals are generated by randomly generating coefficients alpha in Sum alpha_i * variable_i. In this second section, the linear functionals are generated by using trace and a weight matrix. The functions in this section have been more successful in repeated dilations.*)*)*)*)*)*)*)


(* ::Subsection::Initialization:: *)
(*(*(*(*(*(*(*Nontrace Linear Functionals*)*)*)*)*)*)*)


(* ::Subsubsection::Initialization:: *)
(*(*(*(*(*(*(*Extreme Point Classification*)*)*)*)*)*)*)


(* ::Input::Initialization:: *)
(* Solves the Kernel Containment linear system to determine if a point is Arveson *) 
Options[ArvesonTest]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2)}
ArvesonTest[A_,X_,OptionsPattern[]]:=Block[{g,n,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZArvMat,NullContainmentEqsBasic,NullContainmentEqs,NullContainmentTable,NullSystemMat,NullSystemEigVals,NullSystemEigenVecs,ZSolExistQ,ZSolConfidence,ArvesonQ,BadSystemNumerics},
g=Length[A];
n=Length[X[[1]]];
{LMIEigenvalues,LMIEigenvectors}=Eigensystem[LMI[A,X]];
{NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[NullVecStartIterate,False],Return[{False,{NullConfidence,False,LMIEigenvalues}}],
If[SameQ[NullVecStartIterate,BadNumerics],Return[{BadNullNumerics,{NullConfidence,BadNullNumerics}}],
NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
ZArvMat=MakeZArv[g,n];
NullContainmentEqsBasic=Lambda[A,ZArvMat].NullInclusionMatrix;
NullContainmentEqs=DeleteCases[DeleteCases[Flatten[NullContainmentEqsBasic],0.],0];
NullContainmentTable=Table[NullContainmentEqs[[i]]==0,{i,1,Length[NullContainmentEqs]}];
NullSystemMat=N[Normal[CoefficientArrays[NullContainmentTable,Variables[ZArvMat]]][[2]]];
{NullSystemEigVals,NullSystemEigenVecs}=Eigensystem[Transpose[NullSystemMat].NullSystemMat];
{ZSolExistQ,ZSolConfidence}=DetermineNull[NullSystemEigVals,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
ArvesonQ=If[SameQ[False,ZSolExistQ],True,
If[SameQ[ZSolExistQ,BadNumerics],BadSystemNumerics,False]];
Return[{ArvesonQ,{NullConfidence,ZSolConfidence}}]]]]


(* ArvesonTestSystemMat returns the matrix which represents the eqs for the linear system for testing if a matrix is Arveson. This is used for more careful analysis by hand. *) 
Options[ArvesonTestSystem]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2)}
ArvesonTestSystem[A_,X_,OptionsPattern[]]:=Block[{g,n,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZArvMat,NullContainmentEqsBasic,NullContainmentEqs,NullContainmentTable,NullSystemMat,NullSystemEigVals,NullSystemEigenVecs,ZSolExistQ,ZSolConfidence,ArvesonQ,BadSystemNumerics},
g=Length[A];
n=Length[X[[1]]];
{LMIEigenvalues,LMIEigenvectors}=Eigensystem[LMI[A,X]];
{NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[NullVecStartIterate,False],Return[{False,{NullConfidence,False,LMIEigenvalues}}],
If[SameQ[NullVecStartIterate,BadNumerics],Return[{BadNullNumerics,{NullConfidence,BadNullNumerics}}],
NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
ZArvMat=MakeZArv[g,n];
NullContainmentEqsBasic=Lambda[A,ZArvMat].NullInclusionMatrix;
NullContainmentEqs=DeleteCases[DeleteCases[Flatten[NullContainmentEqsBasic],0.],0];
NullContainmentTable=Table[NullContainmentEqs[[i]]==0,{i,1,Length[NullContainmentEqs]}];
NullSystemMat=N[Normal[CoefficientArrays[NullContainmentTable,Variables[ZArvMat]]][[2]]];
(*{NullSystemEigVals,NullSystemEigenVecs}=Eigensystem[Transpose[NullSystemMat].NullSystemMat];
{ZSolExistQ,ZSolConfidence}=DetermineNull[NullSystemEigVals,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment\[Rule] OptionValue[NumericsAssessment],NumericsAssessment\[Rule] OptionValue[NumericsAssessmentTol]];
ArvesonQ=If[SameQ[False,ZSolExistQ],True,
If[SameQ[ZSolExistQ,BadNumerics],BadSystemNumerics,False]];*)
Return[NullSystemMat]]]]




(* Solves the appropriate kernel containment system to determine if a given point is Euclidean Extreme *) 

Options[EuclideanTest]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2)}
EuclideanTest[A_,X_,OptionsPattern[]]:=Block[{g,n,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZEucMat,NullContainmentEqsBasic,NullContainmentEqs,NullContainmentTable,NullSystemMat,NullSystemEigVals,NullSystemEigenVecs,ZSolExistQ,ZSolConfidence,EuclideanQ,BadSystemNumerics},
g=Length[A];
n=Length[X[[1]]];
{LMIEigenvalues,LMIEigenvectors}=Eigensystem[LMI[A,X]];
{NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[NullVecStartIterate,False],Return[{False,{NullConfidence,False,LMIEigenvalues}}],
If[SameQ[NullVecStartIterate,BadNumerics],Return[{BadNullNumerics,{NullConfidence,BadNullNumerics}}],
NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
ZEucMat=MakeZ[g,n];
NullContainmentEqsBasic=Lambda[A,ZEucMat].NullInclusionMatrix;
NullContainmentEqs=DeleteCases[DeleteCases[Flatten[NullContainmentEqsBasic],0.],0];
NullContainmentTable=Table[NullContainmentEqs[[i]]==0,{i,1,Length[NullContainmentEqs]}];
NullSystemMat=N[Normal[CoefficientArrays[NullContainmentTable,Variables[ZEucMat]]][[2]]];
{NullSystemEigVals,NullSystemEigenVecs}=Eigensystem[Transpose[NullSystemMat].NullSystemMat];
{ZSolExistQ,ZSolConfidence}=DetermineNull[NullSystemEigVals,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
EuclideanQ=If[SameQ[False,ZSolExistQ],True,
If[SameQ[ZSolExistQ,BadNumerics],BadSystemNumerics,False]];
Return[{EuclideanQ,{NullConfidence,ZSolConfidence}}]]]]

(* ClassifyExtremePoint first determines if an extreme point is Arveson. If it is not Arveson then it checks to see if the extreme point is Euclidean. This is just a combination of the ArvesonTest and EuclideanTest commands. *)
Options[ClassifyExtremePoint]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),PrintExtremeData-> False}
ClassifyExtremePoint[A_,ExtremePoint_,OptionsPattern[]]:=Block[{g,n,ArvesonQ,ArvesonTolerance,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,EuclideanQ,EuclideanTolerance,PrintExtremeData},

{ArvesonQ,ArvesonTolerance}=ArvesonTest[A,ExtremePoint,EigMagTol->OptionValue[EigMagTol],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol]];

If[SameQ[ArvesonQ,True], 
EuclideanQ=True;
EuclideanTolerance=ArvesonTolerance;
If[OptionValue[PrintExtremeData]==True,
(Print["The point is an Arveson extreme point"];
Print["The Arveson tolerance was"];
Print[ArvesonTolerance];
Print[];)],
If[OptionValue[PrintExtremeData]==True,(Print["The point is not an Arveson extreme point"];
Print["The Arveson tolerance was"];
Print[ArvesonTolerance];
Print[];)];

{EuclideanQ,EuclideanTolerance}=EuclideanTest[A,ExtremePoint,EigMagTol->OptionValue[EigMagTol],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol]];

If[OptionValue[PrintExtremeData]==True,
If[SameQ[EuclideanQ,True],
Print["The point is a Euclidean extreme point"];
Print["The Euclidean tolerance was"];
Print[EuclideanTolerance];
Print[];,Print[];,
Print["The point is not a Euclidean extreme point"];
Print["The Euclidean tolerance was"];
Print[EuclideanTolerance];
Print[];]];];

Return[{ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance}];]




(* ::Subsubsection::Initialization:: *)
(*(*(*(*(*(*(*Extreme Point Generation*)*)*)*)*)*)*)


(* ::Input::Initialization:: *)
(* Generates an Extreme Point candidate. Returns the extreme point and the linear functional that was used to generate the point *)
Options[GenerateExtremePoint]:={MyFunctional-> MakeFunctionalRational,ChopCutoff-> 10^(-3),TolGap-> 10^(-9),WeightVector-> Null,WeightMatrix->Null, Sig->0}
GenerateExtremePoint[A_,g_,n_,OptionsPattern[]]:=Block[{ArvesonTolerance,ArvesonQ,ExtremeX,EuclideanQ,EuclideanTolerance,lmi,MyFunctional,SDPVars,sdp,XRule,retVal,Y,Z,S,flags,OutputFileName,PencilEigenvalues,SDPFunctional,SDPWeight,Sig,TraceAnalysisValue,WeightMatrix,WeightVector,X,Xg},
Xg=MakeX[g,n];
lmi=LMI[A,Xg];
SDPVars=MakeSDPVars[Xg];
retVal=Null;
(* If the MyFunctional option is set to MakeFunctionalRational then a Random Rational Functional of the appropriate size is generated. If the MyFunctional option is set to a specfic functional then the SDP and the functional defined by the user in the MyFunctional option will be used*)

(* Execute if MyFunctional option is MakeFunctionalTrace. This makes a positive linear functional by taking Trace[W.LMI[A,X]] where W is given by WeightMatrix. If WeightMatrix is Null then it is randomly generated *)
If[SameQ[OptionValue[MyFunctional],MakeFunctionalTrace]==True,
retVal=MakeFunctionalTrace[A,n,WeightMatrix->OptionValue[WeightMatrix], Sig->OptionValue[Sig]];];

If[SameQ[OptionValue[MyFunctional],MakeFunctionalRational]==True,
(* Execute if MyFunctional option is MakeFunctionalRational. This makes a rational functional using the option for WeightVector. If WeightVector is Null then it is randomly generated *)
retVal=MakeFunctionalRational[g,n,WeightVector-> OptionValue[WeightVector]];]
(* If MyFunctional is not MakeFunctionalTrace, or MakeFunctionalRational, prints an Error message *)
If[SameQ[OptionValue[MyFunctional],MakeFunctionalRational]==False&&SameQ[OptionValue[MyFunctional],MakeFunctionalTrace]==False,
Print["WARNING: The value given for MyFunctional is incorrect or unsupported."];
Return[Null]];
If[retVal==Null,Return[Null]];
SDPWeight=retVal[[1]];
SDPFunctional=retVal[[2]];
sdp=SDPMatrices[SDPFunctional,lmi,SDPVars];
(* End if loop. SDP Run begins here *)
{Y,Z,S,flags}=SDPSolve[sdp,Symbol["GapTol"]-> OptionValue[TolGap],Symbol["FeasibilityTol"]-> 10.^(3)*OptionValue[TolGap],Symbol["PrintIterations"]-> False,Symbol["PrintSummary"]-> False];
Y=Chop[Y,OptionValue[ChopCutoff]*10^(-5)];
(* Set up substitution rule and substitute *)
XRule=MakeXRule[g,n];
ExtremeX=NCReplaceRepeated[Xg,XRule];
Return[{ExtremeX,SDPWeight}]]



(* FindExtremePoint is a version of FindExtremePoint that prints no output and generates much less diagnostic inforomation *)

Options[FindExtremePoint]:={DiagnosticLevel->4, EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),MyFunctional-> MakeFunctionalRational,ChopCutoff-> 10^(-3),TolGap-> 10^(-9),WeightVector-> Null,WeightMatrix->Null, Sig->0}
FindExtremePoint[A_,n_,OptionsPattern[]]:=Block[{retVal,ExtremeX,SDPFunctional,X,Xg,lmi,g,d,MyFunctional,SDPVars,sdp,XRule,Y,Z,S,flags,ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance,PencilEigenvalues,NullSpaceAnalysis,NullSpaceDimension,TangentAnalysis,TangentSpaceDimension,TestExtremePointType,IrredAssessment,IrredData,CommDim,CommTol,ChopCutoff,TolGap,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,WeightVector,WeightMatrix,Sig},
g=Length[A];
d=Length[A[[1]]];
(* Calls appropriate Generate extreme point function to generate an extreme point candadite. *)
retVal=GenerateExtremePoint[A,g,n,MyFunctional-> OptionValue[MyFunctional],ChopCutoff-> OptionValue[ChopCutoff],TolGap->OptionValue[TolGap],WeightMatrix->OptionValue[WeightMatrix], Sig->OptionValue[Sig],WeightVector-> OptionValue[WeightVector]];
If[retVal==Null,Return[Null]];
{ExtremeX,SDPFunctional}={retVal[[1]],retVal[[2]]};

If[OptionValue[DiagnosticLevel]==0,Return[ExtremeX]];
If[OptionValue[DiagnosticLevel]==1,Return[{ExtremeX,SDPFunctional}];];

(* If DiagnosticLevel is at least 2 then ClassifyExtremePoint is run. ClassifyExtremePoint first determines if an extreme point is Arveson. If it is not Arveson then it checks to see if the extreme point is Euclidean. *)
{ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance}=ClassifyExtremePoint[A,ExtremeX,EigMagTol->OptionValue[EigMagTol],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol]];
PencilEigenvalues=Eigenvalues[LMI[A,ExtremeX]];
NullSpaceAnalysis=DetermineNull[PencilEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol]][[1]];
If[SameQ[NullSpaceAnalysis,False],NullSpaceDimension=False,If[SameQ[NullSpaceAnalysis,BadNumerics],NullSpaceDimension=BadNullNumerics,NullSpaceDimension=n*d-NullSpaceAnalysis+1]];
TangentSpaceDimension=FreeTangentNumerical[A,ExtremeX];
If[OptionValue[DiagnosticLevel]==2,Return[{ExtremeX,SDPFunctional,ArvesonQ,EuclideanQ}];];
If[OptionValue[DiagnosticLevel]==3,Return[{ExtremeX,SDPFunctional,ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance}];];

If[SameQ[n,1],{CommDim,CommTol}={True,0},
IrredData=CommutantDimension[ExtremeX,EigMagTol-> OptionValue[EigMagTol]*10^(-3),EigGapTol-> OptionValue[EigGapTol]*10^-3,NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff]*10^(-5)];
If[Length[IrredData]<2,{CommDim,CommTol}={1,0},
If[SameQ[IrredData[[1]],1],{CommDim,CommTol}={True,IrredData[[2]]},{CommDim,CommTol}={IrredData[[1]],IrredData[[2]]}]]];
Return[{ExtremeX,SDPFunctional,ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance,NullSpaceDimension,TangentSpaceDimension,CommDim,CommTol}]]

(* GeneratePointData generates a table using FindExtremePoint *)
Options[GenerateExtremeData]={DiagnosticLevel->0,EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),ChopCutoff-> 10^(-3),TolGap-> 10^(-9),WeightVector-> Null,WeightMatrix->Null,Sig->0,MyFunctional-> MakeFunctionalRational};
GenerateExtremeData[A_,n_,DataLength_,Seed_,OptionsPattern[]]:=Block[{DataTable,EigMagTol,EigGapTol,NumericsAssessment,IrredAssessment,NumericsAssessmentTol,ChopCutoff,TolGap,WeightMatrix,Sig,WeightVector,MyFunctional},
SeedRandom[Seed];
DataTable=Table[FindExtremePoint[A,n,DiagnosticLevel->OptionValue[DiagnosticLevel],EigMagTol-> OptionValue[EigMagTol],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff],TolGap-> OptionValue[TolGap], Sig->OptionValue[Sig],MyFunctional->OptionValue[MyFunctional]],{i,1,DataLength}];
Return[DataTable]]



(* ::Subsubsection::Initialization::Closed:: *)
(*(*(*(*(*(*(*Dilations*)*)*)*)*)*)*)


(* ::Input::Initialization:: *)

(* DiagonalGammaSearch takes the tuple Y={{X,beta},{beta^*,gamma}} and looks for a diagonal \hat{gamma} so {{X,beta},{beta^*,\hat{gamma}}} which is in the spectrahedron A. The input k specifies the size of gamma. *)

Options[DiagonalGammaSearch]:={TolGap->10^(-9)};
DiagonalGammaSearch[A_,X_,k_,OptionsPattern[]]:=Block[{alpha,d,g,gamma,gamVars,gamSDPFunctional,gamLMI,gamSDP,gamY,gamZ,gamS,gamFlags,gamRu,MinSDPEig,n,PosTol,SDPVars,XGamDiag,XGamDiagEval,TolGap},
If[k<=0,Return[X]];
{g,n,d}={Length[X],Length[X[[1]]],Length[A[[1]]]};
XGamDiag=Table[If[j<=n-k||i<=n-k,X[[l,i,j]],If[j==i,gamma[l,i-n+k,j-n+k],0]],{l,g},{i,n},{j,n}];
gamVars=Variables[XGamDiag];
gamSDPFunctional={alpha};
gamLMI=LMI[A,XGamDiag]+alpha*IdentityMatrix[d*n];
SDPVars=Append[gamVars,alpha];
gamSDP=SDPMatrices[gamSDPFunctional,gamLMI,SDPVars];
{gamY,gamZ,gamS,gamFlags}=SDPSolve[gamSDP,GapTol-> OptionValue[TolGap],FeasibilityTol->OptionValue[TolGap],PrintSummary-> False,PrintIterations-> False];
gamRu=Table[Rule[SDPVars[[i]],gamY[[1,1,i]]],{i,Length[SDPVars]}];
XGamDiagEval=NCReplaceRepeated[XGamDiag,gamRu];
MinSDPEig=Min[Eigenvalues[NCReplaceRepeated[LMI[A,XGamDiag],gamRu]]];
PosTol=MinSDPEig;
Return[{XGamDiagEval,PosTol}]]


(* ArvesonDilateOnZero dilates X to {{X,beta},{beta^*,0}} while attempting to compute a maximal beta. This function has not had good success in generating maximal beta or Arveson Dilations *)

Options[ArvesonDilateOnZero]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),ChopCutoff-> 10^(-3),TolGap-> 10^(-9)}
ArvesonDilateOnZero[A_,X_,OptionsPattern[]]:=Block[{g,n,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZArvMat,ZArvVars,NullContainmentEqsBasic,NullContainmentEqs,NullContainmentTable,NullSystemMat,NullSystemEigVals,NullSystemEigenVecs,ZSolExistQ,ZSolConfidence,ArvesonQ,BadSystemNumerics,NullVecs,ZSubRus,DilateCoef,NextMaximalBeta,DilateBetaIterate,DilateBeta,DilateGamma,DilateX,DilateFunctional,DilateLMI,DilateVars,DilateSDP,DilateSDPY,DilateSDPZ,DilateSDPS,DilateSDPflags,TolGap,MaximalDilateRu,MaximalDilateX,DilationSize,DilationArvesonQ},
g=Length[A];
n=Length[X[[1]]];
MaximalDilateX=BadNumerics;
{LMIEigenvalues,LMIEigenvectors}=Eigensystem[LMI[A,X]];
{NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[NullVecStartIterate,False],Return[{False,NullConfidence,False,LMIEigenvalues}],
If[SameQ[NullVecStartIterate,BadNumerics],Return[{BadNullNumerics,{NullConfidence,BadNullNumerics}}],
NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
ZArvMat=MakeZArv[g,n];
ZArvVars=Variables[ZArvMat];
NullContainmentEqsBasic=Lambda[A,ZArvMat].NullInclusionMatrix;
NullContainmentEqs=DeleteCases[DeleteCases[Flatten[NullContainmentEqsBasic],0.],0];
NullContainmentTable=Table[NullContainmentEqs[[i]]==0,{i,1,Length[NullContainmentEqs]}];
NullSystemMat=Normal[CoefficientArrays[NullContainmentTable,ZArvVars]][[2]];
{NullSystemEigVals,NullSystemEigenVecs}=Eigensystem[Transpose[NullSystemMat].NullSystemMat];
{ZSolExistQ,ZSolConfidence}=DetermineNull[NullSystemEigVals,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
ArvesonQ=If[SameQ[False,ZSolExistQ],True,
If[SameQ[ZSolExistQ,BadNumerics],BadSystemNumerics,False]];
If[ArvesonQ==False,NullVecs=NullSystemEigenVecs[[ZSolExistQ;;Length[NullSystemEigenVecs]]];

ZSubRus=Table[Rule[ZArvVars[[i]],DilateCoef[j]*NullVecs[[j,i]]],{j,Length[NullVecs]},{i,Length[ZArvVars]}];

DilateBetaIterate=1;
NextMaximalBeta=ZArvMat;

While[DilateBetaIterate<= Length[NullVecs] ,
DilateBeta=NCReplaceRepeated[NextMaximalBeta,ZSubRus[[DilateBetaIterate]]];
NextMaximalBeta=Table[ArrayFlatten[{{DilateBeta[[i]]},{ZArvMat[[i]]}}],{i,g}];
DilateBetaIterate=DilateBetaIterate+1;];

DilateX=Table[ArrayFlatten[{{X[[i]],Transpose[DilateBeta[[i]]]},{DilateBeta[[i]],0*IdentityMatrix[Length[DilateBeta[[1]]]]}}],{i,g}];

DilateFunctional=Sum[DilateCoef[i],{i,Length[NullVecs]}];
DilateLMI=LMI[A,DilateX];
DilateVars=Variables[DilateX];
DilateSDP=SDPMatrices[DilateFunctional,DilateLMI,DilateVars];

{DilateSDPY,DilateSDPZ,DilateSDPS,DilateSDPflags}=SDPSolve[DilateSDP,GapTol-> OptionValue[TolGap],FeasibilityTol-> 10.^(3)*OptionValue[TolGap],PrintSummary-> False,PrintIterations-> False];

MaximalDilateRu=Table[Rule[DilateVars[[i]],DilateSDPY[[1,1,i]]],{i,Length[DilateVars]}];

MaximalDilateX=NCReplaceRepeated[DilateX,MaximalDilateRu];];

If[ArvesonQ==True,
DilateBeta=0*ZArvMat;
DilateGamma=0*Makegamma[g,1];
MaximalDilateX=Table[ArrayFlatten[{{X[[i]],Transpose[DilateBeta[[i]]]},{DilateBeta[[i]],DilateGamma[[i]]}}],{i,g}];
DilationSize=0;
DilationArvesonQ=ArvesonQ;];


Return[MaximalDilateX]]]]

(* ArvesonDoubleDilateOnZero dilates tice with 0 as the gamma block. Using this suggests that ArvesonDilateOnZero rarely generates a maximal beta (if ever) *)

ArvesonDoubleDilateOnZero[A_,X_]:=Block[{FirstDia,SecondDia},
FirstDia=ArvesonDilateOnZero[A,X];
SecondDia=ArvesonDilateSimple[A,FirstDia];
Return[SecondDia]];



(* ::Section::Initialization:: *)
(*(*(*(*(*(*(*Utilities*)*)*)*)*)*)*)


(* ::Text::Initialization:: *)
(*(*(*(*(*(*(*This section contains utility functions. Examples include viewing graphics of level 1 of a g=2 spectrahedron, viewing nice presentations of LMI to look at, and Random g=2 LMI coefficient generation*)*)*)*)*)*)*)


(* ::Input::Initialization:: *)
(* TupleNorm computes the norm of a tuple *)
TupleNorm[tuple_]:=Norm[Sum[tuple[[i]]^2,{i,Length[tuple]}]]
(* LeftTupleMult left multiplies Tuple by the matrix M *)
LeftMultTuple[M_,tuple_]:=Table[M.tuple[[i]],{i,Length[tuple]}]

(* RightTupleMult Right multiplies Tuple by the matrix M *)
RightMultTuple[M_,tuple_]:=Table[tuple[[i]].M,{i,Length[tuple]}]

(* ConjTuple right multiplies Tuple by M and left multiplies by M^* *)
ConjTuple[M_,tuple_]:=RightMultTuple[Transpose[M],LeftMultTuple[M,tuple]]

(* ViewTuple is short for Map[MatrixForm,Tuple] *)
ViewTuple[tuple_]:=Map[MatrixForm,tuple]

(* TupleComm commutes the commutante of Tuple with M *)
TupleComm[M_,tuple_]:=LeftMultTuple[M,tuple]-RightMultTuple[M,tuple]

ViewLMIGraphic[a_]:=Block[{x},
Print[IdentityMatrix[Length[a[[1]]]]-Sum[KroneckerProduct[a[[i]],{{x[i]}}],{i,Length[a]}]//MatrixForm]]

ViewSpectrahedron2D[a_]:=Block[{ConstraintList,Constraint,d,g,x,RegionUpperBoundList,RegionLowerBoundList,ACoefBoundList},(
d=Length[a[[1]]];
g=Length[a];
ConstraintList=Table[1-Sum[a[[j,i,i]]*x[j],{j,g}]>0,{i,d}];
Constraint=ConstraintList[[1]];
Do[Constraint=And[Constraint,ConstraintList[[i]]],{i,2,d}];
ACoefBoundList=Table[Table[If[a[[j,i,i]]!=0,1/a[[j,i,i]],0],{i,d}],{j,g}];
RegionUpperBoundList=Table[Max[ACoefBoundList[[j]]]+4,{j,g}];
RegionLowerBoundList=Table[Min[ACoefBoundList[[j]]]-4,{j,g}];
Return[RegionPlot[Constraint,{x[1],RegionLowerBoundList[[1]],RegionUpperBoundList[[1]]},{x[2],RegionLowerBoundList[[2]],RegionUpperBoundList[[2]]}]]
(*Return[RegionUpperBoundList]*)
)]

(* DeleteZeros deletes the zeros from a given list *)

DeleteZeros[list_]:=DeleteCases[list,0]


(* CountIrreducibles counts the number of irreducible tuples in a table generated using FindExtremePoint *)

CountIrreducibles[ExtremeList_]:=Block[{iterate,IrredCount},
iterate=1;
IrredCount=0;
While[iterate<= Length[ExtremeList],
If[SameQ[ExtremeList[[iterate,9]],True],
IrredCount=IrredCount+1];
iterate=iterate+1];
Return[IrredCount]]

(* countNullDims and countNullTan is are specialty functions that are called by ExtremeDataAnalysis. countNullDims counts the number of null spaces of a given size in a list and  countNullTan counts the number of pairs of a fixed kernel and tangent space size *)

Options[countNullDims]:={AnalyzeIrredOnly-> True}
countNullDims[list_,n_,OptionsPattern[]]:=Block[{iterate,count,AnalyzeIrredOnly},
iterate=1;
count=0;
If[SameQ[OptionValue[AnalyzeIrredOnly],True],
While[iterate<= Length[list],
If[SameQ[list[[iterate,7]],n]&&SameQ[list[[iterate,9]],True],
count=count+1];
iterate=iterate+1];
If[SameQ[count,0],Return[0],Return[{n,count}]],
While[iterate<= Length[list],
If[SameQ[list[[iterate,7]],n],
count=count+1];
iterate=iterate+1];
If[SameQ[count,0],Return[0],Return[{n,count}]]]]

Options[countNullTan]:={AnalyzeIrredOnly-> True}
countNullTan[list_,n_,m_,OptionsPattern[]]:=Block[{iterate,count,AnalyzeIrredOnly},
iterate=1;
count=0;
If[SameQ[OptionValue[AnalyzeIrredOnly],True],
While[iterate<= Length[list],
If[SameQ[list[[iterate,7]],n]&&SameQ[list[[iterate,8]],m]&&SameQ[list[[iterate,9]],True],
count=count+1];
iterate=iterate+1];
If[SameQ[count,0],Return[0],Return[{n,m,count}]],
While[iterate<= Length[list],
If[SameQ[list[[iterate,7]],n]&&SameQ[list[[iterate,8]],m],
count=count+1];
iterate=iterate+1];
If[SameQ[count,0],Return[0],Return[{n,m,count}]]]]

(* ExtremeDataAnalysis takes a list generated by GenerateExtremeData and counts the number of points with specificed null space size and null space tangent space size pairs for Arveson and Euclidean extreme points *)

Options[ExtremeDataAnalysis]:={AnalyzeIrredOnly-> True}
ExtremeDataAnalysis[A_,list_,OptionsPattern[]]:=Block[{n,d,g,listLength,ReducibleArvEucCount,ArvesonPointList,ArvesonListIterate,BadNullNumerics,BadSystemNumerics,BadNullNumericsList,BadNullNumericsIterateList,EuclideanPointList,NonExtremePointList,NonExtremePointCount,ArvesonPointCount,EuclideanPointCount,ArvesonNullData,EuclideanNullData,ArvesonPointsCounted,EuclideanPointsCounted,ArvesonTangentData,EuclideanTangentData,IrredArvCount,IrredEucCount,AnalyzeIrredOnly},
n=Length[list[[1,1,1]]];
d=Length[A[[1]]];
g=Length[list[[1,1]]];
listLength=Length[list];
ArvesonPointList={};
BadNullNumericsList={};
BadNullNumericsIterateList={};
EuclideanPointList={};
ArvesonListIterate=1;

While[ArvesonListIterate<= listLength,
If[SameQ[list[[ArvesonListIterate,3]],True],ArvesonPointList=Append[ArvesonPointList,list[[ArvesonListIterate]]],
If[SameQ[list[[ArvesonListIterate,3]],BadNullNumerics]||SameQ[list[[ArvesonListIterate,3]],BadSystemNumerics],BadNullNumericsList=Append[BadNullNumericsList,list[[ArvesonListIterate]]];
BadNullNumericsIterateList=Append[BadNullNumericsIterateList,ArvesonListIterate];,
If[SameQ[list[[ArvesonListIterate,3]],False]&&SameQ[list[[ArvesonListIterate,5]],True],EuclideanPointList=Append[EuclideanPointList,list[[ArvesonListIterate]]]]]];
;
ArvesonListIterate=ArvesonListIterate+1];
NonExtremePointList=Complement[list,Join[ArvesonPointList,BadNullNumericsList,EuclideanPointList]];
ReducibleArvEucCount=Length[Join[ArvesonPointList,EuclideanPointList]]-CountIrreducibles[Join[ArvesonPointList,EuclideanPointList]];

NonExtremePointCount=Length[NonExtremePointList];
ArvesonPointCount=Length[ArvesonPointList];
EuclideanPointCount=Length[EuclideanPointList];

If[ArvesonPointCount!= 0,ArvesonNullData=DeleteZeros[Table[countNullDims[ArvesonPointList,l,AnalyzeIrredOnly-> OptionValue[AnalyzeIrredOnly]],{l,0,d*n}]];,
ArvesonNullData=False];

If[EuclideanPointCount!= 0,EuclideanNullData=DeleteZeros[Table[countNullDims[EuclideanPointList,l,AnalyzeIrredOnly-> OptionValue[AnalyzeIrredOnly]],{l,0,d*n}]];,
EuclideanNullData=False];

IrredArvCount=CountIrreducibles[ArvesonPointList];
IrredEucCount=CountIrreducibles[EuclideanPointList];
If[Length[ArvesonNullData]!= 0,ArvesonTangentData=Map[DeleteZeros,Table[countNullTan[ArvesonPointList,l,k],{l,ArvesonNullData[[1,1]],ArvesonNullData[[Length[ArvesonNullData],1]]},{k,-n*(n-1)/2,n*(n+1)*g/2}]];,
ArvesonTangentData=False];
If[Length[EuclideanNullData]!= 0,EuclideanTangentData=Map[DeleteZeros,Table[countNullTan[EuclideanPointList,l,k],{l,EuclideanNullData[[1,1]],EuclideanNullData[[Length[EuclideanNullData],1]]},{k,-n*(n-1)/2,n*(n+1)*g/2}]];,
EuclideanTangentData=False];
Return[{ArvesonNullData,IrredArvCount,ArvesonTangentData,EuclideanNullData,IrredEucCount,EuclideanTangentData,{BadNullNumericsIterateList,Length[BadNullNumericsIterateList]},ReducibleArvEucCount,NonExtremePointCount,EuclideanPointList} ]] 

(* FindExtremeAndAnalyze is an all in one function that generates data using GenerateExtremeData then prints the analysis given by ExtremeDataAnalysis *)

Options[FindExtremeAndAnalyze]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),ChopCutoff-> 10^(-3),TolGap-> 10^(-9),AnalyzeIrredOnly-> True,OutputFile->False, Sig->0,MyFunctional->MakeFunctionalRational}
FindExtremeAndAnalyze[A_,n_,DataLength_,Seed_,OptionsPattern[]]:=Block[{ExtremeDataTable,ExtremeAnalysisTable,EigMagTol,EigGapTol,NumericsAssessment,IrredAssessment,NumericsAssessmentTol,ChopCutoff,TolGap,AnalyzeIrredOnly,OutputFile,EuclideanFunctionalsTable,filename,filepath,fileStream,WeightVector,WeightMatrix,Sig,MyFunctional},
ExtremeDataTable=GenerateExtremeData[A,n,DataLength,Seed,DiagnosticLevel->4,EigMagTol-> OptionValue[EigMagTol],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff],TolGap-> OptionValue[TolGap], Sig->OptionValue[Sig],MyFunctional-> OptionValue[MyFunctional]];
ExtremeAnalysisTable=ExtremeDataAnalysis[A,ExtremeDataTable,AnalyzeIrredOnly-> OptionValue[AnalyzeIrredOnly]];
Do[Print[ExtremeAnalysisTable[[i]]],{i,Length[ExtremeAnalysisTable]-1}];
If[SameQ[OptionValue[OutputFile],False]==False,
EuclideanFunctionalsTable=Table[ExtremeAnalysisTable[[10,i,2]],{i,Length[ExtremeAnalysisTable[[10]]]}];
filename=StringJoin[OptionValue[OutputFile]," n=",ToString[n]," iter=", ToString[DataLength], " seed=", ToString[Seed],".m"];
filepath=FileNameJoin[{$TemporaryDirectory,filename}];
fileStream=OpenWrite[filename];
WriteLine[fileStream,"The number functionals found that generate non-Arveson extreme points is"];
Write[fileStream,Length[EuclideanFunctionalsTable]];
WriteLine[fileStream," "];
WriteLine[fileStream, "This data was generated on "];
Write[fileStream,DateString[]];
WriteLine[fileStream,"The following linear functionals generate non-Arveson extreme points on the spectrahedron"];
WriteLine[fileStream," "];
Write[fileStream,A];
WriteLine[fileStream," "];
WriteLine[fileStream,"at level "];
Write[fileStream, n];
WriteLine[fileStream," "];
Write[fileStream,EuclideanFunctionalsTable];
WriteLine[fileStream," "];
Close[fileStream]];
Return[{ExtremeDataTable,ExtremeAnalysisTable}];]

MakeIrreducibleBoundedA[g_,d_,seed_]:=Block[{PreTuple,SymTuple,GoodQ},
SeedRandom[seed];
GoodQ=False;
While[GoodQ==False||BoundedQ,
PreTuple=Table[RandomInteger[{-25,25}]/10,{k,g},{j,d},{i,d}];
SymTuple=PreTuple+Map[Transpose,PreTuple];
If[CommutantDimension[SymTuple][[1]]==1&&BoundedQ[SymTuple],GoodQ=True];];
Return[SymTuple]]

MakeIrreducibleA[g_,d_,seed_]:=Block[{PreTuple,SymTuple,IrreducibleQ},
SeedRandom[seed];
IrreducibleQ=False;
While[IrreducibleQ==False,
PreTuple=Table[RandomInteger[{-25,25}]/10,{k,g},{j,d},{i,d}];
SymTuple=PreTuple+Map[Transpose,PreTuple];
If[CommutantDimension[SymTuple][[1]]==1,IrreducibleQ=True];];
Return[SymTuple]]

MakeBoundedA[g_,d_,seed_]:=Block[{PreTuple,SymTuple,GoodQ,testedTuples},
SeedRandom[seed];
GoodQ=False;
While[GoodQ==False||BoundedQ,
PreTuple=Table[RandomInteger[{-25,25}]/10,{k,g},{j,d},{i,d}];
SymTuple=PreTuple+Map[Transpose,PreTuple];
If[BoundedQ[SymTuple],GoodQ=True];];
Return[SymTuple]]

GrabNonArvesonExtreme[list_]:=Block[{EucTable},
EucTable={};
Do[If[SameQ[list[[1,i,3]],False]==True&&SameQ[list[[1,i,5]],True]==True&&SameQ[list[[1,i,9]],True]==True,EucTable=Append[EucTable,list[[1,i]]]],{i,Length[list[[1]]]}];
Return[EucTable]]

MakeMatrixSigned[d_,Sig_]:=Block[{M,Signa,Signat},
M=Table[RandomInteger[{-20,20}]/10,{i,d},{j,d}];
For[i=1,i<=d,i++,
For[j=1,j<i,j++,
M[[i,j]]=0;
]
];
Signa=Floor[Sig];
If[Signa<0,Signa=0];
If[Signa>d*n,Signa=d*n];
Signat=DiagonalMatrix[Join[Table[1,{i,d-Signa}],Table[-1,{i,Signa}]]];
M=ConjugateTranspose[M].Signat.M;
Return[M];
]

Options[MakeFunctionalTrace]:={WeightMatrix->Null, Sig->0}
MakeFunctionalTrace[A_,n_,OptionsPattern[]]:=Block[{M,GenX,g,d,WeightMatrix,Sig,Signat},
g=Length[A];
d=Length[A[[1]]];
GenX=MakeX[g,n];
Signat=Floor[OptionValue[Sig]];
If[Signat<0,Signat=0];
If[Signat>d*n,Signat=d*n];
If[SameQ[OptionValue[WeightMatrix],Null],
M=MakeMatrixSigned[d*n,Signat];,
If[Length[OptionValue[WeightMatrix]]==d*n&&Length[OptionValue[WeightMatrix][[1]]]==d*n,
M=OptionValue[WeightMatrix],
Print["WARNING: The WeightMatrix Option does not have the correct format."];
Return[Null];];];
Return[{M,Simplify[Tr[M.LMI[A,GenX]]]/(d*n)}];
]

GrabFunctionalCoefs[g_,n_,Functional_]:=Normal[CoefficientArrays[Functional,Variables[MakeX[g,n]]]][[2]]

Options[BoundedQ]:={Radius->1000, TolGap-> 10^(-9), ReferenceRadiusRatio->.99}
BoundedQ[A_,OptionsPattern[]]:=Block[{g, d, cube, Radius, AugmentedA, Xg, lmi, SDPVars, sdp, Y, Z, S, flags, SDPWeight, SDPFunctional,TolGap,X},
g=Length[A];
d=Length[A[[1]]];
cube=Table[DiagonalMatrix[Join[ConstantArray[0,2(j-1)],{1,-1},ConstantArray[0,2(g-j)]]],{j,g}]/OptionValue[Radius];
AugmentedA=DirectSumTuple[{A, cube}];
Xg = MakeX[g, 1];
lmi = LMI[AugmentedA, Xg];
SDPVars = MakeSDPVars[Xg];
For[i=1, i<=g, i++,
	{SDPWeight, SDPFunctional} = MakeFunctionalRational[g, 1, Symbol["WeightVector"] -> Join[ConstantArray[0,(i-1)],{1},ConstantArray[0,(g-i)]]];
	sdp = SDPMatrices[SDPFunctional, lmi, SDPVars];
	{Y,Z,S,flags}=SDPSolve[sdp,Symbol["GapTol"]-> OptionValue[TolGap],Symbol["FeasibilityTol"]-> 10.^(3)*OptionValue[TolGap],Symbol["PrintIterations"]-> False,Symbol["PrintSummary"]-> False];
	If[Max[Abs[Y[[1,1]]]]/OptionValue[Radius] > OptionValue[ReferenceRadiusRatio],
		Return[False];
	]
];
For[i=1, i<=g, i++,
	{SDPWeight, SDPFunctional} = MakeFunctionalRational[g, 1, Symbol["WeightVector"] -> Join[ConstantArray[0,(i-1)],{-1},ConstantArray[0,(g-i)]]];
	sdp = SDPMatrices[SDPFunctional, lmi, SDPVars];
	{Y,Z,S,flags}=SDPSolve[sdp,Symbol["GapTol"]-> OptionValue[TolGap],Symbol["FeasibilityTol"]-> 10.^(3)*OptionValue[TolGap],Symbol["PrintIterations"]-> False,Symbol["PrintSummary"]-> False];
	If[Max[Abs[Y[[1,1]]]]/OptionValue[Radius] > OptionValue[ReferenceRadiusRatio],
		Return[False];
	]
];
Return[True];
]


End[]
EndPackage[]


(* ::Section:: *)
(*Version History*)


(* ::Text:: *)
(*This section is an attempt to maintain a version history for the changes done to this notebook. *)
(**)
(*20May 2018 *)
(**)
(*Finished Functionality for MakeFunctionalTrace and MakeBlockFunctional in FindExtremePoint and GenerateExtreme and Analyze. These make linear functionals of the form Trace[M.LMI[A,X]] and Trace[M otimes I . LMI[A,X]], respectively.*)
(**)
(*Removed option to make functional with nonrational coefficients, and removed option to in FindExtremePoint to generate tuple with X1 diagonal. These have not been used in experiments. *)
(**)
(*15Apr 2018*)
(**)
(*1. Removed outdated functions for package version.*)
(*2. Changed FindExtremePointNoPrint to FindExtremePoint, and changed all calls for FindExtremePointNoPrint to FindExtremePointPrint. Removed old FindExtremePoint function.*)
(*3. Changed id and mf to IdentityMatrix and MatrixForm respectively. Short hand names will not be included in package.*)
(*4. Removed collection of LMI coefficients for package.*)
(*5. Changed write functionality in GenerateExtremeAndAnalyze to write to a directory*)
(*6. Changed write in GenerateExtremeAndAnalyze to output a table of linear functionals rather than individual linear functionals.*)
(**)
(*8 April 2018*)
(**)
(*Added the GrabNonArvesonExtreme function*)
(**)
(*6 April 2018 *)
(**)
(*1. Added a collection of functions to dilate Euclidean extreme to Arveson extreme. See functions whose name starts with "ArvesonDilate"*)
(*2. Added writing to generate extreme and analyze which writes functionals that generate Euclidean extreme points to an output file if an output name is specified.*)
(*3. Changed exact math to Numerical math in ArvesonTest and EuclideanTest to prevent kernel crashes*)
(*4. Closed comments left open in the preamble. *)
(*5. Added the TupleNorm utility function. This computes the 2 norm of a tuple. *)
(**)
(*26 March 2018 Fixed bug in GenerateExtremeAndAnalyze causing additional output. *)
(**)
(*18 March 2018: Added MakeIrreducibleA function which makes an irreducible g tuple of d x d symmetric matrices. Changed CommutantDimension to always use numerical arithemtic instead of exact.*)
(**)
(*15 March 2018:*)
(*1. Rearragned the functions under Extreme Point Generation and Classification section of preamble. Moved functions into subsubsections based on use. Identified and grouped currently unsupported functions.*)
(**)
(* 2. Added several utility functions. These are*)
(* *)
(* LeftTupleMult*)
(* RightTupleMult*)
(* TupleConj*)
(* ViewTuple*)
(* ArvTanVec*)
(* *)
(**)
(*10 March 2018: Bug fixes in ExtremeDataAnalysis. First bug caused points with BadSystemNumerics as Arveson True False value to be reported as Euclidean extreme points. The second bug caused points which were neither Arveson nor Euclidean extreme to be reported as Euclidean extreme points.*)
(**)
(*ExtremeDataAnalysis now outputs the number of points which are neither Arveson or Euclidean, although does not output data on these points. Additionally, the number reducible Arveson and Euclidean extreme points is now output.*)
(**)
(*7 March 2018: Fixed a bug in DeterimeNull that occured when the list contained negative values.*)
(**)
(*13 Feb 2018: Made new all in one function for extreme point generation and data analysis named "GenerateExtremeAndAnalyze". IMPORTANT: By default GenerateExtremeAndAnalyze only looks at irreducible points when generating data.*)


(* ::Text:: *)
(*2 February 2018: Updated ArvesonTest and EuclideanTest to work by solving the appropriate Kernel containment conditions. This should greatly improve speed and precision. Nullspace sizes are now determined using the DetermineNull command. This command finds a null space by looking for sufficiently sized gaps and small eigenvalues. Certain eigenvalue lists will cause the command to return "BadNullNumerics". This is intended to occur when the command cannot adequately *)
(* asses which values should be zero and which should not. An example of a list which should return this is {1,10^(-3),10^(-7),10^(-10)}. The issue is that 10^(-10) is likely 0, but the gaps between 10^(-10) and 10^(-7) and 10^(-3) are poor. It is also hard to say if 10^(-7) should be 0. *)
(* *)
(* ExtremePointListKernelAnalysis has been updated to handle when BadNullNumerics is returned by FindExtremePointNoPrint.*)
(* *)
(* Many old functions, including FindExtremePoint, may be broken after this update. The key functions, ArvesonTest, EuclideanTest, FindExtremePointNoPrint, and ExtremePointListKernelAnalysis should all be working. *)
(**)
(**)
(**)
(**)
(*20 November 2017: Replaced Substitute with NCReplaceRepeated throughout the notebook.*)
(**)
(*Restructured the main functions into one chapter which has several subsections for related types of functions. This is in hopes of making it easier to find a specific function in the future. Furthermore, this makes it so that all that needs to be compiled is the "Main Functions" section in order to work with the notebook. Old functions or functions that failed to meet their intended purpose are moved into the unsupported chapter. This section should not be compiled as it could break other sections. It has been kept in case we ever want to work with the functions again.*)
(**)
(*Add several variables to blocks which had failed to be put in the block previously. *)
(**)
(*Added a function to count kernel data for a list of extreme points. The function is ExtremePointListKernelAnalysis found in the Utilities section*)
(**)
(*Removed an extraneous print[] from ClassifyExtremePoint. This was previously generating lots of undesired blank lines in large data generation tests.*)
