(* ::Package:: *)

BeginPackage["NCSE`",{"NCReplace`","SDP`"}]

Get["NCSE.usage"];
X;
Y;
Z;
gamma;
BadNullNumerics;

Begin["`Private`"];



(* ::Section:: *)
(*Basic Functions*)


(* ::Text:: *)
(*This section includes the basic functions used in the notebook. Examples include direct sum computation of a list of matrices, LMI evaluation and manipulation (such as Eigenvalue calculations), linear functional generation, random matrix generation, and and basic Variable Generation. The basic variables are used in Extreme Point generation and classification. *)


(* ::Input::Initialization:: *)
(* EqualsZero sets equation\[Equal]0 *)
EqualsZero[equation_]:=Equal[equation,0]


(* Takes the direct sum of a list *)
DirectSum[list_]:=Block[{M},
M=list[[1]];
Do[M=ArrayFlatten[{{M,0},{0,list[[i+1]]}}],{i,Length[list]-1}];
M]

(* Computes the direct sum of a list of tuples *)
DirectSumTuple[tuples_]:=Block[{g,T},
g=Length[tuples[[1]]];
T=Table[DirectSum[tuples[[All,j]]],{j,g}];
T]


(* Computes the monic linear pencil L_A (X)= I-A[[1]] \otimes X[[1]] -...- A[[g]] \otimes X[g] *)
LMI[A_,X_]:=If[SameQ[Length[A],Length[X]],
KroneckerProduct[IdentityMatrix[Length[A[[1]]]],IdentityMatrix[Length[X[[1]]]]]-Sum[KroneckerProduct[A[[i]],X[[i]]],{i,Length[X]}],
KroneckerProduct[A[[1]],IdentityMatrix[Length[X[[1]]]]]-Sum[KroneckerProduct[A[[i+1]],X[[i]]],{i,Length[X]}]];

(* Computes the linear part of L_A (X). That is, computes A[[1]] \otimes X[[1]] +...+ A[[g]] \otimes X[g] *)
Lambda[A_,X_]:=Sum[KroneckerProduct[A[[i]],X[[i]]],{i,Length[X]}]


(*Maps a n x n complex matrix to its 2n x 2n real embedding *)
Cto2R[mat_]:=Block[{A,B},
	A=Re[mat];
	B=Im[mat];
	Return[ArrayFlatten[{{A,B},{-B,A}}]]]
	
Cto2R2V[mat_]:=Block[{A,B},
	A=Re[mat];
	B=Im[mat];
Return[{ArrayFlatten[{{A,0},{0,A}}],ArrayFlatten[{{0,B},{-B,0}}]}]]


(* Calculates eigenvalues of LMI evaluated on X *)
PencilEig[A_,X_]:=Eigenvalues[LMI[A,X]];


(* Generates a symbolic symmetric g-tuple of n x n matrices*)
MakeX[g_,n_]:=Block[{X},
Table[If[i<j,X[k,i,j],X[k,j,i]],{k,g},{i,n},{j,n}]]

(* Generates a sybolic symmetric n x n matrix*)
MakeY[n_]:=Block[{Y},
Table[If[i<j,Y[i,j],Y[j,i]],{i,n},{j,n}]]

(* Generates a symbolic symmetric g-tuple of n x n matrices*)
MakeZ[g_,n_]:=Block[{Z},
Table[If[i<j,Z[k,i,j],Z[k,j,i]],{k,g},{i,n},{j,n}]]

(* Generates a symbolic g-tuple of n x 1 matrices*)
MakeZArv[g_,n_]:=Block[{Z},
Table[{Table[Z[k,j],{j,n}]},{k,g}]]


(* Converts a flattened g-tuple of n x 1 matrices back to a g-tuple of n x 1 matrices *)
VecToBeta[vec_,g_,n_]:=Table[{vec[[(h-1)*n+i]]},{h,1,g},{i,1,n}]


(* Generates a random linear functional on symmetric g-tuples of n x n matrices *)
Options[MakeFunctionalReal]:={WeightVector-> Null}
MakeFunctionalReal[g_,n_,OptionsPattern[]]:=Block[{Functional,FunctionalLength,FunctionalVariables,FunctionalWeight,WeightVector},

(* A functional will be made by taking innerproduct of FunctionalVariables with a weight vector FunctionalWeight *)
FunctionalVariables=Variables[MakeX[g,n]];
FunctionalLength=Length[FunctionalVariables];

(* The following if loop determines how to make FunctionalWeight. First is a check if the Option WeightVector is a vector which has the same number of entries as variables in FunctionalVariables *)
If[SameQ[Head[OptionValue[WeightVector]],List]&&SameQ[Length[OptionValue[WeightVector]],FunctionalLength],
FunctionalWeight=OptionValue[WeightVector],

(* If Option WeightVector is NOT a vector which has the same number of entries as variables in FunctionalVariables, check if WeightVector has the default value of Null. In this case, create a random weight vector *)
If[SameQ[OptionValue[WeightVector],Null],
FunctionalWeight=Table[RandomReal[{-1,1}],{k,FunctionalLength}],

(* If Option WeightVector does not have either of the previous forms, create a random FunctionalWeight, but also print a Warning to the user that their option does not have the correct form *)

FunctionalWeight=Table[RandomReal[{-1,1}],{k,FunctionalLength}];
Print["WARNING: The WeightVector Option does not have the correct format. Defaulted to making a random linear functional"];];];
Functional=Dot[FunctionalWeight,FunctionalVariables];
Return[{FunctionalWeight,Functional}]]

(*Generates a random linear functional with rational coefficients on symmetric g-tuples of n times n matrices *)
Options[MakeFunctionalRational]:={Distribution->"uniform", WeightVector-> Null}
MakeFunctionalRational[g_,n_,OptionsPattern[]]:=Block[{X,Functional,FunctionalLength,FunctionalVariables,FunctionalWeight,WeightVector,Distribution},

(* A functional will be made by taking innerproduct of FunctionalVariables with a weight vector FunctionalWeight *)
FunctionalVariables=Variables[MakeX[g,n]];
FunctionalLength=Length[FunctionalVariables];

(* The following if loop determines how to make FunctionalWeight. First is a check if the Option WeightVector is a vector which has the same number of entries as variables in FunctionalVariables *)
If[SameQ[Head[OptionValue[WeightVector]],List]&&SameQ[Length[OptionValue[WeightVector]],FunctionalLength],
FunctionalWeight=OptionValue[WeightVector],

(* If Option WeightVector is NOT a vector which has the same number of entries as variables in FunctionalVariables, check if WeightVector has the default value of Null. In this case, create a random weight vector *)
If[SameQ[OptionValue[WeightVector],Null],
	If[OptionValue[Distribution]=="uniform",FunctionalWeight=Table[RandomInteger[{-200,200}]/100,{k,FunctionalLength}]];
	If[OptionValue[Distribution]=="gaussian",FunctionalWeight=Table[RandomReal[NormalDistribution[0,1]],{k,FunctionalLength}]];
,

(* If Option WeightVector does not have either of the previous forms, create a random FunctionalWeight, but also print a Warning to the user that their option does not have the correct form *)

FunctionalWeight=Table[RandomInteger[{-200,200}]/100,{k,FunctionalLength}];
Print["WARNING: The WeightVector Option does not have the correct format."];
Return[Null];];];
Functional=Dot[FunctionalWeight,FunctionalVariables];
Return[{FunctionalWeight,Functional}]]


(* Indices are switched in the problem. This is a tool for switching back *)
FindIndex[n_,k_,i_,j_]:=(k-1)*(n^2+n)/2+Sum[n+1-s,{s,i}]+j-n

(* Indices are switched in the problem. This is a tool for switching back in the case X1 is diagonal*)
FindIndexDiag[n_,k_,i_,j_]:=If[k==1,i,((k-1)*(n^2+n)/2+Sum[n+1-s,{s,i}]+j-n)-Binomial[n+1,2]+n]


(* Rule for subsituting in to Xg after running the SDP *)
MakeXRule[g_,n_]:=Flatten[Table[X[k,i,j]->  Y[[1,1,FindIndex[n,k,i,j]]],{k,g},{j,n},{i,j}]]

(* Finds the variables the SDP is in from the input Xg. Stores this in SDPVars *)
MakeSDPVars[MatrixTuple_]:=DeleteDuplicates[Flatten[MatrixTuple]];


(* Makes a column vector beta that will be used in the test to see if the extreme point is arverson *)
MakeBeta[g_,n_]:=Block[{beta},
Table[Transpose[{Table[beta[k,j],{j,n}]}],{k,g}]]

(* Makes a symmetric beta to be used in the test to see if beta is Euclidean *)
MakeSymBeta[g_,n_]:=Block[{SymBeta},
Table[If[i<j,SymBeta[k,i,j],SymBeta[k,j,i]],{k,g},{i,n},{j,n}]]

(* Create a list of zeros with the appriate size to check beta=0 against for the Euclidean test *)
MakeZeroSymBetaList[g_,n_]:={{Table[0,{k,g*(n(n+1))/2}]}}

(* Create a list of zeros with the appriate size to check beta=0 against for the Arveson test *)
MakeZeroBetaList[g_,n_]:={{Table[0,{k,g*n}]}}

(* Makes the matrix {{Extremepoint, Beta},{Transpose[Beta],0}}   *)
MakeExtendX[Xg_,beta_,g_]:=Table[ArrayFlatten[{{Xg[[k]],beta[[k]]},{Transpose[beta[[k]]],0*IdentityMatrix[Length[beta[[1,1]]]]}}],{k,g}]


(* randmat generates a random r by c matrix with inputs which are rational numbers of the form j/10 for -10\[LessEqual] j\[LessEqual] 10 *)
randmat[r_,c_]:=Table[RandomInteger[{-10,10}]/10,{i,r},{j,c}]


(* Makegamma generates a g tuple of gamma n x n symmetric matrices with entires gamma[k,i,j]. *)
Makegamma[g_,n_]:=Block[{gamma},
Table[If[i<j,gamma[k,i,j],gamma[k,j,i]],{k,g},{i,n},{j,n}]]

MakeExtendXwithGamma[Xg_,beta_,g_]:=Block[{ExtendX,betaLength,gamma,gammag},
betaLength=Length[beta[[1,1]]];
gammag=Makegamma[g,betaLength];
ExtendX=Table[ArrayFlatten[{{Xg[[k]],beta[[k]]},{Transpose[beta[[k]]],gammag[[k]]}}],{k,g}]]


(* Determines the dimension of the null space of a numerical matrix using Cutoff as the value to treat as zero *)
NullDimension[Mat_,Cutoff_]:=Count[Chop[Eigenvalues[Mat],Cutoff],0]

(* Determine Nulls attempts to decide what values should be called zero in a give list. The function looks for small values which have a large gap from the next value. By default, if the gap is not sufficiently large or small, the function reports that the numerics are poor. DetermineNull returns the index of the largest element of the list which is considered zero when the list is ordered from greatest to smallest absolute value. *)
Options[DetermineNull]:={NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2)}
DetermineNull[list_,EigMagTol_,EigGapTol_,OptionsPattern[]]:=Block[{AbsList,NullFound,iterate,EigGap,BestGap,NumericsAssessment,NumericsAssessmentTol,BadNumerics},
AbsList=Map[Abs,list];
AbsList=Sort[AbsList,Greater];
If[AbsList[[1]]<= EigMagTol,
{Return[1],0}];
iterate=2;
NullFound=False;
BestGap=Infinity;
While[NullFound==False &&iterate<= Length[AbsList],
If[Abs[AbsList[[iterate]]]<= EigMagTol&&AbsList[[iterate]]/AbsList[[iterate-1]]<=  EigGapTol,
NullFound=True;
BestGap=AbsList[[iterate]]/AbsList[[iterate-1]],
If[AbsList[[iterate]]/AbsList[[iterate-1]]<BestGap,BestGap=AbsList[[iterate]]/AbsList[[iterate-1]]];
iterate=iterate+1;]];
If[SameQ[NullFound,True],Return[{iterate,BestGap}],If[SameQ[OptionValue[NumericsAssessment],True]&&BestGap*OptionValue[NumericsAssessmentTol]< EigGapTol,
Return[{BadNumerics,BestGap}],If[SameQ[OptionValue[NumericsAssessment],True]&&AbsList[[Length[list]]]<10^(-2)* EigMagTol,Return[{BadNumerics,BestGap}], Return[{False,BestGap}]]]]]




(* ::Section:: *)
(*Free Tangent Planes and Commutants*)


(* ::Text:: *)
(*This section contains functions for computation the dimension of of tangent planes and commutants*)


(* ::Input::Initialization:: *)
(* TanDimGuess computes guess for nontrivial tangent space dimension based on g,n, and k where k is the dimension of the kernel of L_A(X). This will not always be correct. *)
TanDimGuess[g_,n_,k_]:=Block[{},Return[n*(n+1)*g/2-n*(n-1)/2-(k+1)*k/2]]

(* FreeTangentNumerical computes the dimension of the tangent plane to the free spectrahedron defined by A at the tuple X *)
Options[FreeTangentNumerical]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2)}
FreeTangentNumerical[A_,X_,OptionsPattern[]]:=Block[{g,n,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZEucMat,TangentEqsBasic,TangentEqs,TangentEqsTable,TangentSystemMat,TangentSystemEigVals,TangentSystemEigVecs,ZSolExistQ,ZSolConfidence,TangentQ,BadSystemNumerics},
g=Length[A];
n=Length[X[[1]]];
{LMIEigenvalues,LMIEigenvectors}=Eigensystem[LMI[A,X]];
{NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[NullVecStartIterate,False],Return[{False,NullConfidence,False,LMIEigenvalues}],
If[SameQ[NullVecStartIterate,BadNumerics],Return[{BadNullNumerics,{NullConfidence,BadNullNumerics}}],
NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
ZEucMat=MakeZ[g,n];
TangentEqsBasic=ConjugateTranspose[NullInclusionMatrix].Lambda[A,ZEucMat].NullInclusionMatrix;
TangentEqs=DeleteCases[DeleteCases[Flatten[TangentEqsBasic],0.],0];
TangentEqsTable=Table[TangentEqs[[i]]==0,{i,1,Length[TangentEqs]}];
TangentSystemMat=Normal[CoefficientArrays[TangentEqsTable,Variables[ZEucMat]]][[2]];
{TangentSystemEigVals,TangentSystemEigVecs}=Eigensystem[Transpose[TangentSystemMat].TangentSystemMat];
{ZSolExistQ,ZSolConfidence}=DetermineNull[TangentSystemEigVals,OptionValue[EigMagTol]*10^(-3),OptionValue[EigGapTol]*10^(-3),NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
TangentQ=If[SameQ[False,ZSolExistQ],0,
If[SameQ[ZSolExistQ,BadNumerics],BadSystemNumerics,Length[TangentSystemEigVals]-ZSolExistQ+1-n*(n-1)/2]];
Return[TangentQ]]]];


(* CommutantDimension determines the dimension of the commutant of the tuple X={X[[1]],X[[2]],...,X[[g]]}. by determining the dimension of the null space of the linear system Y.X[[i]]-X[[i]].Y\[Equal]0 for i=1,...,g. *)
Options[CommutantDimension]:={EigMagTol-> 10^(-9),EigGapTol-> 10^(-8),ChopCutoff->10^(-8),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2)}
CommutantDimension[X_,OptionsPattern[]]:=Block[{g,n,YMat,CommutantEqs,CommutantSystemMat,CommutantSystemEigVals,CommutantSystemEigVecs,CommSolExistQ,CommSolConfidence,EigMagTol,EigGapTol,ChopCutoff,NumericsAssessment,NumericsAssessmentTol,CommDim,BadNumerics,BadSystemNumerics},
g=Length[X];
n=Length[X[[1]]];
YMat=MakeY[n];
CommutantEqs=Map[EqualsZero,DeleteCases[Chop[Flatten[Table[YMat.X[[i]]-X[[i]].YMat,{i,g}]],OptionValue[ChopCutoff]],0]];
If[Length[CommutantEqs]==0,Return[{n*(n+1)/2,0}]];
CommutantSystemMat=N[Normal[CoefficientArrays[CommutantEqs,Variables[YMat]]][[2]]];
{CommutantSystemEigVals,CommutantSystemEigVecs}=Eigensystem[Transpose[CommutantSystemMat].CommutantSystemMat];
{CommSolExistQ,CommSolConfidence}=DetermineNull[CommutantSystemEigVals,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[CommSolExistQ,BadNumerics],CommDim=BadSystemNumerics,CommDim=Length[CommutantSystemEigVals]-CommSolExistQ+1];
Return[{CommDim,CommSolConfidence}]]



(* ::Section:: *)
(*Extreme Point Generation and Classification*)


(* ::Text:: *)
(*This section contains the major functions for extreme point generation and classification. There are two subsections. The first subsection is main subsection. In this section linear functionals are generated by randomly generating coefficients alpha in Sum alpha_i * variable_i. In this second section, the linear functionals are generated by using trace and a weight matrix. The functions in this section have been more successful in repeated dilations.*)


(* ::Subsection:: *)
(*Extreme Point Classification*)


(* ::Input::Initialization:: *)
(* Solves the Kernel Containment linear system to determine if a point is Arveson *) 
Options[ArvesonTest]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2)}
ArvesonTest[A_,X_,OptionsPattern[]]:=Block[{g,n,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZArvMat,NullContainmentEqsBasic,NullContainmentEqs,NullContainmentTable,NullSystemMat,NullSystemEigVals,NullSystemEigenVecs,ZSolExistQ,ZSolConfidence,ArvesonQ,BadSystemNumerics,Alin},
g=Length[X];
n=Length[X[[1]]];
If[SameQ[Length[A],Length[X]],Alin=A,Alin=A[[2;;All]]];
{LMIEigenvalues,LMIEigenvectors}=Eigensystem[LMI[A,X]];
{NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[NullVecStartIterate,False],Return[{False,{NullConfidence,False,LMIEigenvalues}}],
If[SameQ[NullVecStartIterate,BadNumerics],Return[{BadNullNumerics,{NullConfidence,BadNullNumerics}}],
NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
ZArvMat=MakeZArv[g,n];
NullContainmentEqsBasic=Lambda[Alin,ZArvMat].NullInclusionMatrix;
NullContainmentEqs=DeleteCases[DeleteCases[Flatten[NullContainmentEqsBasic],0.],0];
NullContainmentTable=Table[NullContainmentEqs[[i]]==0,{i,1,Length[NullContainmentEqs]}];
NullSystemMat=N[Normal[CoefficientArrays[NullContainmentTable,Variables[ZArvMat]]][[2]]];
{NullSystemEigVals,NullSystemEigenVecs}=Eigensystem[Transpose[NullSystemMat].NullSystemMat];
{ZSolExistQ,ZSolConfidence}=DetermineNull[NullSystemEigVals,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
ArvesonQ=If[SameQ[False,ZSolExistQ],True,
If[SameQ[ZSolExistQ,BadNumerics],BadSystemNumerics,False]];
Return[{ArvesonQ,{NullConfidence,ZSolConfidence}}]]]]

(* ArvesonTestSystemMat returns the matrix which represents the eqs for the linear system for testing if a matrix is Arveson. This function may be used for more careful analysis by hand. *) 
Options[ArvesonTestSystem]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2)}
ArvesonTestSystem[A_,X_,OptionsPattern[]]:=Block[{g,n,Alin,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZArvMat,NullContainmentEqsBasic,NullContainmentEqs,NullContainmentTable,NullSystemMat,NullSystemEigVals,NullSystemEigenVecs,ZSolExistQ,ZSolConfidence,ArvesonQ,BadSystemNumerics},
g=Length[X];
n=Length[X[[1]]];
If[SameQ[Length[A],Length[X]],Alin=A,Alin=A[[2;;All]]];
{LMIEigenvalues,LMIEigenvectors}=Eigensystem[LMI[A,X]];
{NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[NullVecStartIterate,False],Return[{False,{NullConfidence,False,LMIEigenvalues}}],
If[SameQ[NullVecStartIterate,BadNumerics],Return[{BadNullNumerics,{NullConfidence,BadNullNumerics}}],
NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
ZArvMat=MakeZArv[g,n];
NullContainmentEqsBasic=Lambda[Alin,ZArvMat].NullInclusionMatrix;
NullContainmentEqs=DeleteCases[DeleteCases[Flatten[NullContainmentEqsBasic],0.],0];
NullContainmentTable=Table[NullContainmentEqs[[i]]==0,{i,1,Length[NullContainmentEqs]}];
NullSystemMat=N[Normal[CoefficientArrays[NullContainmentTable,Variables[ZArvMat]]][[2]]];
(*{NullSystemEigVals,NullSystemEigenVecs}=Eigensystem[Transpose[NullSystemMat].NullSystemMat];
{ZSolExistQ,ZSolConfidence}=DetermineNull[NullSystemEigVals,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment\[Rule] OptionValue[NumericsAssessment],NumericsAssessment\[Rule] OptionValue[NumericsAssessmentTol]];
ArvesonQ=If[SameQ[False,ZSolExistQ],True,
If[SameQ[ZSolExistQ,BadNumerics],BadSystemNumerics,False]];*)
Return[NullSystemMat]]]]


(* Solves the appropriate kernel containment system to determine if a given point is Euclidean Extreme *) 
Options[EuclideanTest]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2)}
EuclideanTest[A_,X_,OptionsPattern[]]:=Block[{g,n,Alin,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZEucMat,NullContainmentEqsBasic,NullContainmentEqs,NullContainmentTable,NullSystemMat,NullSystemEigVals,NullSystemEigenVecs,ZSolExistQ,ZSolConfidence,EuclideanQ,BadSystemNumerics},
g=Length[X];
n=Length[X[[1]]];
If[SameQ[Length[A],Length[X]],Alin=A,Alin=A[[2;;All]]];
{LMIEigenvalues,LMIEigenvectors}=Eigensystem[LMI[A,X]];
{NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[NullVecStartIterate,False],Return[{False,{NullConfidence,False,LMIEigenvalues}}],
If[SameQ[NullVecStartIterate,BadNumerics],Return[{BadNullNumerics,{NullConfidence,BadNullNumerics}}],
NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
ZEucMat=MakeZ[g,n];
NullContainmentEqsBasic=Lambda[Alin,ZEucMat].NullInclusionMatrix;
NullContainmentEqs=DeleteCases[DeleteCases[Flatten[NullContainmentEqsBasic],0.],0];
NullContainmentTable=Table[NullContainmentEqs[[i]]==0,{i,1,Length[NullContainmentEqs]}];
NullSystemMat=N[Normal[CoefficientArrays[NullContainmentTable,Variables[ZEucMat]]][[2]]];
{NullSystemEigVals,NullSystemEigenVecs}=Eigensystem[Transpose[NullSystemMat].NullSystemMat];
{ZSolExistQ,ZSolConfidence}=DetermineNull[NullSystemEigVals,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
EuclideanQ=If[SameQ[False,ZSolExistQ],True,
If[SameQ[ZSolExistQ,BadNumerics],BadSystemNumerics,False]];
Return[{EuclideanQ,{NullConfidence,ZSolConfidence}}]]]]


(* ClassifyExtremePoint first determines if an extreme point is Arveson. If it is not Arveson then it checks to see if the extreme point is Euclidean. This is just a combination of the ArvesonTest and EuclideanTest commands. *)
Options[ClassifyExtremePoint]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),PrintExtremeData-> False}
ClassifyExtremePoint[A_,ExtremePoint_,OptionsPattern[]]:=Block[{g,n,ArvesonQ,ArvesonTolerance,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,EuclideanQ,EuclideanTolerance,PrintExtremeData},

{ArvesonQ,ArvesonTolerance}=ArvesonTest[A,ExtremePoint,EigMagTol->OptionValue[EigMagTol],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol]];

If[SameQ[ArvesonQ,True], 
EuclideanQ=True;
EuclideanTolerance=ArvesonTolerance;
If[OptionValue[PrintExtremeData]==True,
(Print["The point is an Arveson extreme point"];
Print["The Arveson tolerance was"];
Print[ArvesonTolerance];
Print[];)],
If[OptionValue[PrintExtremeData]==True,(Print["The point is not an Arveson extreme point"];
Print["The Arveson tolerance was"];
Print[ArvesonTolerance];
Print[];)];

{EuclideanQ,EuclideanTolerance}=EuclideanTest[A,ExtremePoint,EigMagTol->OptionValue[EigMagTol],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol]];

If[OptionValue[PrintExtremeData]==True,
If[SameQ[EuclideanQ,True],
Print["The point is a Euclidean extreme point"];
Print["The Euclidean tolerance was"];
Print[EuclideanTolerance];
Print[];,Print[];,
Print["The point is not a Euclidean extreme point"];
Print["The Euclidean tolerance was"];
Print[EuclideanTolerance];
Print[];]];];

Return[{ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance}];]




(* ::Subsection:: *)
(*Extreme Point Generation*)


(* ::Input::Initialization:: *)
(* Generates an Extreme Point candidate. Returns the extreme point and the linear functional that was used to generate the point *)
Options[GenerateExtremePoint]:={MyFunctional->  MakeFunctionalRational,ChopCutoff->  10^(-3),TolGap->  10^(-9),WeightVector->  Null,WeightMatrix-> Null, Sig-> 0,MathematicaSDP->  True, Distribution->"uniform"}
GenerateExtremePoint[A_,g_,n_,OptionsPattern[]]:=Block[{ArvesonTolerance,ArvesonQ,ExtremeX,EuclideanQ,EuclideanTolerance,lmi,MyFunctional,SDPVars,sdp,XRule,retVal,Y,Z,S,flags,OutputFileName,PencilEigenvalues,SDPFunctional,SDPWeight,Sig,TraceAnalysisValue,WeightMatrix,WeightVector,X,Xg,MathematicaSDP,SDPrule,d,constraint,Distribution},
Xg=MakeX[g,n];
d=Length[A[[1]]];
lmi=LMI[A,Xg];
SDPVars=MakeSDPVars[Xg];
retVal=Null;
(* If the MyFunctional option is set to MakeFunctionalRational then a Random Rational Functional of the appropriate size is generated. If the MyFunctional option is set to a specfic functional then the SDP and the functional defined by the user in the MyFunctional option will be used*)

(* Execute if MyFunctional option is MakeFunctionalTrace. This makes a positive linear functional by taking Trace[W.LMI[A,X]] where W is given by WeightMatrix. If WeightMatrix is Null then it is randomly generated *)
If[SameQ[OptionValue[MyFunctional],MakeFunctionalTrace]==True,
retVal=MakeFunctionalTrace[A,n,WeightMatrix->OptionValue[WeightMatrix], Sig->OptionValue[Sig],Distribution-> OptionValue[Distribution]];];

If[SameQ[OptionValue[MyFunctional],MakeFunctionalRational]==True,
(* Execute if MyFunctional option is MakeFunctionalRational. This makes a rational functional using the option for WeightVector. If WeightVector is Null then it is randomly generated *)
retVal=MakeFunctionalRational[g,n,WeightVector-> OptionValue[WeightVector],Distribution-> OptionValue[Distribution]];];
(* If MyFunctional is not MakeFunctionalTrace, or MakeFunctionalRational, prints an Error message *)
If[SameQ[OptionValue[MyFunctional],MakeFunctionalRational]==False&&SameQ[OptionValue[MyFunctional],MakeFunctionalTrace]==False,
Print["WARNING: The value given for MyFunctional is incorrect or unsupported."];
Return[Null]];
If[retVal==Null,Return[Null]];
SDPWeight=retVal[[1]];
SDPFunctional=retVal[[2]];
If[OptionValue[MathematicaSDP]==False,
sdp=SDPMatrices[SDPFunctional,lmi,SDPVars];
(* End if loop. SDP Run begins here *)
{Y,Z,S,flags}=SDPSolve[sdp,Symbol["GapTol"]-> OptionValue[TolGap],Symbol["FeasibilityTol"]-> 10.^(3)*OptionValue[TolGap],Symbol["PrintIterations"]-> False,Symbol["PrintSummary"]-> False];
Y=Chop[Y,OptionValue[ChopCutoff]*10^(-5)];
(* Set up substitution rule and substitute *)
XRule=MakeXRule[g,n];
ExtremeX=NCReplaceRepeated[Xg,XRule];,
constraint=VectorGreaterEqual[{lmi,0},{"SemidefiniteCone",d*n}];
SDPrule=Quiet[SemidefiniteOptimization[SDPFunctional,constraint,SDPVars]];
(*Set up substitution rule and substitute*)
ExtremeX=NCReplaceRepeated[Xg,SDPrule];
];
Return[{ExtremeX,SDPWeight}]]


(* FindExtremePoint is the main extreme point finding tool of NCSE. This function generates an extreme point on the spectrahedron D_A by maximizing a linear functional on D_A (n). By default additional information about the extreme point is also generated including if it is Arveson/Euclidean and if it is irreducible. *)
Options[FindExtremePoint]:={MonicLMI-> True,MathematicaSDP-> True,DiagnosticLevel->4, EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),MyFunctional-> MakeFunctionalRational,ChopCutoff-> 10^(-3),TolGap-> 10^(-9),WeightVector-> Null,WeightMatrix->Null, Sig->0}
FindExtremePoint[A_,n_,OptionsPattern[]]:=Block[{retVal,MathematicaSDP,ExtremeX,SDPFunctional,X,Xg,lmi,g,d,MyFunctional,SDPVars,sdp,XRule,Y,Z,S,flags,ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance,PencilEigenvalues,NullSpaceAnalysis,NullSpaceDimension,TangentAnalysis,TangentSpaceDimension,TestExtremePointType,IrredAssessment,IrredData,CommDim,CommTol,ChopCutoff,TolGap,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,WeightVector,WeightMatrix,Sig},
If[OptionValue[MonicLMI],g=Length[A],g=Length[A]-1];
d=Length[A[[1]]];
(* Calls appropriate Generate extreme point function to generate an extreme point candadite. *)
retVal=GenerateExtremePoint[A,g,n,MyFunctional-> OptionValue[MyFunctional],MathematicaSDP-> OptionValue[MathematicaSDP],ChopCutoff-> OptionValue[ChopCutoff],TolGap->OptionValue[TolGap],WeightMatrix->OptionValue[WeightMatrix], Sig->OptionValue[Sig],WeightVector-> OptionValue[WeightVector]];
If[retVal==Null,Return[Null]];
{ExtremeX,SDPFunctional}={retVal[[1]],retVal[[2]]};

If[OptionValue[DiagnosticLevel]==0,Return[ExtremeX]];
If[OptionValue[DiagnosticLevel]==1,Return[{ExtremeX,SDPFunctional}];];

(* If DiagnosticLevel is at least 2 then ClassifyExtremePoint is run. ClassifyExtremePoint first determines if an extreme point is Arveson. If it is not Arveson then it checks to see if the extreme point is Euclidean. *)
{ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance}=ClassifyExtremePoint[A,ExtremeX,EigMagTol->OptionValue[EigMagTol],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol]];
PencilEigenvalues=Eigenvalues[LMI[A,ExtremeX]];
NullSpaceAnalysis=DetermineNull[PencilEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol]][[1]];
If[SameQ[NullSpaceAnalysis,False],NullSpaceDimension=False,If[SameQ[NullSpaceAnalysis,BadNumerics],NullSpaceDimension=BadNullNumerics,NullSpaceDimension=n*d-NullSpaceAnalysis+1]];
TangentSpaceDimension=FreeTangentNumerical[A,ExtremeX];
If[OptionValue[DiagnosticLevel]==2,Return[{ExtremeX,SDPFunctional,ArvesonQ,EuclideanQ}];];
If[OptionValue[DiagnosticLevel]==3,Return[{ExtremeX,SDPFunctional,ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance}];];

If[SameQ[n,1],{CommDim,CommTol}={True,0},
IrredData=CommutantDimension[ExtremeX,EigMagTol-> OptionValue[EigMagTol]*10^(-3),EigGapTol-> OptionValue[EigGapTol]*10^-3,NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff]*10^(-5)];
If[SameQ[IrredData[[1]],1],{CommDim,CommTol}={True,IrredData[[2]]},{CommDim,CommTol}={IrredData[[1]],IrredData[[2]]}]];
Return[{ExtremeX,SDPFunctional,ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance,NullSpaceDimension,TangentSpaceDimension,CommDim,CommTol}]]

(* GeneratePointData generates a table using FindExtremePoint *)
Options[GenerateExtremeData]={DiagnosticLevel->0,EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),ChopCutoff-> 10^(-3),TolGap-> 10^(-9),WeightVector-> Null,WeightMatrix->Null,Sig->0,MyFunctional-> MakeFunctionalRational,MathematicaSDP-> True};
GenerateExtremeData[A_,n_,DataLength_,Seed_,OptionsPattern[]]:=Block[{DataTable,EigMagTol,EigGapTol,NumericsAssessment,IrredAssessment,NumericsAssessmentTol,ChopCutoff,TolGap,WeightMatrix,Sig,WeightVector,MyFunctional,MathematicaSDP},
SeedRandom[Seed];
DataTable=Table[FindExtremePoint[A,n,DiagnosticLevel->OptionValue[DiagnosticLevel],EigMagTol-> OptionValue[EigMagTol],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff],TolGap-> OptionValue[TolGap], Sig->OptionValue[Sig],MathematicaSDP-> OptionValue[MathematicaSDP],MyFunctional->OptionValue[MyFunctional]],{i,1,DataLength}];
Return[DataTable]]



(* ::Section:: *)
(*Dilations*)


(* ::Text:: *)
(*This section contains functions for dilating a tuple toward a free extreme point of the given free spectrahedron*)


(* ::Input::Initialization:: *)
 (* DilationSubspaceDimension computes the dimension of the dilation subspaces of X in the free spectrahedron D_A *)
  
  Options[DilationSubspaceDimension]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),ChopCutoff-> 10^(-3)}
  DilationSubspaceDimension[A_,X_,OptionsPattern[]]:=Block[{g,Ag,n,Alin,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZArvMat,ZArvVars,NullContainmentEqsBasic,NullContainmentEqs,NullContainmentTable,NullSystemMat,NullSystemEigVals,NullSystemEigenVecs,ZSolExistQ,ZSolConfidence,ArvesonQ,BadSystemNumerics,NullVecs,ZSubRus,DilateCoef,NextMaximalBeta,DilateBetaIterate,DilateBeta,DilateGamma,DilateX,DilateFunctional,DilateLMI,DilateVars,DilateSDP,DilateSDPY,DilateSDPZ,DilateSDPS,DilateSDPflags,MaximalDilateRu,MaximalDilateX,DilationSize,DilationArvesonQ},
  g=Length[X];
  Ag=Length[A];
  If[SameQ[g,Ag],Alin=A,Alin=A[[2;;All]]];
  n=Length[X[[1]]];
  MaximalDilateX=BadNumerics;
  {LMIEigenvalues,LMIEigenvectors}=Eigensystem[LMI[A,X]];
  {NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
  If[SameQ[NullVecStartIterate,False],Return[n*g],
  If[SameQ[NullVecStartIterate,BadNumerics],Return[{BadNullNumerics,{NullConfidence,BadNullNumerics}}],
  NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
  ZArvMat=MakeZArv[g,n];
  ZArvVars=Variables[ZArvMat];
  NullContainmentEqsBasic=Lambda[Alin,ZArvMat].NullInclusionMatrix;
  NullContainmentEqs=DeleteCases[DeleteCases[Flatten[NullContainmentEqsBasic],0.],0];
  NullContainmentTable=Table[NullContainmentEqs[[i]]==0,{i,1,Length[NullContainmentEqs]}];
  NullSystemMat=Normal[CoefficientArrays[NullContainmentTable,ZArvVars]][[2]];
  {NullSystemEigVals,NullSystemEigenVecs}=Eigensystem[Transpose[NullSystemMat].NullSystemMat];
  If[NullSystemMat==0,Return[True]];
  {ZSolExistQ,ZSolConfidence}=DetermineNull[NullSystemEigVals,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]]]];
  If[SameQ[ZSolExistQ,False], Return[0] ,Return[Length[NullSystemEigVals]-ZSolExistQ+1]]]
  
  (* DilationSubspaceBasis computes a  basis for the dilation subspace of the spectrahedron defined by A at the tuple X *)
  
  
Options[DilationSubspaceBasis]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),ChopCutoff-> 10^(-3)}
DilationSubspaceBasis[A_,X_,OptionsPattern[]]:=Block[{DilationSubspaceBasisVecs,DilationSubspaceBasisPreVecs,g,Ag,n,Alin,LMIEigenvalues,LMIEigenvectors,NullVecStartIterate,NullConfidence,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,NullInclusionMatrix,ZArvMat,ZArvVars,NullContainmentEqsBasic,NullContainmentEqs,NullContainmentTable,NullSystemMat,NullSystemEigVals,NullSystemEigenVecs,ZSolExistQ,ZSolConfidence,ArvesonQ,BadSystemNumerics,NullVecs,ZSubRus,DilateCoef,NextMaximalBeta,DilateBetaIterate,DilateBeta,DilateGamma,DilateX,DilateFunctional,DilateLMI,DilateVars,DilateSDP,DilateSDPY,DilateSDPZ,DilateSDPS,DilateSDPflags,MaximalDilateRu,MaximalDilateX,DilationSize,DilationArvesonQ},
  g=Length[X];
  Ag=Length[A];
  If[SameQ[Ag,g],Alin=A,Alin=A[[2;;All]]];
  n=Length[X[[1]]];
  MaximalDilateX=BadNumerics;
  {LMIEigenvalues,LMIEigenvectors}=Eigensystem[LMI[A,X]];
  {NullVecStartIterate,NullConfidence}=DetermineNull[LMIEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment->  OptionValue[NumericsAssessment],NumericsAssessment->  OptionValue[NumericsAssessmentTol]];
  If[SameQ[NullVecStartIterate,False],
	DilationSubspaceBasisPreVecs=IdentityMatrix[g*n];
	DilationSubspaceBasisVecs=Table[VecToBeta[DilationSubspaceBasisPreVecs[[i]],g,n],{i,Length[DilationSubspaceBasisPreVecs]}];
	Return[DilationSubspaceBasisVecs],
  If[SameQ[NullVecStartIterate,BadNumerics],Return[{BadNullNumerics,{NullConfidence,BadNullNumerics}}],
  NullInclusionMatrix=Transpose[Table[LMIEigenvectors[[i]],{i,NullVecStartIterate,Length[LMIEigenvectors]}]];
  ZArvMat=MakeZArv[g,n];
  ZArvVars=Variables[ZArvMat];
  NullContainmentEqsBasic=Lambda[Alin,ZArvMat].NullInclusionMatrix;
  NullContainmentEqs=DeleteCases[DeleteCases[Flatten[NullContainmentEqsBasic],0.],0];
  NullContainmentTable=Table[NullContainmentEqs[[i]]==0,{i,1,Length[NullContainmentEqs]}];
  NullSystemMat=Normal[CoefficientArrays[NullContainmentTable,ZArvVars]][[2]];
  {NullSystemEigVals,NullSystemEigenVecs}=Eigensystem[Transpose[NullSystemMat].NullSystemMat];
  {ZSolExistQ,ZSolConfidence}=DetermineNull[NullSystemEigVals,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
  ArvesonQ=If[SameQ[False,ZSolExistQ],True,
  If[SameQ[ZSolExistQ,BadNumerics],BadSystemNumerics,False]];
  If[ArvesonQ==False,DilationSubspaceBasisPreVecs=NullSystemEigenVecs[[ZSolExistQ;;Length[NullSystemEigenVecs]]];
DilationSubspaceBasisVecs=Table[VecToBeta[DilationSubspaceBasisPreVecs[[i]],g,n],{i,Length[DilationSubspaceBasisPreVecs]}];
  Return[DilationSubspaceBasisVecs],
  Return["The given tuple is Arveson extreme"]]]]]

  
  
  (* Maximal1Dilation attempts to compute a maximal 1 dilation of X in the free spectrahedron D_A of the form {{X,c*beta},{c*Tranpose[beta],gamma}}. Here c is a real number. The computed c should always be optimal; however a heuristic is used for gamma so optimality is not guaranteed. Initial tests are highly succesful however. *)
  
  Options[Maximal1DilationGivenBeta]:={EigMagTol->10^(-6),EigGapTol->10^(-5),NumericsAssessment->True,NumericsAssessmentTol->10^(-2),ChopCutoff->10^(-3),TolGap->10^(-9),GammaFunctionalWeight-> Null,MathematicaSDP-> True}
  Maximal1DilationGivenBeta[A_,X_,beta_,OptionsPattern[]]:=Block[{betaSDP,betaSDPY,betaSDPX,betaSDPS,betaSDPflags,g,n,H,gamma,gammaSDP,gammaSDPY,gammaSDPX,gammaSDPS,gammaSDPflags,LMIEval,SDPVars,SDPFunctional,sdp,XDi,XMaxBetaDi,XMaxBetaDiRu,XMaxgammaDi,XMaxgammaDiRu,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,TolGap,FunctionalCoefs,GammaFunctionalWeight,d,MathematicaSDP,betaSDPrule,betaconstraint,gammaconstraint},
  g=Length[X];
  n=Length[X[[1]]];
d=Length[A[[1]]];
  XDi=Table[ArrayFlatten[{{X[[i]],Z*beta[[i]]},{Z*Transpose[beta[[i]]],{{gamma[i]}}}}],{i,g}];
  SDPFunctional=Z;
  SDPVars=Join[{Z},Table[gamma[i],{i,g}]];

If[SameQ[OptionValue[MathematicaSDP],False],
 LMIEval={LMI[A,XDi]};
  betaSDP=SDPMatrices[SDPFunctional,LMIEval,SDPVars];
  {betaSDPY,betaSDPX,betaSDPS,betaSDPflags}=SDPSolve[betaSDP,GapTol->OptionValue[TolGap],FeasibilityTol->10.^(3)*OptionValue[TolGap],Symbol["PrintIterations"]-> False,Symbol["PrintSummary"]-> False];
  XMaxBetaDiRu={Z-> betaSDPY[[1,1,1]]};
  XMaxBetaDi=NCReplaceRepeated[XDi,XMaxBetaDiRu];,
 LMIEval=LMI[A,XDi];
betaconstraint=VectorGreaterEqual[{LMIEval,0},{"SemidefiniteCone",Length[LMIEval]}];
 XMaxBetaDiRu={Quiet[SemidefiniteOptimization[SDPFunctional,betaconstraint,SDPVars]][[1]]};
(*Set up substitution rule and substitute*)
XMaxBetaDi=NCReplaceRepeated[XDi,XMaxBetaDiRu];];
  SDPVars=Table[gamma[i],{i,g}];
  If[SameQ[OptionValue[GammaFunctionalWeight],Null],
  FunctionalCoefs=Table[RandomReal[],{i,Length[SDPVars]}],
  FunctionalCoefs=OptionValue[GammaFunctionalWeight]];
  SDPFunctional=Dot[SDPVars,FunctionalCoefs];
If[SameQ[OptionValue[MathematicaSDP],False],
LMIEval={LMI[A,XMaxBetaDi]};
  gammaSDP=SDPMatrices[SDPFunctional,LMIEval,SDPVars];
  {gammaSDPY,gammaSDPX,gammaSDPS,gammaSDPflags}=SDPSolve[gammaSDP,GapTol->OptionValue[TolGap],FeasibilityTol->10.^(3)*OptionValue[TolGap],Symbol["PrintIterations"]-> False,Symbol["PrintSummary"]-> False];
  XMaxgammaDiRu=Table[Rule[gamma[i],gammaSDPY[[1,1,i]]],{i,g}];
  XMaxgammaDi=NCReplaceRepeated[XMaxBetaDi,XMaxgammaDiRu];,
LMIEval=LMI[A,XMaxBetaDi];
gammaconstraint=VectorGreaterEqual[{LMIEval,0},{"SemidefiniteCone",d*(n+1)}];
XMaxgammaDiRu=Quiet[SemidefiniteOptimization[SDPFunctional,gammaconstraint,SDPVars]];
(*Set up substitution rule and substitute*)
XMaxgammaDi=NCReplaceRepeated[XMaxBetaDi,XMaxgammaDiRu];];
  Return[{XMaxgammaDi,FunctionalCoefs}]]
  
  
  
  (* Maximal1Dilation attempts to compute a maximal 1 dilation of X in the free spectrahedron D_A of the form {{X,beta},{Tranpose[beta],gamma}}. beta is computed for the user in this version The computed beta should always be optimal; however a heuristic is used for gamma so optimality is not guaranteed. Initial tests are highly succesful however. *)
  Options[Maximal1Dilation]:={EigMagTol->10^(-6),EigGapTol->10^(-5),NumericsAssessment->True,NumericsAssessmentTol->10^(-2),ChopCutoff->10^(-3),TolGap->10^(-9),GammaFunctionalWeight-> Null,MathematicaSDP-> True}
  Maximal1Dilation[A_,X_,OptionsPattern[]]:=Block[{beta,g,n,DiSubBasis,DiSubDim,XMax1Di,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,TolGap,ChopCutoff,GammaFunctionalWeight,FunctionalCoefs,MathematicaSDP},
  g=Length[X];
  n=Length[X[[1]]];
  DiSubDim=DilationSubspaceDimension[A,X,EigMagTol->  OptionValue[EigMagTol],EigGapTol-> OptionValue[EigGapTol],NumericsAssessment->OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff]];
  If[SameQ[DiSubDim,0],Return["The given tuple is Arveson extreme"],
If[SameQ[DiSubDim,g*n],beta=Table[Transpose[{Table[1,{i,n}]}],{j,g}],
 DiSubBasis=DilationSubspaceBasis[A,X,EigMagTol->  OptionValue[EigMagTol],EigGapTol-> OptionValue[EigGapTol],NumericsAssessment->OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff]];
  If[SameQ[DiSubBasis[[1]],False],beta=VecToBeta[Table[1,{i,n*g}],g,n],
  beta=DiSubBasis[[1]]]]];
  {XMax1Di,FunctionalCoefs}=Maximal1DilationGivenBeta[A,X,beta,MathematicaSDP-> OptionValue[MathematicaSDP],EigMagTol-> OptionValue[EigMagTol],EigGapTol-> OptionValue[EigGapTol],NumericsAssessment->OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff],TolGap-> OptionValue[TolGap],GammaFunctionalWeight-> OptionValue[GammaFunctionalWeight]];
  Return[{XMax1Di,FunctionalCoefs}]]

  (* Maxmial1DilationRepeated attempts to compute success maximal 1-dilations of the given tuple X. The function will stop after reaching an Arveson extreme point of the free spectrahedron or after a user specified number of iterations *)
Maximal1DilationRepeated[lmi_,tuple_,MaxIters_]:=Block[{DiSubDim,DiSubDimTemp,tupleTemp,Max1Di,iters,failediters},
DiSubDim=DilationSubspaceDimension[lmi,tuple];
iters=0;
failediters=0;
Max1Di=tuple;
While[DiSubDim>0&&iters<MaxIters,
tupleTemp=Maximal1Dilation[lmi,Max1Di][[1]];
DiSubDimTemp=DilationSubspaceDimension[lmi,tupleTemp];
If[DiSubDim>DiSubDimTemp,
DiSubDim=DiSubDimTemp;
Max1Di=tupleTemp,
failediters=failediters+1];
iters=iters+1];
Return[{Max1Di,iters,failediters}]]



(* ::Section:: *)
(*Matrix Extreme Classification*)


(* ::Text:: *)
(*This section contains rudimentary functions with a goal of finding matrix extreme points.*)


(* BetaCommutantDimension computes the dimension of a relaxation of the commutant. *)
Options[BetaCommutantDimension]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),ChopCutoff-> 10^(-3)}
BetaCommutantDimension[X_,beta_,OptionsPattern[]]:=Block[{g,n,YMat,CommutantEqs,CommutantSystemMat,CommutantSystemEigVals,CommutantSystemEigVecs,CommSolExistQ,CommSolConfidence,EigMagTol,EigGapTol,ChopCutoff,NumericsAssessment,NumericsAssessmentTol,CommDim,BadNumerics,BadSystemNumerics,DiSubDim,DilationBeta,YSquare,YCol},
g=Length[X];
n=Length[X[[1]]];
YMat=MakeY[n+1];
YSquare=YMat[[1;;n,1;;n]];
YCol=Transpose[{YMat[[1;;n,n+1]]}];
CommutantEqs=Map[EqualsZero,DeleteCases[Chop[Flatten[Table[YSquare.X[[i]]+YCol.Transpose[beta[[i]]]-X[[i]].YSquare-beta[[i]].Transpose[YCol],{i,g}]],OptionValue[ChopCutoff]],0]];
If[Length[CommutantEqs]==0,Return[{n*(n+1)/2+n,0}]];
CommutantSystemMat=N[Normal[CoefficientArrays[CommutantEqs,Variables[YMat]]][[2]]];
{CommutantSystemEigVals,CommutantSystemEigVecs}=Eigensystem[Transpose[CommutantSystemMat].CommutantSystemMat];
{CommSolExistQ,CommSolConfidence}=DetermineNull[CommutantSystemEigVals,OptionValue[EigMagTol],OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessment-> OptionValue[NumericsAssessmentTol]];
If[SameQ[CommSolExistQ,BadNumerics],CommDim=BadSystemNumerics,CommDim=Length[CommutantSystemEigVals]-CommSolExistQ+1];
Return[{CommDim,CommSolConfidence}]]

(* Relaxed matrix extreme test checks if a tuple has a one dimensional dilation subspace and if it has a trivial beta commutant. This test is intended to help with finding matrix extreme points. *)
Options[RelaxedMatrixExtremeTest]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),ChopCutoff-> 10^(-3)}
RelaxedMatrixExtremeTest[A_,X_,OptionsPattern[]]:=Block[{g,n,YMat,CommutantEqs,CommutantSystemMat,CommutantSystemEigVals,CommutantSystemEigVecs,CommSolExistQ,CommSolConfidence,EigMagTol,EigGapTol,ChopCutoff,NumericsAssessment,NumericsAssessmentTol,CommDim,BadNumerics,BadSystemNumerics,DiSubDim,DilationBeta,YSquare,YCol,BetaCommDim,BetaCommConfidence},
g=Length[X];
n=Length[X[[1]]];
DiSubDim=DilationSubspaceDimension[A,X,EigMagTol-> OptionValue[EigMagTol],EigGapTol->  OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol->  OptionValue[NumericsAssessmentTol],ChopCutoff->  OptionValue[ChopCutoff]];
If[SameQ[SameQ[Element[DiSubDim,Integers],True],False],Return[{False,"There was an error in computation of the dilation subspace"}]];
If[DiSubDim==0,Return[{False,"The tuple is Arveson Extreme"}]];
If[DiSubDim>1,Return[{False,"The dilation subspace has dimension two or greater"}]];
DilationBeta=DilationSubspaceBasis[A,X,EigMagTol-> OptionValue[EigMagTol],EigGapTol->  OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol->  OptionValue[NumericsAssessmentTol],ChopCutoff->  OptionValue[ChopCutoff]][[1]];
{BetaCommDim,BetaCommConfidence}=BetaCommutantDimension[X,DilationBeta,EigMagTol-> OptionValue[EigMagTol],EigGapTol->  OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol->  OptionValue[NumericsAssessmentTol],ChopCutoff->  OptionValue[ChopCutoff]];
If[SameQ[BetaCommDim,BadNullNumerics],Return[{False,"The dimension of the BetaCommutant could not be determined"}],
If[BetaCommDim>1,Return[{False,{BetaCommDim,BetaCommConfidence}}],Return[{True,{BetaCommDim,BetaCommConfidence}}]]]]



(* ::Section:: *)
(*Utilities*)


(* ::Text:: *)
(*This section contains utility functions. Examples include viewing graphics of level 1 of a g=2 spectrahedron, viewing nice presentations of LMI to look at, and Random g=2 LMI coefficient generation*)


(* ::Input::Initialization:: *)
(* TupleNorm computes the norm of a tuple *)
TupleNorm[tuple_]:=Sqrt[Norm[Sum[tuple[[i]]^2,{i,Length[tuple]}]]]

(* LeftTupleMult left multiplies Tuple by the matrix M *)
LeftMultTuple[M_,tuple_]:=Table[M.tuple[[i]],{i,Length[tuple]}]

(* RightTupleMult Right multiplies Tuple by the matrix M *)
RightMultTuple[M_,tuple_]:=Table[tuple[[i]].M,{i,Length[tuple]}]

(* ConjTuple right multiplies Tuple by M and left multiplies by M^* *)
ConjTuple[M_,tuple_]:=RightMultTuple[Transpose[M],LeftMultTuple[M,tuple]]

(* TupleComm commutes the commutante of Tuple with M *)
TupleComm[M_,tuple_]:=LeftMultTuple[M,tuple]-RightMultTuple[M,tuple]

(* ArvTanVec Computes the element of the Arveson tangent space corresponding to beta and M *)
ArvTanVec[M_,beta_]:=LeftMultTuple[M,Map[Transpose,beta]]+Map[Transpose,LeftMultTuple[M,Map[Transpose,beta]]]


(* ViewTuple is short for Map[MatrixForm,Tuple] *)
ViewTuple[tuple_]:=Map[MatrixForm,tuple]

(* Shows evaluation of the LMI[A,X] on a symbolic variable X *)
ViewLMIGraphic[a_]:=Block[{X},
Print[IdentityMatrix[Length[a[[1]]]]-Sum[KroneckerProduct[a[[i]],{{X[i]}}],{i,Length[a]}]//MatrixForm]]

(* Note: ViewPolyhedron2D only works when the input is a polyhedron, i.e. defined by a tuple of diagonal matrices*)
ViewPolyhedron2D[a_]:=Block[{ConstraintList,Constraint,d,g,x,RegionUpperBoundList,RegionLowerBoundList,ACoefBoundList},(
d=Length[a[[1]]];
g=Length[a];
ConstraintList=Table[1-Sum[a[[j,i,i]]*x[j],{j,g}]>0,{i,d}];
Constraint=ConstraintList[[1]];
Do[Constraint=And[Constraint,ConstraintList[[i]]],{i,2,d}];
ACoefBoundList=Table[Table[If[a[[j,i,i]]!=0,1/a[[j,i,i]],0],{i,d}],{j,g}];
RegionUpperBoundList=Table[Max[ACoefBoundList[[j]]]+4,{j,g}];
RegionLowerBoundList=Table[Min[ACoefBoundList[[j]]]-4,{j,g}];
Return[RegionPlot[Constraint,{x[1],RegionLowerBoundList[[1]],RegionUpperBoundList[[1]]},{x[2],RegionLowerBoundList[[2]],RegionUpperBoundList[[2]]}]]
(*Return[RegionUpperBoundList]*)
)]

(* Level1ExtremePlot makes a plot of the extreme points at level 1 of the given spectrahedron *)
Options[Level1ExtremePlot]:={PointCount-> 10000,g4GraphicsStyle-> Graphics3D}
Level1ExtremePlot[A_,OptionsPattern[]]:=Block[{g,ExtremePointList,PointCount,DiagnosticLevel,minval,maxval,midval,g4GraphicsStyle},
g=Length[A];
If[g!=2&&g!=3&&g!=4,Return["SpectrahedronLevel1ExtremePlot is not supported on a g-tuple of this size"];];
ExtremePointList=Table[Flatten[FindExtremePoint[A,1,DiagnosticLevel-> 0]],{i,OptionValue[PointCount]}];
If[g==2,Return[ListPlot[ExtremePointList]],
If[g==3,Return[ListPointPlot3D[ExtremePointList, Axes -> True, BoxRatios -> {1, 1, 1/GoldenRatio}]],
If[SameQ[OptionValue[g4GraphicsStyle],Graphics3D],
Return[Graphics3D[{PointSize[0.004],
   Point[ExtremePointList[[All, 1 ;; 3]], VertexColors -> Hue /@ ExtremePointList[[All, 4]]],
   Axes -> True, BoxRatios -> {1, 1, 1/GoldenRatio}}]];,
minval=Min[ExtremePointList[[All,4]]];
maxval=Max[ExtremePointList[[All,4]]];
midval=(minval+maxval)/2;
Return[ListPointPlot3D[List /@ ExtremePointList[[All, {1, 2, 3}]], 
 PlotStyle -> ({PointSize[Small], 
      Blend[{{minval, Blue}, {midval, Darker[Green]}, {maxval, 
         Red}}, #1]} & /@ Flatten[ExtremePointList[[All, {4}]]])]]]]
];]


(* DeleteZeros deletes the zeros from a given list *)

DeleteZeros[list_]:=DeleteCases[list,0]

(* CountIrreducibles counts the number of irreducible tuples in a table generated using FindExtremePoint *)

CountIrreducibles[ExtremeList_]:=Block[{iterate,IrredCount},
iterate=1;
IrredCount=0;
While[iterate<= Length[ExtremeList],
If[SameQ[ExtremeList[[iterate,9]],True],
IrredCount=IrredCount+1];
iterate=iterate+1];
Return[IrredCount]]

(* countNullDims and countNullTan is are specialty functions that are called by ExtremeDataAnalysis. countNullDims counts the number of null spaces of a given size in a list and  countNullTan counts the number of pairs of a fixed kernel and tangent space size *)

Options[countNullDims]:={AnalyzeIrredOnly-> True}
countNullDims[list_,n_,OptionsPattern[]]:=Block[{iterate,count,AnalyzeIrredOnly},
iterate=1;
count=0;
If[SameQ[OptionValue[AnalyzeIrredOnly],True],
While[iterate<= Length[list],
If[SameQ[list[[iterate,7]],n]&&SameQ[list[[iterate,9]],True],
count=count+1];
iterate=iterate+1];
If[SameQ[count,0],Return[0],Return[{n,count}]],
While[iterate<= Length[list],
If[SameQ[list[[iterate,7]],n],
count=count+1];
iterate=iterate+1];
If[SameQ[count,0],Return[0],Return[{n,count}]]]]

Options[countNullTan]:={AnalyzeIrredOnly-> True}
countNullTan[list_,n_,m_,OptionsPattern[]]:=Block[{iterate,count,AnalyzeIrredOnly},
iterate=1;
count=0;
If[SameQ[OptionValue[AnalyzeIrredOnly],True],
While[iterate<= Length[list],
If[SameQ[list[[iterate,7]],n]&&SameQ[list[[iterate,8]],m]&&SameQ[list[[iterate,9]],True],
count=count+1];
iterate=iterate+1];
If[SameQ[count,0],Return[0],Return[{n,m,count}]],
While[iterate<= Length[list],
If[SameQ[list[[iterate,7]],n]&&SameQ[list[[iterate,8]],m],
count=count+1];
iterate=iterate+1];
If[SameQ[count,0],Return[0],Return[{n,m,count}]]]]


(* ExtremeDataAnalysis takes a list generated by GenerateExtremeData and counts the number of points with specificed null space size and null space tangent space size pairs for Arveson and Euclidean extreme points *)

Options[ExtremeDataAnalysis]:={AnalyzeIrredOnly-> True}
ExtremeDataAnalysis[A_,list_,OptionsPattern[]]:=Block[{n,d,g,listLength,ReducibleArvEucCount,ArvesonPointList,ArvesonListIterate,BadNullNumerics,BadSystemNumerics,BadNullNumericsList,BadNullNumericsIterateList,EuclideanPointList,NonExtremePointList,NonExtremePointCount,ArvesonPointCount,EuclideanPointCount,ArvesonNullData,EuclideanNullData,ArvesonPointsCounted,EuclideanPointsCounted,ArvesonTangentData,EuclideanTangentData,IrredArvCount,IrredEucCount,AnalyzeIrredOnly},
n=Length[list[[1,1,1]]];
d=Length[A[[1]]];
g=Length[list[[1,1]]];
listLength=Length[list];
ArvesonPointList={};
BadNullNumericsList={};
BadNullNumericsIterateList={};
EuclideanPointList={};
ArvesonListIterate=1;

While[ArvesonListIterate<= listLength,
If[SameQ[list[[ArvesonListIterate,3]],True],ArvesonPointList=Append[ArvesonPointList,list[[ArvesonListIterate]]],
If[SameQ[list[[ArvesonListIterate,3]],BadNullNumerics]||SameQ[list[[ArvesonListIterate,3]],BadSystemNumerics],BadNullNumericsList=Append[BadNullNumericsList,list[[ArvesonListIterate]]];
BadNullNumericsIterateList=Append[BadNullNumericsIterateList,ArvesonListIterate];,
If[SameQ[list[[ArvesonListIterate,3]],False]&&SameQ[list[[ArvesonListIterate,5]],True],EuclideanPointList=Append[EuclideanPointList,list[[ArvesonListIterate]]]]]];
;
ArvesonListIterate=ArvesonListIterate+1];
NonExtremePointList=Complement[list,Join[ArvesonPointList,BadNullNumericsList,EuclideanPointList]];
ReducibleArvEucCount=Length[Join[ArvesonPointList,EuclideanPointList]]-CountIrreducibles[Join[ArvesonPointList,EuclideanPointList]];

NonExtremePointCount=Length[NonExtremePointList];
ArvesonPointCount=Length[ArvesonPointList];
EuclideanPointCount=Length[EuclideanPointList];

If[ArvesonPointCount!= 0,ArvesonNullData=DeleteZeros[Table[countNullDims[ArvesonPointList,l,AnalyzeIrredOnly-> OptionValue[AnalyzeIrredOnly]],{l,0,d*n}]];,
ArvesonNullData=False];

If[EuclideanPointCount!= 0,EuclideanNullData=DeleteZeros[Table[countNullDims[EuclideanPointList,l,AnalyzeIrredOnly-> OptionValue[AnalyzeIrredOnly]],{l,0,d*n}]];,
EuclideanNullData=False];

IrredArvCount=CountIrreducibles[ArvesonPointList];
IrredEucCount=CountIrreducibles[EuclideanPointList];
If[Length[ArvesonNullData]!= 0,ArvesonTangentData=Map[DeleteZeros,Table[countNullTan[ArvesonPointList,l,k],{l,ArvesonNullData[[1,1]],ArvesonNullData[[Length[ArvesonNullData],1]]},{k,-n*(n-1)/2,n*(n+1)*g/2}]];,
ArvesonTangentData=False];
If[Length[EuclideanNullData]!= 0,EuclideanTangentData=Map[DeleteZeros,Table[countNullTan[EuclideanPointList,l,k],{l,EuclideanNullData[[1,1]],EuclideanNullData[[Length[EuclideanNullData],1]]},{k,-n*(n-1)/2,n*(n+1)*g/2}]];,
EuclideanTangentData=False];
Return[{ArvesonNullData,IrredArvCount,ArvesonTangentData,EuclideanNullData,IrredEucCount,EuclideanTangentData,{BadNullNumericsIterateList,Length[BadNullNumericsIterateList]},ReducibleArvEucCount,NonExtremePointCount,EuclideanPointList} ]] 


(* FindExtremeAndAnalyze is an all in one function that generates data using GenerateExtremeData then prints the analysis given by ExtremeDataAnalysis *)

Options[FindExtremeAndAnalyze]:={EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,NumericsAssessmentTol-> 10^(-2),ChopCutoff-> 10^(-3),TolGap-> 10^(-9),AnalyzeIrredOnly-> True,OutputFile->False, Sig->0,MyFunctional->MakeFunctionalRational,MathematicaSDP-> True}
FindExtremeAndAnalyze[A_,n_,DataLength_,Seed_,OptionsPattern[]]:=Block[{ExtremeDataTable,ExtremeAnalysisTable,EigMagTol,EigGapTol,NumericsAssessment,IrredAssessment,NumericsAssessmentTol,ChopCutoff,TolGap,AnalyzeIrredOnly,OutputFile,EuclideanFunctionalsTable,filename,filepath,fileStream,WeightVector,WeightMatrix,Sig,MyFunctional,MathematicaSDP},
ExtremeDataTable=GenerateExtremeData[A,n,DataLength,Seed,DiagnosticLevel->4,EigMagTol-> OptionValue[EigMagTol],MathematicaSDP-> OptionValue[MathematicaSDP],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff],TolGap-> OptionValue[TolGap], Sig->OptionValue[Sig],MyFunctional-> OptionValue[MyFunctional]];
ExtremeAnalysisTable=ExtremeDataAnalysis[A,ExtremeDataTable,AnalyzeIrredOnly-> OptionValue[AnalyzeIrredOnly]];
Do[Print[ExtremeAnalysisTable[[i]]],{i,Length[ExtremeAnalysisTable]-1}];
If[SameQ[OptionValue[OutputFile],False]==False,
EuclideanFunctionalsTable=Table[ExtremeAnalysisTable[[10,i,2]],{i,Length[ExtremeAnalysisTable[[10]]]}];
filename=StringJoin[OptionValue[OutputFile]," n=",ToString[n]," iter=", ToString[DataLength], " seed=", ToString[Seed],".m"];
filepath=FileNameJoin[{$TemporaryDirectory,filename}];
fileStream=OpenWrite[filename];
WriteLine[fileStream,"The number functionals found that generate non-Arveson extreme points is"];
Write[fileStream,Length[EuclideanFunctionalsTable]];
WriteLine[fileStream," "];
WriteLine[fileStream, "This data was generated on "];
Write[fileStream,DateString[]];
WriteLine[fileStream,"The following linear functionals generate non-Arveson extreme points on the spectrahedron"];
WriteLine[fileStream," "];
Write[fileStream,A];
WriteLine[fileStream," "];
WriteLine[fileStream,"at level "];
Write[fileStream, n];
WriteLine[fileStream," "];
Write[fileStream,EuclideanFunctionalsTable];
WriteLine[fileStream," "];
Close[fileStream]];
Return[{ExtremeDataTable,ExtremeAnalysisTable}];]


(* MakeIrreducibleBoundedA makes a g tuple of d x d matrices A which define a bounded irreducible free spectrahedron. This is done randomly using the given seed. *)
Options[MakeIrreducibleBoundedA]:={Distribution->"uniform"}
MakeIrreducibleBoundedA[g_,d_,seed_,OptionsPattern[]]:=Block[{PreTuple,SymTuple,GoodQ,Distribution},
SeedRandom[seed];
GoodQ=False;
While[GoodQ==False||BoundedQ,
If[OptionValue[Distribution]=="uniform",
	PreTuple=Table[RandomInteger[{-25,25}]/10,{k,g},{j,d},{i,d}];
];
If[OptionValue[Distribution]=="gaussian",
	PreTuple=Table[RandomReal[NormalDistribution[0, 1]],{k,g},{j,d},{i,d}];
];
SymTuple=PreTuple+Map[Transpose,PreTuple];
If[CommutantDimension[SymTuple][[1]]==1&&BoundedQ[SymTuple],GoodQ=True];];
Return[SymTuple]]

(* MakeIrreducibleBoundedA makes a g tuple of d x d matrices A which define a bounded irreducible free spectrahedron. This is done randomly but does not require a seed input*)
Options[MakeIrreducibleBoundedANoSeed]:={Distribution->"uniform",MathematicaSDP->False}
MakeIrreducibleBoundedANoSeed[g_,d_,OptionsPattern[]]:=Block[{PreTuple,SymTuple,GoodQ, numRejected,Distribution,MathematicaSDP},
GoodQ=False;
numRejected = 0;
While[GoodQ==False||BoundedQ,
If[OptionValue[Distribution]=="uniform",
	PreTuple=Table[RandomInteger[{-25,25}]/10,{k,g},{j,d},{i,d}];
];
If[OptionValue[Distribution]=="gaussian",
	PreTuple=Table[RandomReal[NormalDistribution[0, 1]],{k,g},{j,d},{i,d}];
];
SymTuple=PreTuple+Map[Transpose,PreTuple];
If[CommutantDimension[SymTuple][[1]]==1&&BoundedQ[SymTuple,MathematicaSDP->OptionValue[MathematicaSDP]],GoodQ=True,numRejected+=1;];];
Return[{SymTuple,numRejected}]]

Options[MakeIrreducibleA]:={Distribution->"uniform"}
MakeIrreducibleA[g_,d_,seed_,OptionsPattern[]]:=Block[{PreTuple,SymTuple,IrreducibleQ,Distribution},
SeedRandom[seed];
IrreducibleQ=False;
While[IrreducibleQ==False,
If[OptionValue[Distribution]=="uniform",
	PreTuple=Table[RandomInteger[{-25,25}]/10,{k,g},{j,d},{i,d}];
];
If[OptionValue[Distribution]=="gaussian",
	PreTuple=Table[RandomReal[NormalDistribution[0, 1]],{k,g},{j,d},{i,d}];
];
SymTuple=PreTuple+Map[Transpose,PreTuple];
If[CommutantDimension[SymTuple][[1]]==1,IrreducibleQ=True];];
Return[SymTuple]]

MakeBoundedA[g_,d_,seed_]:=Block[{PreTuple,SymTuple,GoodQ,testedTuples},
SeedRandom[seed];
GoodQ=False;
While[GoodQ==False||BoundedQ,
PreTuple=Table[RandomInteger[{-25,25}]/10,{k,g},{j,d},{i,d}];
SymTuple=PreTuple+Map[Transpose,PreTuple];
If[BoundedQ[SymTuple],GoodQ=True];];
Return[SymTuple]]


GrabNonArvesonExtreme[list_]:=Block[{EucTable},
EucTable={};
Do[If[SameQ[list[[1,i,3]],False]==True&&SameQ[list[[1,i,5]],True]==True&&SameQ[list[[1,i,9]],True]==True,EucTable=Append[EucTable,list[[1,i]]]],{i,Length[list[[1]]]}];
Return[EucTable]]


Options[MakeMatrixSigned]:={Distribution->"uniform"}
MakeMatrixSigned[d_,Sig_,OptionsPattern[]]:=Block[{M,Signa,Signat,Distribution},
If[OptionValue[Distribution]=="uniform",
M=Table[RandomInteger[{-200000,200000}]/100000,{i,d},{j,d}];];
If[OptionValue[Distribution]=="gaussian",
M=Table[RandomReal[NormalDistribution[0, 1]],{i,d},{j,d}];];
For[i=1,i<=d,i++,
For[j=1,j<i,j++,
M[[i,j]]=0;
]
];
Signa=Floor[Sig];
If[Signa<0,Signa=0];
If[Signa>d,Signa=d];
Signat=DiagonalMatrix[Join[Table[1,{i,d-Signa}],Table[-1,{i,Signa}]]];
M=ConjugateTranspose[M].Signat.M;
Return[M];
]

Options[MakeBlockLinearFunctional]:={WeightMatrix->Null, Sig->0}
MakeBlockLinearFunctional[A_,n_,OptionsPattern[]]:=Block[{M,MBlock,GenX,g,d,WeightMatrix,Sig},
g=Length[A];
d=Length[A[[1]]];
GenX=MakeX[g,n];
If[SameQ[OptionValue[WeightMatrix],Null],
M=MakeMatrixSigned[d,OptionValue[Sig]];
MBlock=KroneckerProduct[M,IdentityMatrix[n]];,
M=OptionValue[WeightMatrix];
MBlock=KroneckerProduct[M,IdentityMatrix[n]]];
Return[{M,Simplify[Tr[MBlock.LMI[A,GenX]]]/(d*n)}];
]

Options[MakeFunctionalTrace]:={WeightMatrix->Null, Sig->0,Distribution->"uniform"}
MakeFunctionalTrace[A_,n_,OptionsPattern[]]:=Block[{M,GenX,g,d,WeightMatrix,Sig,Signat,Distribution},
g=Length[A];
d=Length[A[[1]]];
GenX=MakeX[g,n];
Signat=Floor[OptionValue[Sig]];
If[Signat<0,Signat=0];
If[Signat>d*n,Signat=d*n];
If[SameQ[OptionValue[WeightMatrix],Null],
M=MakeMatrixSigned[d*n,Signat,Distribution->OptionValue[Distribution]];,
If[Length[OptionValue[WeightMatrix]]==d*n&&Length[OptionValue[WeightMatrix][[1]]]==d*n,
M=OptionValue[WeightMatrix],
Print["WARNING: The WeightMatrix Option does not have the correct format."];
Return[Null];];];
Return[{M,Simplify[Tr[M.LMI[A,GenX]]]/(d*n)}];
]

GrabFunctionalCoefs[g_,n_,Functional_]:=Normal[CoefficientArrays[Functional,Variables[MakeX[g,n]]]][[2]]


(* BoundedQ maximizes and minimizes coordinate linear functionals over a spectrahedron which has been intersected with a cube of radius OptionValue[Radius]. The spectrahedron is reported to be unbounded if the optimizers have magnitude larger than OptionValue[ReferenceRadiusRation] times the radius of the cube. *)
Options[BoundedQ]:={Radius->1000, TolGap-> 10^(-9), ReferenceRadiusRatio->.99,MathematicaSDP->True}
BoundedQ[A_,OptionsPattern[]]:=Block[{g, d, cube, Radius, AugmentedA, Xg, lmi, SDPVars, sdp, Y, Z, S, flags, SDPWeight, SDPFunctional,TolGap,X,rule,ExtremeX,constraint,ReferenceRadiusRatio,MathematicaSDP},
g=Length[A];
d=Length[A[[1]]];
cube=Table[DiagonalMatrix[Join[ConstantArray[0,2(j-1)],{1,-1},ConstantArray[0,2(g-j)]]],{j,g}]/OptionValue[Radius];
AugmentedA=DirectSumTuple[{A, cube}];
Xg = MakeX[g, 1];
lmi = LMI[AugmentedA, Xg];
SDPVars = MakeSDPVars[Xg];
(* If OptinValue[MathematicaSDP] is True then use MMA SDP. *)
If[SameQ[OptionValue[MathematicaSDP],True],
(* First minimize linear functionals *)
For[i=1, i<=g, i++,
	{SDPWeight, SDPFunctional} = MakeFunctionalRational[g, 1, Symbol["WeightVector"] -> Join[ConstantArray[0,(i-1)],{1},ConstantArray[0,(g-i)]]];
		constraint=VectorGreaterEqual[{lmi,0},{"SemidefiniteCone",d+2*g}];
		rule=Quiet[SemidefiniteOptimization[SDPFunctional,constraint,SDPVars]];
		ExtremeX=Xg/.rule;
	If[Max[Abs[ExtremeX]]/OptionValue[Radius] > OptionValue[ReferenceRadiusRatio],
		Return[False];
	]
];
(* Next maximize Linear Functionals *)
For[i=1, i<=g, i++,
	{SDPWeight, SDPFunctional} = MakeFunctionalRational[g, 1, Symbol["WeightVector"] -> Join[ConstantArray[0,(i-1)],{-1},ConstantArray[0,(g-i)]]];
		constraint=VectorGreaterEqual[{lmi,0},{"SemidefiniteCone",d+2*g}];
		rule=Quiet[SemidefiniteOptimization[SDPFunctional,constraint,SDPVars]];
		ExtremeX=Xg/.rule;
	If[Max[Abs[ExtremeX]]/OptionValue[Radius] > OptionValue[ReferenceRadiusRatio],
		Return[False];
	]
];,
(* If OptionValue[MathematicaSDP] is not true then use NC SDP. Again minimize linear functionals first.  *)
For[i=1, i<=g, i++,
	{SDPWeight, SDPFunctional} = MakeFunctionalRational[g, 1, Symbol["WeightVector"] -> Join[ConstantArray[0,(i-1)],{1},ConstantArray[0,(g-i)]]];
	sdp = SDPMatrices[SDPFunctional, lmi, SDPVars];
	{Y,Z,S,flags}=SDPSolve[sdp,Symbol["GapTol"]-> OptionValue[TolGap],Symbol["FeasibilityTol"]-> 10.^(3)*OptionValue[TolGap],Symbol["PrintIterations"]-> False,Symbol["PrintSummary"]-> False];
	If[Max[Abs[Y[[1,1]]]]/OptionValue[Radius] > OptionValue[ReferenceRadiusRatio],
		Return[False];
	]
];
(* Maximize linear functionals *)
For[i=1, i<=g, i++,
	{SDPWeight, SDPFunctional} = MakeFunctionalRational[g, 1, Symbol["WeightVector"] -> Join[ConstantArray[0,(i-1)],{-1},ConstantArray[0,(g-i)]]];
	sdp = SDPMatrices[SDPFunctional, lmi, SDPVars];
	{Y,Z,S,flags}=SDPSolve[sdp,Symbol["GapTol"]-> OptionValue[TolGap],Symbol["FeasibilityTol"]-> 10.^(3)*OptionValue[TolGap],Symbol["PrintIterations"]-> False,Symbol["PrintSummary"]-> False];
	If[Max[Abs[Y[[1,1]]]]/OptionValue[Radius] > OptionValue[ReferenceRadiusRatio],
		Return[False];
	]
];];
Return[True];
]



(* ::Section:: *)
(*Extreme point generation for (A,ell) pair experiments.*)


(* ::Text:: *)
(* In these functions, a user specifies g and d rather than a defining tuple A. The defining tuples used are then randomly generated tuples of size (g,d) which define bounded irreducible free spectrahedra *)


(* ::Input::Initialization:: *)
Options[GenerateExtremeAndAnalyze2]:={Distribution->"uniform", EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,IrredAssessment-> True,NumericsAssessmentTol-> 10^(-2),ChopCutoff-> 10^(-3),TolGap-> 10^(-9),AnalyzeIrredOnly-> True,OutputFile->False,WeightVector-> Null,WeightMatrix->Null, Sig->0,MyFunctional->MakeFunctionalRational,MathematicaSDP->False}
GenerateExtremeAndAnalyze2[g_,d_,n_,DataLength_,Seed_,OptionsPattern[]]:=Block[{Distribution,s,ExtremeDataTable,ExtremeAnalysisTable,EigMagTol,EigGapTol,NumericsAssessment,IrredAssessment,NumericsAssessmentTol,ChopCutoff,TolGap,AnalyzeIrredOnly,OutputFile,EuclideanFunctionalsTable,filename,filepath,fileStream,WeightVector,WeightMatrix,Sig,MyFunctional,MathematicaSDP},
ExtremeDataTable=GenerateExtremeData2[g,d,n,DataLength,Seed,Distribution->OptionValue[Distribution],EigMagTol-> OptionValue[EigMagTol],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],IrredAssessment-> OptionValue[IrredAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff],TolGap-> OptionValue[TolGap],WeightVector->OptionValue[WeightVector],WeightMatrix->OptionValue[WeightMatrix], Sig->OptionValue[Sig],MyFunctional-> OptionValue[MyFunctional],MathematicaSDP->OptionValue[MathematicaSDP]];
ExtremeAnalysisTable=ExtremeDataAnalysis2[g,d,ExtremeDataTable,AnalyzeIrredOnly-> OptionValue[AnalyzeIrredOnly]];
Do[Print[ExtremeAnalysisTable[[i]]],{i,Length[ExtremeAnalysisTable]-1}];
If[SameQ[OptionValue[OutputFile],False]==False,
EuclideanFunctionalsTable=Table[ExtremeAnalysisTable[[11,i,2]],{i,Length[ExtremeAnalysisTable[[11]]]}];
EuclideanSpecsTable=Table[ExtremeAnalysisTable[[11,i,12]],{i,Length[ExtremeAnalysisTable[[11]]]}];

BigKernelFunctionalsTable=Table[ExtremeAnalysisTable[[12,i,2]],{i,Length[ExtremeAnalysisTable[[12]]]}];
BigKernelSpecsTable=Table[ExtremeAnalysisTable[[12,i,12]],{i,Length[ExtremeAnalysisTable[[12]]]}];

filename=StringJoin[OptionValue[OutputFile]," n=",ToString[n]," iter=", ToString[DataLength], " seed=", ToString[Seed],".m"];
filepath=FileNameJoin[{$TemporaryDirectory,filename}];
fileStream=OpenWrite[filename];
WriteLine[fileStream,"The number functionals found that generate non-Arveson extreme points is"];
Write[fileStream,Length[EuclideanFunctionalsTable]];
WriteLine[fileStream,"The number functionals found that generate high kernel dimension (greater than ceiling(3n/2)) extreme points is"];
Write[fileStream,Length[BigKernelFunctionalsTable]];
WriteLine[fileStream," "];
WriteLine[fileStream, "This data was generated on "];
Write[fileStream,DateString[]];
s=StringJoin["The following are pairs {Spectrahedron, LinearFunctional} where LinearFunctional generates an Euclidean point on Spectrahedron with g=", ToString[g], " and d=", ToString[d], " at level n=", ToString[n]];
WriteLine[fileStream,s];
WriteLine[fileStream," "];
For[i=1,i<=Length[EuclideanSpecsTable],i++,
Write[fileStream,{EuclideanSpecsTable[[i]],EuclideanFunctionalsTable[[i]]}];
];
s=StringJoin["The following are pairs {Spectrahedron, LinearFunctional} where LinearFunctional generates an extreme point on Spectrahedron with g=", ToString[g], " and d=", ToString[d], " at level n=", ToString[n], " such that k>ceiling(3n/2)."];
WriteLine[fileStream,s];
WriteLine[fileStream," "];
For[i=1,i<=Length[BigKernelSpecsTable],i++,
Write[fileStream,{BigKernelSpecsTable[[i]],BigKernelFunctionalsTable[[i]]}];
];

Close[fileStream]];
Return[{ExtremeDataTable,ExtremeAnalysisTable}];]


Options[GenerateExtremeData2]={Distribution->"uniform", EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,IrredAssessment-> True,NumericsAssessmentTol-> 10^(-2),ChopCutoff-> 10^(-3),TolGap-> 10^(-9),WeightVector-> Null,WeightMatrix->Null,Sig->0,MyFunctional-> MakeFunctionalRational, MathematicaSDP->False};
GenerateExtremeData2[g_,d_,n_,DataLength_,Seed_,OptionsPattern[]]:=Block[{Distribution,DataTable,EigMagTol,EigGapTol,NumericsAssessment,IrredAssessment,NumericsAssessmentTol,ChopCutoff,TolGap,WeightMatrix,Sig,WeightVector,MyFunctional,MathematicaSDP},
SeedRandom[Seed];
DataTable=Table[FindExtremePoint2[g,d,n,Distribution->OptionValue[Distribution], EigMagTol-> OptionValue[EigMagTol],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],IrredAssessment-> OptionValue[IrredAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff],TolGap-> OptionValue[TolGap],WeightVector->OptionValue[WeightVector],WeightMatrix->OptionValue[WeightMatrix], Sig->OptionValue[Sig],MyFunctional->OptionValue[MyFunctional],MathematicaSDP->OptionValue[MathematicaSDP]],{i,1,DataLength}];
Return[DataTable]]


Options[ExtremeDataAnalysis2]:={AnalyzeIrredOnly-> True}
ExtremeDataAnalysis2[g_,d_,list_,OptionsPattern[]]:=Block[{numRejected,n,listLength,ReducibleArvEucCount,ArvesonPointList,ArvesonListIterate,BadNullNumerics,BadSystemNumerics,BadNullNumericsList,BadNullNumericsIterateList,EuclideanPointList,NonExtremePointList,NonExtremePointCount,ArvesonPointCount,EuclideanPointCount,ArvesonNullData,EuclideanNullData,ArvesonPointsCounted,EuclideanPointsCounted,ArvesonTangentData,EuclideanTangentData,IrredArvCount,IrredEucCount,AnalyzeIrredOnly,BigKernelPointList},
n=Length[list[[1,1,1]]];
listLength=Length[list];
ArvesonPointList={};
BadNullNumericsList={};
BadNullNumericsIterateList={};
EuclideanPointList={};
BigKernelPointList={};
ArvesonListIterate=1;
numRejected = 0;

For[i=1,i<=Length[list],i++,
numRejected+=list[[i,11]];
]

While[ArvesonListIterate<= listLength,
If[SameQ[list[[ArvesonListIterate,3]],True],ArvesonPointList=Append[ArvesonPointList,list[[ArvesonListIterate]]],
If[SameQ[list[[ArvesonListIterate,3]],BadNullNumerics]||SameQ[list[[ArvesonListIterate,3]],BadSystemNumerics],BadNullNumericsList=Append[BadNullNumericsList,list[[ArvesonListIterate]]];
BadNullNumericsIterateList=Append[BadNullNumericsIterateList,ArvesonListIterate];,
If[SameQ[list[[ArvesonListIterate,3]],False]&&SameQ[list[[ArvesonListIterate,5]],True],EuclideanPointList=Append[EuclideanPointList,list[[ArvesonListIterate]]]]]];
;
ArvesonListIterate=ArvesonListIterate+1];
NonExtremePointList=Complement[list,Join[ArvesonPointList,BadNullNumericsList,EuclideanPointList]];
ReducibleArvEucCount=Length[Join[ArvesonPointList,EuclideanPointList]]-CountIrreducibles[Join[ArvesonPointList,EuclideanPointList]];

NonExtremePointCount=Length[NonExtremePointList];
ArvesonPointCount=Length[ArvesonPointList];
EuclideanPointCount=Length[EuclideanPointList];

If[ArvesonPointCount!= 0,ArvesonNullData=DeleteZeros[Table[countNullDims[ArvesonPointList,l,AnalyzeIrredOnly-> OptionValue[AnalyzeIrredOnly]],{l,0,d*n}]];,
ArvesonNullData=False];

If[EuclideanPointCount!= 0,EuclideanNullData=DeleteZeros[Table[countNullDims[EuclideanPointList,l,AnalyzeIrredOnly-> OptionValue[AnalyzeIrredOnly]],{l,0,d*n}]];,
EuclideanNullData=False];

ArvesonListIterate=1;
While[ArvesonListIterate<= listLength,
If[n>=2&&((SameQ[list[[ArvesonListIterate,3]],BadNullNumerics]||SameQ[list[[ArvesonListIterate,3]],BadSystemNumerics])==False)&&list[[ArvesonListIterate,7]]>Ceiling[3*n/2],BigKernelPointList=Append[BigKernelPointList,list[[ArvesonListIterate]]];
];
;
ArvesonListIterate=ArvesonListIterate+1];
IrredArvCount=CountIrreducibles[ArvesonPointList];
IrredEucCount=CountIrreducibles[EuclideanPointList];
If[Length[ArvesonNullData]!= 0,ArvesonTangentData=Map[DeleteZeros,Table[countNullTan[ArvesonPointList,l,k],{l,ArvesonNullData[[1,1]],ArvesonNullData[[Length[ArvesonNullData],1]]},{k,-n*(n-1)/2,n*(n+1)*g/2}]];,
ArvesonTangentData=False];
If[Length[EuclideanNullData]!= 0,EuclideanTangentData=Map[DeleteZeros,Table[countNullTan[EuclideanPointList,l,k],{l,EuclideanNullData[[1,1]],EuclideanNullData[[Length[EuclideanNullData],1]]},{k,-n*(n-1)/2,n*(n+1)*g/2}]];,
EuclideanTangentData=False];
Return[{ArvesonNullData,IrredArvCount,ArvesonTangentData,EuclideanNullData,IrredEucCount,EuclideanTangentData,{BadNullNumericsIterateList,Length[BadNullNumericsIterateList]},ReducibleArvEucCount,NonExtremePointCount,numRejected,EuclideanPointList, BigKernelPointList} ]] 


(* FindExtremePoint2 randomly generates a tuple A of size (g,d) which defines a bounded irreducible free spectrahedron, then optimizes a random linear functional over D_A at level n *)
Options[FindExtremePoint2]:={Distribution->"uniform", EigMagTol-> 10^(-6),EigGapTol-> 10^(-5),NumericsAssessment-> True,IrredAssessment-> True,NumericsAssessmentTol-> 10^(-2),TestExtremePointType->True,MyFunctional-> MakeFunctionalRational,ChopCutoff-> 10^(-3),TolGap-> 10^(-9),WeightVector-> Null,WeightMatrix->Null, Sig->0, MathematicaSDP->False}
FindExtremePoint2[g_,d_,n_,OptionsPattern[]]:=Block[{Distribution,numRejected,ExtremeX,SDPFunctional,X,Xg,lmi,MyFunctional,SDPVars,sdp,XRule,A,Y,Z,S,flags,ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance,PencilEigenvalues,NullSpaceAnalysis,NullSpaceDimension,TangentAnalysis,TangentSpaceDimension,X1Diag,TestExtremePointType,IrredAssessment,IrredData,CommDim,CommTol,ChopCutoff,TolGap,EigMagTol,EigGapTol,NumericsAssessment,NumericsAssessmentTol,BadNumerics,BadNullNumerics,WeightVector,WeightMatrix,Sig,MathematicaSDP},
{A,numRejected}=MakeIrreducibleBoundedANoSeed[g,d,Distribution->OptionValue[Distribution],MathematicaSDP->OptionValue[MathematicaSDP]];
(* Calls appropriate Generate extreme point function to generate an extreme point candadite. Will Generate an extreme point that has X1 diagonal if X1Diag option is True *)
{ExtremeX,SDPFunctional}=GenerateExtremePoint[A,g,n,Distribution->OptionValue[Distribution],MyFunctional-> OptionValue[MyFunctional],ChopCutoff-> OptionValue[ChopCutoff],TolGap->OptionValue[TolGap],WeightMatrix->OptionValue[WeightMatrix], Sig->OptionValue[Sig],WeightVector-> OptionValue[WeightVector],MathematicaSDP->OptionValue[MathematicaSDP]];

(* If TestExtremePointType is True then ClassifyExtremePoint is run. ClassifyExtremePoint first determines if an extreme point is Arveson. If it is not Arveson then it checks to see if the extreme point is Euclidean. *)
 If[OptionValue[TestExtremePointType]==True,
{ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance}=ClassifyExtremePoint[A,ExtremeX,EigMagTol->OptionValue[EigMagTol],EigGapTol->OptionValue[EigGapTol],NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol]]; ];
PencilEigenvalues=Eigenvalues[LMI[A,ExtremeX]];
NullSpaceAnalysis=DetermineNull[PencilEigenvalues,OptionValue[EigMagTol],OptionValue[EigGapTol]][[1]];
If[SameQ[NullSpaceAnalysis,False],NullSpaceDimension=False,If[SameQ[NullSpaceAnalysis,BadNumerics],NullSpaceDimension=BadNullNumerics,NullSpaceDimension=n*d-NullSpaceAnalysis+1]];
TangentSpaceDimension=FreeTangentNumerical[A,ExtremeX];

If[SameQ[OptionValue[IrredAssessment],False],IrredData="Not Analyzed",
If[SameQ[n,1],{CommDim,CommTol}={True,0},
IrredData=CommutantDimension[ExtremeX,EigMagTol-> OptionValue[EigMagTol]*10^(-3),EigGapTol-> OptionValue[EigGapTol]*10^-3,NumericsAssessment-> OptionValue[NumericsAssessment],NumericsAssessmentTol-> OptionValue[NumericsAssessmentTol],ChopCutoff-> OptionValue[ChopCutoff]*10^(-5)];
If[Length[IrredData]<2,{CommDim,CommTol}={1,0},
If[SameQ[IrredData[[1]],1],{CommDim,CommTol}={True,IrredData[[2]]},{CommDim,CommTol}={IrredData[[1]],IrredData[[2]]}]]]];
Return[{ExtremeX,SDPFunctional,ArvesonQ,ArvesonTolerance,EuclideanQ,EuclideanTolerance,NullSpaceDimension,TangentSpaceDimension,CommDim,CommTol,numRejected,A}]]


(* ::Section:: *)
(*Statistics from extreme point data*)


(* ::Text:: *)
(* These functions are used for generating various statistics about extreme points found using extreme point generation commands *)


(* ::Input::Initialization:: *)
  Options[GeneratePDFFromTable]:= {}
GeneratePDFFromTable[g_,d_,n_,list_, OptionsPattern[]] := Block[{listLength,ReducibleArvEucCount,ArvesonPointList,ArvesonListIterate,BadNullNumerics,BadSystemNumerics,BadNullNumericsList,BadNullNumericsIterateList,EuclideanPointList,NonExtremePointList,NonExtremePointCount,ArvesonPointCount,EuclideanPointCount,ArvesonNullData,EuclideanNullData,ArvesonPointsCounted,EuclideanPointsCounted,ArvesonTangentData,EuclideanTangentData,IrredArvCount,IrredEucCount,AnalyzeIrredOnly,ArvesonIrredNullData,EuclideanIrredNullData,TotalArv,TotalIrredArv,TotalEuc,TotalIrredEuc},
	listLength=Length[list];
	ArvesonPointList={};
	BadNullNumericsList={};
	BadNullNumericsIterateList={};
	EuclideanPointList={};
	ArvesonListIterate=1;

	While[ArvesonListIterate<= listLength,
	If[SameQ[list[[ArvesonListIterate,3]],True],ArvesonPointList=Append[ArvesonPointList,list[[ArvesonListIterate]]],
	If[SameQ[list[[ArvesonListIterate,3]],BadNullNumerics]||SameQ[list[[ArvesonListIterate,3]],BadSystemNumerics],BadNullNumericsList=Append[BadNullNumericsList,list[[ArvesonListIterate]]];
	BadNullNumericsIterateList=Append[BadNullNumericsIterateList,ArvesonListIterate];,
	If[SameQ[list[[ArvesonListIterate,3]],False]&&SameQ[list[[ArvesonListIterate,5]],True],EuclideanPointList=Append[EuclideanPointList,list[[ArvesonListIterate]]]]]];
	ArvesonListIterate=ArvesonListIterate+1];
	ArvesonPointCount=Length[ArvesonPointList];
	EuclideanPointCount=Length[EuclideanPointList];

	If[ArvesonPointCount!= 0,ArvesonNullData=DeleteZeros[Table[countNullDims[ArvesonPointList,l,AnalyzeIrredOnly-> False],{l,0,d*n}]];,
	ArvesonNullData=False];
	If[EuclideanPointCount!= 0,EuclideanNullData=DeleteZeros[Table[countNullDims[EuclideanPointList,l,AnalyzeIrredOnly-> False],{l,0,d*n}]];,
	EuclideanNullData=False];
	If[ArvesonPointCount!= 0,ArvesonIrredNullData=DeleteZeros[Table[countNullDims[ArvesonPointList,l,AnalyzeIrredOnly-> True],{l,0,d*n}]];,
	ArvesonIrredNullData=False];
	If[EuclideanPointCount!= 0,EuclideanIrredNullData=DeleteZeros[Table[countNullDims[EuclideanPointList,l,AnalyzeIrredOnly-> True],{l,0,d*n}]];,
	EuclideanIrredNullData=False];
	
	TotalArv = 0;
	TotalIrredArv = 0;
	TotalEuc = 0;
	TotalIrredEuc = 0;
	
	For[i=1,i<=Length[ArvesonNullData],i++,
		TotalArv += ArvesonNullData[[i,2]];
	];
	For[i=1,i<=Length[ArvesonIrredNullData],i++,
		TotalIrredArv += ArvesonIrredNullData[[i,2]];
	];
	For[i=1,i<=Length[EuclideanNullData],i++,
		TotalEuc += EuclideanNullData[[i,2]];
	];
	For[i=1,i<=Length[EuclideanIrredNullData],i++,
		TotalIrredEuc += EuclideanIrredNullData[[i,2]];
	];
	
	For[i=1,i<=Length[ArvesonNullData],i++,
		ArvesonNullData[[i,2]] /= TotalArv;
	];
	For[i=1,i<=Length[ArvesonIrredNullData],i++,
		ArvesonIrredNullData[[i,2]] /= TotalIrredArv;
	];
	For[i=1,i<=Length[EuclideanNullData],i++,
		EuclideanNullData[[i,2]] /= TotalEuc;
	];
	For[i=1,i<=Length[EuclideanIrredNullData],i++,
		EuclideanIrredNullData[[i,2]] /= TotalIrredEuc;
	];
Return[{ArvesonNullData,ArvesonIrredNullData,EuclideanNullData,EuclideanIrredNullData}]]

Options[GenerateCDFFromTable]:= {}
GenerateCDFFromTable[g_,d_,n_,list_, OptionsPattern[]] := Block[{ArvesonNullData,ArvesonIrredNullData,EuclideanNullData,EuclideanIrredNullData},
	{ArvesonNullData,ArvesonIrredNullData,EuclideanNullData,EuclideanIrredNullData} = GeneratePDFFromTable[g,d,n,list];
	
	For[i=2,i<=Length[ArvesonNullData],i++,
		ArvesonNullData[[i,2]]+=ArvesonNullData[[i-1,2]];
	];
	For[i=2,i<=Length[ArvesonIrredNullData],i++,
		ArvesonIrredNullData[[i,2]]+=ArvesonIrredNullData[[i-1,2]];
	];
	For[i=2,i<=Length[EuclideanNullData],i++,
		EuclideanNullData[[i,2]]+=EuclideanNullData[[i-1,2]];
	];
	For[i=2,i<=Length[EuclideanIrredNullData],i++,
		EuclideanIrredNullData[[i,2]]+=EuclideanIrredNullData[[i-1,2]];
	];
	Return[{ArvesonNullData,ArvesonIrredNullData,EuclideanNullData,EuclideanIrredNullData}]
]

Options[GenerateKerDimListFromTable]:= {}
GenerateKerDimListFromTable[d_,n_,list_, OptionsPattern[]] := Block[{listLength,ReducibleArvEucCount,ArvesonPointList,ArvesonListIterate,BadNullNumerics,BadSystemNumerics,BadNullNumericsList,BadNullNumericsIterateList,EuclideanPointList,NonExtremePointList,NonExtremePointCount,ArvesonPointCount,EuclideanPointCount,ArvesonNullData,EuclideanNullData,ArvesonPointsCounted,EuclideanPointsCounted,ArvesonTangentData,EuclideanTangentData,IrredArvCount,IrredEucCount,AnalyzeIrredOnly,ArvesonIrredNullData,EuclideanIrredNullData,TotalArv,TotalIrredArv,TotalEuc,TotalIrredEuc,ArvesonData,ArvesonIrredData,EuclideanData,EuclideanIrredData},
	listLength=Length[list];
	ArvesonPointList={};
	BadNullNumericsList={};
	BadNullNumericsIterateList={};
	EuclideanPointList={};
	ArvesonListIterate=1;
	While[ArvesonListIterate<= listLength,
	If[SameQ[list[[ArvesonListIterate,3]],True],ArvesonPointList=Append[ArvesonPointList,list[[ArvesonListIterate]]],
	If[SameQ[list[[ArvesonListIterate,3]],BadNullNumerics]||SameQ[list[[ArvesonListIterate,3]],BadSystemNumerics],BadNullNumericsList=Append[BadNullNumericsList,list[[ArvesonListIterate]]];
	BadNullNumericsIterateList=Append[BadNullNumericsIterateList,ArvesonListIterate];,
	If[SameQ[list[[ArvesonListIterate,3]],False]&&SameQ[list[[ArvesonListIterate,5]],True],EuclideanPointList=Append[EuclideanPointList,list[[ArvesonListIterate]]]]]];
	ArvesonListIterate=ArvesonListIterate+1];
	ArvesonPointCount=Length[ArvesonPointList];
	EuclideanPointCount=Length[EuclideanPointList];

	If[ArvesonPointCount!= 0,ArvesonNullData=DeleteZeros[Table[countNullDims[ArvesonPointList,l,AnalyzeIrredOnly-> False],{l,0,d*n}]];,
	ArvesonNullData=False];
	If[EuclideanPointCount!= 0,EuclideanNullData=DeleteZeros[Table[countNullDims[EuclideanPointList,l,AnalyzeIrredOnly-> False],{l,0,d*n}]];,
	EuclideanNullData=False];
	If[ArvesonPointCount!= 0,ArvesonIrredNullData=DeleteZeros[Table[countNullDims[ArvesonPointList,l,AnalyzeIrredOnly-> True],{l,0,d*n}]];,
	ArvesonIrredNullData=False];
	If[EuclideanPointCount!= 0,EuclideanIrredNullData=DeleteZeros[Table[countNullDims[EuclideanPointList,l,AnalyzeIrredOnly-> True],{l,0,d*n}]];,
	EuclideanIrredNullData=False];
	
	ArvesonData = {};
	For[i=1,i<=Length[ArvesonNullData],i++,
		ArvesonData = Join[ArvesonData,Table[ArvesonNullData[[i,1]],ArvesonNullData[[i,2]]]];
	];
	EuclideanData = {};
	For[i=1,i<=Length[EuclideanNullData],i++,
		EuclideanData = Join[EuclideanData,Table[EuclideanNullData[[i,1]],EuclideanNullData[[i,2]]]];
	];
	ArvesonIrredData = {};
	For[i=1,i<=Length[ArvesonIrredNullData],i++,
		ArvesonIrredData = Join[ArvesonIrredData,Table[ArvesonIrredNullData[[i,1]],ArvesonIrredNullData[[i,2]]]];
	];
	EuclideanIrredData = {};
	For[i=1,i<=Length[EuclideanIrredNullData],i++,
		EuclideanIrredData = Join[EuclideanIrredData,Table[EuclideanIrredNullData[[i,1]],EuclideanIrredNullData[[i,2]]]];
	];
	
	Return[{ArvesonData,ArvesonIrredData,EuclideanData,EuclideanIrredData}]
]

End[]
EndPackage[]


(* ::Section:: *)
(*Version History*)


(* ::Text:: *)
(*This section is an attempt to maintain a version history for the changes done to this notebook. *)
(**)
(*7 Feb 2020*)
(**)
(*Added the "Distribution" option to several functions. *)
(*Changed BoundedQ to use MathematicaSDP by default and added the MathematicaSDP function.*)
(*Fixed erroneously placed quotation marks in usage file which caused several issues. *)
(**)
(*17 Jan 2020*)
(**)
(*Reorganized body of notebook. Added descriptions to several functions. *)
(**)
(*Added reconciled version differences. Several functions had been added in another version for working with randomly generated A. These functions were added to the main branch *)
(**)
(*Removed the following functions which are no longer supported.*)
(*1. DiagonalGammaSearch*)
(*2. ArvesonDilateOnZero*)
(*3. ArvesonDoubleDilateOnZero*)
(**)
(*Dec 2020 *)
(**)
(*Converted almost all functions to used mathematica SDP by default. *)
(**)
(*29 Aug 2019 *)
(**)
(*1. Fixed bug in interaction of CommutantDimension and FindExtremePoint that in rare situations caused n(n+1)/2 dimensional commutant to be reported as 1 dimensional. Fortuantely FindExtremePoint reports "True" *)
(* for irreducible points rather than returning a commutant dimension, so in the eyes of FindExtremeAndAnalyze, these points were still considered reducible. .*)
(*2. Fixed possible bug in DetermineNull. In all cases where DetermineNull is used in the package, the input list is ordered from largest to smallest magnitutde. However a bug could occur if DetermineNull is given a list which is not ordered in this way. DetermineNull now orders lists from largest to smallest magnitutde *)
(**)
(**)
(*20May 2018 *)
(**)
(*Finished Functionality for MakeFunctionalTrace and MakeBlockFunctional in FindExtremePoint and GenerateExtreme and Analyze. These make linear functionals of the form Trace[M.LMI[A,X]] and Trace[M otimes I . LMI[A,X]], respectively.*)
(**)
(*Removed option to make functional with nonrational coefficients, and removed option to in FindExtremePoint to generate tuple with X1 diagonal. These have not been used in experiments. *)
(**)
(*15Apr 2018*)
(**)
(*1. Removed outdated functions for package version.*)
(*2. Changed FindExtremePointNoPrint to FindExtremePoint, and changed all calls for FindExtremePointNoPrint to FindExtremePointPrint. Removed old FindExtremePoint function.*)
(*3. Changed id and mf to IdentityMatrix and MatrixForm respectively. Short hand names will not be included in package.*)
(*4. Removed collection of LMI coefficients for package.*)
(*5. Changed write functionality in GenerateExtremeAndAnalyze to write to a directory*)
(*6. Changed write in GenerateExtremeAndAnalyze to output a table of linear functionals rather than individual linear functionals.*)
(**)
(*8 April 2018*)
(**)
(*Added the GrabNonArvesonExtreme function*)
(**)
(*6 April 2018 *)
(**)
(*1. Added a collection of functions to dilate Euclidean extreme to Arveson extreme. See functions whose name starts with "ArvesonDilate"*)
(*2. Added writing to generate extreme and analyze which writes functionals that generate Euclidean extreme points to an output file if an output name is specified.*)
(*3. Changed exact math to Numerical math in ArvesonTest and EuclideanTest to prevent kernel crashes*)
(*4. Closed comments left open in the preamble. *)
(*5. Added the TupleNorm utility function. This computes the 2 norm of a tuple. *)
(**)
(*26 March 2018 Fixed bug in GenerateExtremeAndAnalyze causing additional output. *)
(**)
(*18 March 2018: Added MakeIrreducibleA function which makes an irreducible g tuple of d x d symmetric matrices. Changed CommutantDimension to always use numerical arithemtic instead of exact.*)
(**)
(*15 March 2018:*)
(*1. Rearragned the functions under Extreme Point Generation and Classification section of preamble. Moved functions into subsubsections based on use. Identified and grouped currently unsupported functions.*)
(**)
(* 2. Added several utility functions. These are*)
(* *)
(* LeftTupleMult*)
(* RightTupleMult*)
(* TupleConj*)
(* ViewTuple*)
(* ArvTanVec*)
(* *)
(**)
(*10 March 2018: Bug fixes in ExtremeDataAnalysis. First bug caused points with BadSystemNumerics as Arveson True False value to be reported as Euclidean extreme points. The second bug caused points which were neither Arveson nor Euclidean extreme to be reported as Euclidean extreme points.*)
(**)
(*ExtremeDataAnalysis now outputs the number of points which are neither Arveson or Euclidean, although does not output data on these points. Additionally, the number reducible Arveson and Euclidean extreme points is now output.*)
(**)
(*7 March 2018: Fixed a bug in DeterimeNull that occured when the list contained negative values.*)
(**)
(*13 Feb 2018: Made new all in one function for extreme point generation and data analysis named "GenerateExtremeAndAnalyze". IMPORTANT: By default GenerateExtremeAndAnalyze only looks at irreducible points when generating data.*)


(* ::Text:: *)
(*2 February 2018: Updated ArvesonTest and EuclideanTest to work by solving the appropriate Kernel containment conditions. This should greatly improve speed and precision. Nullspace sizes are now determined using the DetermineNull command. This command finds a null space by looking for sufficiently sized gaps and small eigenvalues. Certain eigenvalue lists will cause the command to return "BadNullNumerics". This is intended to occur when the command cannot adequately *)
(* asses which values should be zero and which should not. An example of a list which should return this is {1,10^(-3),10^(-7),10^(-10)}. The issue is that 10^(-10) is likely 0, but the gaps between 10^(-10) and 10^(-7) and 10^(-3) are poor. It is also hard to say if 10^(-7) should be 0. *)
(* *)
(* ExtremePointListKernelAnalysis has been updated to handle when BadNullNumerics is returned by FindExtremePointNoPrint.*)
(* *)
(* Many old functions, including FindExtremePoint, may be broken after this update. The key functions, ArvesonTest, EuclideanTest, FindExtremePointNoPrint, and ExtremePointListKernelAnalysis should all be working. *)
(**)
(**)
(**)
(**)
(*20 November 2017: Replaced Substitute with NCReplaceRepeated throughout the notebook.*)
(**)
(*Restructured the main functions into one chapter which has several subsections for related types of functions. This is in hopes of making it easier to find a specific function in the future. Furthermore, this makes it so that all that needs to be compiled is the "Main Functions" section in order to work with the notebook. Old functions or functions that failed to meet their intended purpose are moved into the unsupported chapter. This section should not be compiled as it could break other sections. It has been kept in case we ever want to work with the functions again.*)
(**)
(*Add several variables to blocks which had failed to be put in the block previously. *)
(**)
(*Added a function to count kernel data for a list of extreme points. The function is ExtremePointListKernelAnalysis found in the Utilities section*)
(**)
(*Removed an extraneous print[] from ClassifyExtremePoint. This was previously generating lots of undesired blank lines in large data generation tests.*)
